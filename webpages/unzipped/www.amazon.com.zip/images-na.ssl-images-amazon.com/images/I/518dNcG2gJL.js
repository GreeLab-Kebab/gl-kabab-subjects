(function(G) {
    var g = window.AmazonUIPageJS || window.P,
        r = g._namespace || g.attributeErrors,
        d = r ? r("RetailSearchAutocompleteAssets", "") : g;
    d.guardFatal ? d.guardFatal(G)(d, window) : d.execute(function() {
        G(d, window)
    })
})(function(G, g, r) {
    (function(d) {
        if (!d.$Nav || d.$Nav._replay) {
            document.createElement("header");
            var a = function() {
                this.data = {}
            };
            a.arrayAdder = function(b) {
                return function() {
                    this.data[b] = (this.data[b] || []).concat([].slice.call(arguments));
                    return this
                }
            };
            a.prototype = {
                build: function(b, a) {
                    this.data.name = b;
                    this.data.value =
                        a;
                    this.data.immediate = !1;
                    this.data.process = !0;
                    c.manager.add(this.data)
                },
                run: function(b, a) {
                    a && (this.data.name = b);
                    this.data.value = a || b;
                    this.data.process = !0;
                    c.manager.add(this.data)
                },
                publish: function(b, a) {
                    this.data.name = b;
                    this.data.value = a;
                    c.manager.publish(this.data)
                },
                declare: function(b, a) {
                    this.data.name = b;
                    this.data.value = a;
                    c.manager.add(this.data)
                },
                when: a.arrayAdder("when"),
                iff: a.arrayAdder("iff"),
                filter: a.arrayAdder("filter"),
                observe: a.arrayAdder("observe")
            };
            var c = function(b) {
                    c.manager.add(b)
                },
                e =
                function(b) {
                    c[b] = function() {
                        var c = new a;
                        return c[b].apply(c, arguments)
                    }
                },
                f;
            for (f in a.prototype) a.prototype.hasOwnProperty(f) && e(f);
            c.make = function() {
                return c
            };
            c.getNow = function(b, a) {
                return c.manager.get(b, a)
            };
            c.stats = function(b) {
                return c.manager.stats(b)
            };
            c.importEvent = function(b, a) {
                a = a || {};
                a.name = b;
                c.manager.importEvent(a)
            };
            c.manager = {
                pending: [],
                add: function(b) {
                    this.pending.push({
                        m: "add",
                        data: b
                    })
                },
                publish: function(b) {
                    this.pending.push({
                        m: "publish",
                        data: b
                    })
                },
                importEvent: function(b) {
                    this.pending.push({
                        m: "importEvent",
                        data: b
                    })
                },
                get: function(b, a) {
                    return a
                },
                stats: function() {
                    return {}
                }
            };
            if (d.$Nav && d.$Nav.make && d.$Nav.make._shims) {
                e = function(b) {
                    for (var f = new a, d = 0; d < b.length; d++) {
                        var e = b[d];
                        if ("importEvent" === e.m) {
                            b = e.a[1] || {};
                            b.name = e.a[0];
                            c.manager.importEvent(b);
                            break
                        } else if (!f[e.m]) break;
                        f[e.m].apply(f, e.a)
                    }
                };
                f = d.$Nav.make._shims;
                for (var b = 0; b < f.length; b++) {
                    for (var u = 0; u < f[b]._replay.length; u++) e(f[b]._replay[u]);
                    for (var m in f[b]) f[b].hasOwnProperty(m) && c.hasOwnProperty(m) && (f[b][m] = c[m])
                }
            }
            d.$Nav = c
        }
    })(g);
    (function(d,
        a, c, e) {
        if ((a = d.$Nav) && a.manager && a.manager.pending) {
            var f = c.now || function() {
                    return +new c
                },
                b = function(b) {
                    return "function" === typeof b
                },
                u = "object" === typeof d.P && "function" === typeof d.P.when && "function" === typeof d.P.register && "function" === typeof d.P.execute,
                m = function(b, a) {
                    a = a || {};
                    var c = a.start || 50,
                        f = function() {
                            c <= (a.max || 2E4) && !b() && (setTimeout(f, c), c *= a.factor || 2)
                        };
                    return f
                },
                k = function(b, a) {
                    try {
                        return a()
                    } catch (c) {
                        if (a = c, b = "[rcx-nav:" + b + "] ", a && a.message ? a.message = b + a.message : "object" === typeof a ? a.message =
                            b : a = b + a, d.console && d.console.error && d.console.error(a), d.ueLogError) d.ueLogError(a);
                        else throw a;
                    }
                },
                h = function() {
                    function b() {
                        return setTimeout(a, 0)
                    }

                    function a() {
                        for (var d = b(), m = f(); c.length;)
                            if (c.shift()(), 50 < f() - m) return;
                        clearTimeout(d);
                        e = !1
                    }
                    var c = [],
                        e = !1;
                    try {
                        /OS 6_[0-9]+ like Mac OS X/i.test(navigator.userAgent) && d.addEventListener && d.addEventListener("scroll", b, !1)
                    } catch (m) {}
                    return function(a) {
                        c.push(a);
                        e || (b(), e = !0)
                    }
                }(),
                g = function() {
                    var b = {};
                    return {
                        run: function(a) {
                            if (b[a] instanceof Array)
                                for (var c =
                                        0; c < b[a].length; c++) b[a][c]();
                            b[a] = !0
                        },
                        add: function(a, c) {
                            for (var f = 1, d = function() {
                                    0 >= --f && h(c)
                                }, e = a.length; e--;) !0 !== b[a[e]] && ((b[a[e]] = b[a[e]] || []).push(d), f++);
                            d()
                        }
                    }
                },
                n = function(b) {
                    b = b || {};
                    this.context = b.context || d;
                    this.once = b.once || !1;
                    this.async = b.async || !1;
                    this.observers = [];
                    this.notifyCount = 0;
                    this.notifyArgs = []
                };
            n.prototype = {
                notify: function() {
                    this.notifyCount++;
                    if (!(this.once && 1 < this.notifyCount)) {
                        this.notifyArgs = [].slice.call(arguments);
                        for (var b = 0; b < this.observers.length; b++) this._run(this.observers[b])
                    }
                },
                observe: function(a) {
                    b(a) && (this.once && this.isNotified() ? this._run(a) : this.observers.push(a))
                },
                boundObserve: function() {
                    var b = this;
                    return function() {
                        b.observe.apply(b, arguments)
                    }
                },
                isNotified: function() {
                    return 0 < this.notifyCount
                },
                _run: function(b) {
                    var a = this.notifyArgs,
                        c = this.context;
                    this.async ? h(function() {
                        b.apply(c, a)
                    }) : b.apply(c, a)
                }
            };
            e = function() {
                var a = {},
                    c = 0,
                    e = {},
                    p = g(),
                    y = {},
                    r = function(b) {
                        this.data = {
                            name: "nav:" + c++,
                            value: null,
                            result: null,
                            immediate: !0,
                            process: !1,
                            override: !1,
                            resolved: !1,
                            watched: !1,
                            context: e,
                            when: [],
                            iff: [],
                            filter: [],
                            observe: [],
                            stats: {
                                defined: f(),
                                resolved: -1,
                                buildStarted: -1,
                                buildCompleted: -1,
                                callCount: 0
                            }
                        };
                        for (var a in b) b.hasOwnProperty(a) && (this.data[a] = b[a])
                    };
                r.prototype = {
                    getDependencyNames: function() {
                        for (var b = [].concat(this.data.when, this.data.filter), a = 0; a < this.data.iff.length; a++) "string" === typeof this.data.iff[a] ? b.push(this.data.iff[a]) : this.data.iff[a].name && b.push(this.data.iff[a].name);
                        return b
                    },
                    checkIff: function(b) {
                        b = function(b) {
                            b = "string" === typeof b ? {
                                name: b
                            } : b;
                            var c = a[b.name];
                            if (!c || !c.data.resolved) return !1;
                            var c = c.getResult(),
                                c = b.prop && c ? c[b.prop] : c,
                                f = b.value || !0;
                            switch (b.op || "truthy") {
                                case "truthy":
                                    return !!c;
                                case "falsey":
                                    return !c;
                                case "eq":
                                    return c === f;
                                case "ne":
                                    return c !== f;
                                case "gt":
                                    return c > f;
                                case "lt":
                                    return c < f;
                                case "gte":
                                    return c >= f;
                                case "lte":
                                    return c <= f
                            }
                            return !1
                        };
                        for (var c = 0; c < this.data.iff.length; c++)
                            if (!b(this.data.iff[c])) return !1;
                        return !0
                    },
                    watchModule: function(c) {
                        var f = this;
                        y[c] || (y[c] = new n);
                        y[c].observe(function() {
                            var a = f.getResult();
                            if (b(a)) return a.apply(f.data.context,
                                arguments)
                        });
                        a[c] && a[c].applyObserverWrapper()
                    },
                    applyObserverWrapper: function() {
                        var a = this;
                        if (y[this.data.name] && !this.data.watched && this.data.resolved && this.data.result) {
                            if (b(this.data.result)) {
                                var c = this.data.result;
                                this.data.result = function() {
                                    var b = c.apply(a.data.context, arguments);
                                    y[a.data.name].notify(b)
                                };
                                for (var f in c) c.hasOwnProperty(f) && (this.data.result[f] = c[f])
                            }
                            this.data.watched = !0
                        }
                    },
                    applyFilterWrapper: function() {
                        var c = this;
                        if (0 !== this.data.filter.length && b(this.data.result)) {
                            for (var f = [], d = [], m = 0; m < this.data.filter.length; m++)
                                if (a.hasOwnProperty(this.data.filter[m])) {
                                    var h = a[this.data.filter[m]].getResult();
                                    b(h.request) && f.push(h.request);
                                    b(h.response) && d.push(h.response)
                                }
                            var u = function(b, a) {
                                    for (var f = 0; f < b.length; f++)
                                        if (a = b[f].call(c.data.context, a), !1 === a) return !1;
                                    return a
                                },
                                k = this.data.result;
                            this.data.result = function(b) {
                                if (!1 !== (b = u(f, b)) && (b = k.call(e, b), !1 !== (b = u(d, b)))) return b
                            }
                        }
                    },
                    execute: function() {
                        if (this.checkIff()) {
                            for (var b = 0; b < this.data.observe.length; b++) this.watchModule(this.data.observe[b]);
                            p.run(this.data.name);
                            this.data.resolved = !0;
                            this.data.stats.resolved = f();
                            this.data.immediate && this.getResult()
                        }
                    },
                    getResult: function() {
                        var c = this;
                        this.data.stats.callCount++;
                        if (null !== this.data.result || !this.data.resolved) return this.data.result;
                        this.data.stats.buildStarted = f();
                        var e = [];
                        if (this.data.process && b(this.data.value)) {
                            for (var d = 0; d < this.data.when.length; d++) e.push(a.hasOwnProperty(this.data.when[d]) ? a[this.data.when[d]].getResult() : null);
                            this.data.result = k(this.data.name, function() {
                                return c.data.value.apply(c.data.context,
                                    e)
                            })
                        } else this.data.result = this.data.value;
                        this.applyFilterWrapper();
                        this.applyObserverWrapper();
                        this.data.stats.buildCompleted = f();
                        return this.data.result
                    }
                };
                return {
                    add: function(b) {
                        if (!a.hasOwnProperty(b.name) || b.override) {
                            var c = new r(b);
                            a[c.data.name] = c;
                            b = function() {
                                c.execute()
                            };
                            var f = c.getDependencyNames();
                            0 === f.length ? h(b) : p.add(f, b)
                        }
                    },
                    publish: function(b) {
                        this.add(b);
                        u && d.P.register(b.name, function() {
                            return b.value
                        });
                        d.amznJQ && d.amznJQ.declareAvailable(b.name)
                    },
                    importEvent: function(b) {
                        var a = this;
                        b = b || {};
                        u && d.P.when(b.name).execute(function(c) {
                            c = void 0 === c || null === c ? b.otherwise : c;
                            a.add({
                                name: b.as || b.name,
                                value: c
                            })
                        });
                        if (d.amznJQ) d.amznJQ[b.useOnCompletion ? "onCompletion" : "available"](b.amznJQ || b.name, m(function() {
                            var c;
                            if (b.global) {
                                c = d;
                                for (var f = (b.global || "").split("."), e = 0, m = f.length; e < m; e++) c && f[e] && (c = c[f[e]])
                            } else c = b.otherwise;
                            if (b.retry && (void 0 === c || null === c)) return !1;
                            a.add({
                                name: b.as || b.name,
                                value: c
                            });
                            return !0
                        }))
                    },
                    get: function(b, c) {
                        return a[b] && a[b].data.resolved ? a[b].getResult() : c
                    },
                    stats: function(b) {
                        var c = {},
                            f;
                        for (f in a)
                            if (a.hasOwnProperty(f) && (!b || !a[f].data.resolved)) {
                                c[f] = a[f].data;
                                c[f].blocked = [];
                                for (var e = a[f].getDependencyNames(), d = 0; d < e.length; d++) a[e[d]] && a[e[d]].data.resolved || c[f].blocked.push(e[d])
                            }
                        return c
                    }
                }
            }();
            if (a && a.manager && a.manager.pending)
                for (var p = 0; p < a.manager.pending.length; p++) e[a.manager.pending[p].m](a.manager.pending[p].data);
            a.manager = e;
            a.declare("now", f);
            a.declare("async", h);
            a.declare("eventGraph", g);
            a.declare("Observer", n)
        }
    })(g, document, Date);
    "use strict";
    g.$Nav.build("NavDomApi", function() {
        return {
            getAliasFromDropdown: function(d) {
                if (!d || !d.aliases || "string" !== typeof d.aliases) return "aps";
                var a = d.aliases.split(",");
                return (a = (d = d.implicitAlias) ? [d] : a) && 1 === a.length && "" != a[0] ? a[0] : "aps"
            }
        }
    });
    "use strict";
    g.$Nav.build("sx.iss.TemplateEngine", function() {
        var d = {},
            a = {
                allowUndefined: !0,
                allowMalformedHtml: !0
            },
            c = function f(b, c) {
                var m = /^[a-zA-Z0-9_-]+$/.test(b) ? d[b] = d[b] || f(document.getElementById(b).innerHTML) : new Function("obj", "var p\x3d[],print\x3dfunction(){p.push.apply(p,arguments);};with(obj){p.push('" +
                    b.replace(/[\r\t\n]/g, " ").replace(/'(?=[^#]*#>)/g, "\t").split("'").join("\\'").split("\t").join("'").replace(/<#=(.+?)#>/g, a.allowUndefined ? "',$1,'" : "',typeof($1)!\x3d\x3d\"undefined\"?$1:function(){throw 0}(),'").split("\x3c#").join("');").split("#\x3e").join("p.push('") + "');}return p.join('');");
                b = a.allowMalformedHtml ? m : function(b) {
                    b = m(b);
                    var a = document.createElement("div");
                    a.innerHTML = b;
                    if (a.innerHTML === b) return b;
                    throw "Malformed html";
                };
                return c ? b(c) : b
            };
        return {
            template: c,
            templateWithOptions: function(f,
                b, d) {
                var m = a;
                a = b;
                f = c(f, d);
                a = m;
                return f
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils", "sx.iss.DomUtils").build("sx.iss.EventBus.instance", function(d, a) {
        return new function() {
            function c(b) {
                var a = typeof b,
                    c = "";
                "object" === a && b.hasOwnProperty("name") ? c = b.name : "string" === a && (c = b);
                return c
            }
            var e = {},
                f = {};
            this.listen = function(b, f, m) {
                var k, h;
                if (a.isArray(b)) {
                    for (k = 0; k < b.length; k++) h = b[k], this.listen(h, f, m), d.logDebug("Listening for: " + h);
                    return this
                }
                h = c(b);
                e[h] || (e[h] = []);
                e[h].push({
                    f: f,
                    o: m
                });
                d.logDebug("Listening for: " +
                    h);
                return this
            };
            this.trigger = function(b, a) {
                b = c(b);
                d.logDebugWithTrace("Trigger: " + b, a);
                b = e[b];
                var f;
                if (b) {
                    for (f = 0; f < b.length; f++) b[f].f.call(b[f].o, a);
                    return this
                }
            };
            this.triggerThrottledEvent = function(b, a, m) {
                var k = c(b);
                d.logDebugWithTrace("Trigger (throttled): " + k, a);
                var h = e[k];
                b = f[k];
                if (h) return m === r && (m = 100), b && (clearTimeout(b), delete f[k]), b = setTimeout(function() {
                    var b;
                    for (b = 0; b < h.length; b++) h[b].f.call(h[b].o, a);
                    delete f[k]
                }, m), f[k] = b, this
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils", "sx.iss.DomUtils").build("sx.iss.IssContext",
        function(d, a) {
            var c;
            return {
                getConfiguration: function() {
                    return c
                },
                setConfiguration: function(a) {
                    c = a
                }
            }
        });
    "use strict";
    g.$Nav.when("sx.iss.CommonSuggestionUtils").build("sx.iss.suggestionUtils", function(d) {
        return {
            getPrefixPos: d.getPrefixPos,
            getPrefixPosMultiWord: d.getPrefixPosMultiWord,
            splitStringForDisplay: d.splitStringForDisplay,
            isComplexLayoutScript: d.isComplexLayoutScript
        }
    });
    "use strict";
    g.$Nav.build("sx.iss.CommonSuggestionUtils", function() {
        var d = /\s/;
        return {
            getPrefixPos: function(a, c) {
                return a.toLowerCase().indexOf(c.toLowerCase())
            },
            getPrefixPosMultiWord: function(a, c) {
                c = a.toLowerCase().indexOf(c.toLowerCase());
                if (-1 === c) return -1;
                if (0 === c) return 0;
                a = a[c - 1];
                return " " === a || "\t" === a || a.match(d) ? c : -1
            },
            splitStringForDisplay: function(a, c, d) {
                return {
                    bprefix: a.substr(0, c),
                    prefix: a.substr(c, d),
                    suffix: a.substr(c + d)
                }
            },
            isComplexLayoutScript: function(a) {
                return (a = a.charCodeAt(0)) ? 0 >= (a - 1536) * (a - 2431) : !1
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.suggestionUtils", "sx.iss.CachingProvider.instance").build("sx.iss.commonUtils", function(d, a) {
        function c(b) {
            var c = !1;
            b && (b = b.charAt(0), c = a.get("isComplexLayout", b), c === r && (c = d.isComplexLayoutScript(b), a.put("isComplexLayout", b, c)));
            return c
        }
        var e = /\"/gi,
            f = /[&|]+/gi;
        return {
            suggestionUtils: d,
            isHighlightDisabled: function(b) {
                return c(b && b.length && b[0].length ? b[0] : r)
            },
            isHighlightDisabledForAPIV2: function(b) {
                return c(b && b.length && b[0].value && b[0].value.length ? b[0].value : r)
            },
            extractDomainFromUrl: function(b) {
                return -1 < b.indexOf("://") ? b.split("/")[2] : b.split("/")[0]
            },
            pruneUndefined: function(b) {
                if ("object" !== typeof b) return b;
                for (var a in b) b[a] === r && delete b[a];
                return b
            },
            findIndex: function(b, a) {
                if (!Array.isArray(b) || 0 === b.length || "function" !== typeof a) return -1;
                for (var c = 0; c < b.length; c++)
                    if (a(b[c])) return c;
                return -1
            },
            isWeblabTreatment: function(b, a, c) {
                return b !== r && b.weblabTreatments !== r && "string" === typeof a && "string" === typeof c && "" !== a && "" !== c && (b = b.weblabTreatments[a], "string" === typeof b && "" !== b && b === c) ? !0 : !1
            },
            getWeblabOverrideFromCookie: function() {
                for (var b = document.cookie.split(";"), a = 0; a < b.length; a++) {
                    var c = b[a].trim();
                    if (0 === c.indexOf("experiment\x3d")) {
                        b = c.substring(11, c.length);
                        b = b.replace(e, "");
                        b = b.split(f);
                        a = "";
                        for (c = 0; c < b.length; c++) var d = b[c].trim(),
                            a = a + d + ",";
                        0 < a.length && (a = a.substring(0, a.length - 1));
                        return a
                    }
                }
                return ""
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.TimingProvider.instance", "sx.iss.EventBus.instance", "sx.iss.commonUtils", "sx.iss.DependenciesMet").build("sx.iss.utils", function(d, a, c, e) {
        function f(b) {
            var a = {
                "\x26": "\x26amp;",
                "\x3c": "\x26lt;",
                "\x3e": "\x26gt;",
                '"': "\x26quot;",
                "'": "\x26#39;",
                "/": "\x26#x2F;"
            };
            return String(b).replace(/[&<>"'\/]/g, function(b) {
                return a[b]
            })
        }
        var b = /[^\w]/;
        return {
            timingProvider: a,
            eventBus: c,
            suggestionUtils: e.suggestionUtils,
            now: function() {
                return (new Date).getTime()
            },
            escapeRegExp: function(b) {
                return b.replace(/([.*+?\^${}()|\[\]\/\\])/g, "\\$1")
            },
            htmlDecode: function(a) {
                var c = a;
                a && b.test(a) && (c = d("\x3cdiv\x3e\x3c/div\x3e").html(a).text());
                return c = f(c)
            },
            htmlEncode: function(b) {
                var a = b;
                b && (a = d("\x3cdiv\x3e\x3c/div\x3e").text(b).html());
                return a
            },
            escapeHtmlTags: f,
            extractDomainFromUrl: e.extractDomainFromUrl,
            uiKeycode: {
                BACKSPACE: 8,
                COMMA: 188,
                DELETE: 46,
                DOWN: 40,
                END: 35,
                ENTER: 13,
                ESCAPE: 27,
                HOME: 36,
                LEFT: 37,
                PAGE_DOWN: 34,
                PAGE_UP: 33,
                PERIOD: 190,
                RIGHT: 39,
                SPACE: 32,
                TAB: 9,
                UP: 38
            },
            isHighlightDisabled: e.isHighlightDisabled,
            isHighlightDisabledForAPIV2: e.isHighlightDisabledForAPIV2,
            findIndex: e.findIndex,
            pruneUndefined: e.pruneUndefined,
            isWeblabTreatment: e.isWeblabTreatment,
            getWeblabOverrideFromCookie: e.getWeblabOverrideFromCookie,
            numSuggestions: {
                MAX_NUMBER_OF_SUGGESTIONS: 11,
                MOBILE: 6
            }
        }
    });
    "use strict";
    g.$Nav.when("$").build("sx.iss.DomUtils",
        function(d) {
            var a = /\+/g,
                c = /^\s+/;
            (function() {
                Array.prototype.indexOf || (Array.prototype.indexOf = function(a, c) {
                    var b = this.length >>> 0;
                    c = Number(c) || 0;
                    c = 0 > c ? Math.ceil(c) : Math.floor(c);
                    for (0 > c && (c += b); c < b; c++)
                        if (c in this && this[c] === a) return c;
                    return -1
                })
            })();
            return {
                isHoveredClass: "is-hovered",
                getKeyword: function(a) {
                    return (a = a.val()) ? a.replace(c, "") : a
                },
                isElHoveredOver: function(a) {
                    return a.hasClass("is-hovered")
                },
                hoverOverEl: function(a) {
                    return a.addClass("is-hovered")
                },
                hoverOutEl: function(a) {
                    return a.removeClass("is-hovered")
                },
                isArray: function(a) {
                    return "[object Array]" === Object.prototype.toString.call(a)
                },
                getFormParams: function(c) {
                    c = c.split("?");
                    for (var f = 1 < c.length ? c[1] : r, f = f ? f.split("\x26") : [], b = f.length, d; 0 < b--;) d = f[b].split("\x3d"), f[b] = {
                        name: d[0],
                        value: d[1].replace(a, " ")
                    };
                    return {
                        uri: c[0],
                        formParams: f
                    }
                },
                suggestionClass: ".s-suggestion",
                hiddenInputValue: "frmDynamic",
                hiddenInputClass: ".frmDynamic",
                areAnySuggestionsHoveredOver: function(a) {
                    return 0 < a.find(".is-hovered").length
                },
                getCursorPosition: function(a) {
                    a = a.get(0);
                    if ("selectionStart" in a) return a.selectionStart;
                    if (document.selection) {
                        a.focus();
                        var c = document.selection.createRange(),
                            b = c.text.length;
                        c.moveStart("character", -a.value.length);
                        return c.text.length - b
                    }
                    return -1
                }
            }
        });
    "use strict";
    g.$Nav.build("sx.iss.DebugUtils", function() {
        function d() {
            return e.iss || e.isstrace
        }

        function a() {
            return e.isstrace
        }

        function c(a, b) {
            d() && g.console && (b !== r ? console.debug(a, b) : console.debug(a))
        }
        var e = {
            iss: !1,
            isstrace: !1,
            noiss: !1,
            isspolyfill: !1,
            isscf: !1
        };
        return {
            init: function(a) {
                if (a &&
                    0 < a.length) {
                    a = a.substring(1).split("\x26");
                    for (var b = 0; b < a.length; b++) {
                        var c = a[b].split("\x3d");
                        if ("debug" === c[0]) {
                            for (var d in e) e.hasOwnProperty(d) && (e[d] = -1 !== c[1].indexOf(d) ? !0 : !1);
                            break
                        }
                    }
                }
            },
            logDebug: c,
            logDebugWithTrace: function(d, b) {
                c(d, b);
                a() && console.trace()
            },
            isDebugModeOn: d,
            isDebugModeOnWithTrace: a,
            isDisableISS: function() {
                return e.noiss
            },
            isUsingPolyFill: function() {
                return e.isspolyfill
            },
            isQIAEnabled: function() {
                return e.isscf
            }
        }
    });
    "use strict";
    g.$Nav.build("sx.iss.ObjectUtils", function() {
        return {
            freeze: function(d) {
                Object.freeze &&
                    d && Object.freeze(d)
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.DebugUtils").run(function(d, a) {
        a.isDisableISS() || (d.fn.delegate && !a.isUsingPolyFill() || d.extend(d.fn, {
            delegate: function(c, e, f) {
                return this.bind(e, function(b) {
                    var e = d(b.target);
                    if (e.is(c) || 0 < e.parents(c).length) return a.logDebug("delegate ", {
                        selector: c,
                        target: e,
                        event: b
                    }), f.apply(e, arguments)
                })
            }
        }), g.$Nav.declare("sx.iss.DependenciesMet"))
    });
    "use strict";
    g.$Nav.when("sx.iss.ConfigVariants").build("sx.iss.ConfigVariantUtil", function(d) {
        return {
            augmentConfig: function(a) {
                a &&
                    a.obfMkt && ((Object.keys(d) || []).forEach(function(c) {
                        var e = d[c],
                            f = e.marketplaces || [];
                        "function" === typeof f.indexOf && -1 !== f.indexOf(a.obfMkt) ? a[c] = e.returnVal : a[c] = r
                    }), a.crossCategoryEmphasisTreatment = !0)
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils").build("sx.iss.V2ResponseReformatter", function(d) {
        return {
            reformat: function(a) {
                if (!a) return ["", [],
                    [],
                    [], ""
                ];
                var c = a.prefix,
                    e = a.responseId,
                    f = [],
                    b = [],
                    g = [];
                (a.suggestions || []).forEach(function(a, c) {
                    var e = a.type || "";
                    if ("" !== e && "KEYWORD" === e) {
                        var e = [],
                            l = {},
                            n;
                        a.fallback &&
                            e.push("fb");
                        Array.isArray(a.highlightFragments) && (n = [], a.highlightFragments.forEach(function(b) {
                            n.push({
                                isHit: b.hit,
                                text: b.text
                            })
                        }));
                        l = {
                            sc: a.spellCorrected ? "1" : r,
                            ghost: a.ghost ? !0 : r,
                            source: e.length ? e : r,
                            highlightFragments: n
                        };
                        d.pruneUndefined(l);
                        g.push(l);
                        e = d.findIndex(a.scopes, function(b) {
                            return "ALIAS" === b.type
                        });
                        if (-1 !== e && (b.push({
                                name: a.scopes[e].display,
                                alias: a.scopes[e].value
                            }), 1 === c && f[0] === a.value)) return;
                        f.push(a.value)
                    }
                });
                b.length && (g[0].nodes = b);
                return [c, f, g, [], e]
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.ObjectUtils").build("sx.iss.SuggestionTypes",
        function(d) {
            var a = {
                a9: {
                    name: "a9",
                    reftag: "i",
                    templateId: "a9-suggestion-template"
                },
                a9Xcat: {
                    name: "a9-xcat",
                    reftag: "c",
                    templateId: "a9xc-suggestion-template"
                },
                a9XOnly: {
                    name: "a9-xcat-only",
                    reftag: "xo",
                    source: "xo",
                    templateId: "s-suggestion"
                },
                nextSearch: {
                    name: "nextSearch",
                    reftag: "nsis",
                    templateId: "s-nextSearch"
                },
                recentSearch: {
                    name: "recentSearch",
                    reftag: "rsis",
                    templateId: "s-recentSearch"
                },
                trendSearch: {
                    name: "trendSearch",
                    reftag: "trnd",
                    templateId: "s-suggestion"
                },
                bia: {
                    name: "bia",
                    reftag: "bia",
                    templateId: "s-bia"
                },
                qu: {
                    name: "qu",
                    reftag: "qu_au",
                    templateId: "s-qu-suggestion"
                },
                help: {
                    name: "help",
                    reftag: "h",
                    templateId: "s-suggestion"
                },
                KeywordSuggestion: {
                    name: "KEYWORD",
                    templateId: "s-suggestion"
                },
                BIASuggestion: {
                    name: "BUY_IT_AGAIN"
                },
                TrendingSearchesSuggestion: {
                    name: "TRENDING_SEARCHES"
                },
                WidgetSuggestion: {
                    name: "WIDGET"
                }
            };
            d.freeze(a);
            return a
        });
    "use strict";
    g.$Nav.when("sx.iss.ObjectUtils").build("sx.iss.InfoTypes", function(d) {
        var a = {
            actor: "actor",
            author: "author",
            director: "director",
            seasonTitle: "season_title",
            title: "title"
        };
        d.freeze(a);
        return a
    });
    "use strict";
    g.$Nav.build("sx.iss.DataAttributes", function() {
        return {
            fallback: {
                name: "isfb"
            },
            spellCorrected: {
                name: "issc"
            },
            type: {
                name: "type"
            },
            refTag: {
                name: "reftag"
            }
        }
    });
    "use strict";
    g.$Nav.build("sx.iss.TimingEvents", function() {
        return {
            latency: {
                group: "Latency",
                events: {
                    timeToDisplay: "timeToDisplay"
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils").build("sx.iss.Events", function(d) {
        function a() {
            var a = Date.now();
            return {
                uid: a,
                suggestionsReadyForDisplay: {
                    name: "suggestionsReadyForDisplay-" +
                        a
                },
                suggestionsReady: {
                    name: "suggestionsReady-" + a
                },
                suggestionsRendered: {
                    name: "suggestionsRendered-" + a
                },
                updateSearchBox: {
                    name: "updateSearchBox-" + a
                },
                selectionChange: {
                    name: "selectionChange-" + a
                },
                dropdownHidden: {
                    name: "dropdownHidden-" + a
                },
                updateSearchTerm: {
                    name: "updateSearchTerm-" + a
                },
                suggestionClicked: {
                    name: "suggestionClicked-" + a
                },
                suggestionsNeeded: {
                    name: "suggestionsNeeded-" + a
                },
                a9SuggestionsNeeded: {
                    name: "a9-suggestionsNeeded-" + a
                },
                recentSuggestionsNeeded: {
                    name: "recent-suggestionsNeeded-" + a
                },
                biaSuggestionsNeeded: {
                    name: "bia-suggestionsNeeded-" +
                        a
                },
                biaSuggestionsReady: {
                    name: "bia-suggestionsReady-" + a
                },
                trendingSuggestionsNeeded: {
                    name: "trendSearch-suggestionsNeeded-" + a
                },
                trendingSuggestionsReady: {
                    name: "trendSearch-suggestionsReady-" + a
                },
                eventBasedSuggestionsNeeded: {
                    name: "event-based-suggestionsNeeded-" + a
                },
                eventBasedSuggestionsReady: {
                    name: "event-based-suggestionsReady-" + a
                },
                searchBoxUpdated: {
                    name: "searchBoxUpdated-" + a
                },
                noSuggestions: {
                    name: "nosuggestions-" + a
                },
                searchBoxFocusIn: {
                    name: "searchBoxFocusIn-" + a
                },
                searchBoxFocusOut: {
                    name: "searchBoxFocusOut-" +
                        a
                },
                keydown: {
                    name: "keydown-" + a
                },
                hideDropdown: {
                    name: "hidedropdown-" + a
                },
                focusOnParent: {
                    name: "focusOnParent-" + a
                },
                parentFocused: {
                    name: "parentFocused-" + a
                },
                parentLostFocus: {
                    name: "parentLostFocus-" + a
                },
                searchTermChanged: {
                    name: "searchTermChanged-" + a
                },
                suggestionsDisplayed: {
                    name: "suggestionsDisplayed-" + a
                },
                upArrowPressed: {
                    name: "upArrowPressed-" + a
                },
                downArrowPressed: {
                    name: "downArrowPressed-" + a
                },
                blockSearchBoxFocusInOnce: {
                    name: "blockSearchBoxFocusInOnce-" + a
                },
                allowSearchBoxFocusIn: {
                    name: "allowSearchBoxFocusIn-" + a
                },
                reftagUpdatedAfterRender: {
                    name: "reftagUpdatedAfterRender-" + a
                },
                onFocusWithSearchTerm: {
                    name: "onFocusWithSearchTerm"
                },
                onFocusEmptySearchTerm: {
                    name: "onFocusEmptySearchTerm"
                },
                onKeyPress: {
                    name: "onKeyPress"
                },
                onPaste: {
                    name: "onPaste"
                },
                onIMEAction: {
                    name: "onIMEAction"
                }
            }
        }
        return {
            globals: {
                issLoaded: {
                    name: "issLoaded"
                },
                suggestionsRendered: {
                    name: "suggestionsRendered"
                },
                initializeNavSearchBox: {
                    name: "initializeSearchBox"
                },
                navConfigReady: {
                    name: "navConfigReady"
                }
            },
            createInstance: function() {
                return new a
            },
            createEvent: function(a,
                e) {
                var f = e;
                e.hasOwnProperty("name") ? f = e.name : "string" === typeof e ? f = e : d.logDebug('Format of "event" parameter is not a string or an event object', e);
                return a + "-" + f
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.ObjectUtils").build("sx.iss.Platform", function(d) {
        var a = {
            name: "mobile",
            cid: "amazon-search-ui-mobile",
            callback: "String",
            needExtraParams: !1
        };
        d.freeze(a);
        return a
    });
    "use strict";
    g.$Nav.build("sx.iss.ConfigVariants", function() {
        return {
            crossCategoryEmphasisTreatment: {
                marketplaces: "ATVPDKIKX0DER A1F83G8C2ARO7P A1PA6795UKMFR9 A21TJRUUN4KGV A13V1IB3VIYZZH A2EUQ1WTGCTBG2 APJ6JRA9NG5V4".split(" "),
                returnVal: !0
            },
            useAmazonEmberFontFamily: {
                marketplaces: "ATVPDKIKX0DER A1F83G8C2ARO7P A1PA6795UKMFR9 A21TJRUUN4KGV A13V1IB3VIYZZH A2EUQ1WTGCTBG2".split(" "),
                returnVal: !0
            }
        }
    });
    g.$Nav.when("$").build("sx.iss.TimingProvider.instance", function(d) {
        return new function() {
            var a = {};
            this.startTimer = function(c, d) {
                a[c] || (a[c] = {});
                a[c][d] = {
                    start: +new Date
                }
            };
            this.stopTimer = function(c, d) {
                c = a[c] && a[c][d];
                if (!c) return -1;
                c.end = +new Date;
                return c.end - c.start
            };
            this.getTimings = function(c) {
                return a[c]
            };
            this.getTimingStats =
                function(c) {
                    var e = {
                            name: c
                        },
                        f = 0,
                        b = 0,
                        g = r,
                        m = r,
                        k = 0,
                        h = 0,
                        l = [],
                        n = 0,
                        p = 0;
                    if (!a[c]) return r;
                    d.each(a[c], function(a, c) {
                        if (c.start && c.end) {
                            h = c.end - c.start;
                            l.push(h);
                            k++;
                            b += h;
                            if (!g || h < g) g = h;
                            if (!m || h > m) m = h
                        }
                    });
                    l.sort();
                    e.n = k;
                    e.avg = b / k;
                    e.min = g;
                    e.max = m;
                    e.med = 1 === k ? l[0] : k % 2 ? (l[Math.floor(k / 2)] + l[Math.ceil(k / 2)]) / 2 : l[k / 2];
                    for (f = 0; f < k; f++) n = l[f] - e.avg, n *= n, p += n;
                    e.stddev = Math.sqrt(p / k);
                    return e
                };
            this.getTimingWithDisplayLatency = function(c, d) {
                return (c = a[c] && a[c][d]) && c.end && c.start ? c.end - c.start + 100 : -1
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.Events", "sx.iss.SuggestionTypes", "sx.iss.DebugUtils", "sx.iss.AjaxCallProvider", "sx.iss.ISSAjaxUrlProvider", "sx.iss.EventBasedSuggestionResultsProcessor", "sx.iss.Platform").build("sx.iss.EventBasedSuggestionProvider", function(d, a, c, e, f, b, u, m, k) {
        var h = g.ue && "function" === typeof g.ue.count && g.ue.count;
        return function(d, g) {
            function p(b) {
                var k = b.searchTerm,
                    q = b.keystroke,
                    p = this,
                    u = [e.KeywordSuggestion.name, e.WidgetSuggestion.name];
                b = t(k, q, b.event);
                var r = v.buildUrl(b,
                    u);
                p._requestCounter = (p._requestCounter || 0) + 1;
                p._lastRequestCounter = p._lastRequestCounter || 0;
                var B = p._requestCounter;
                x.callService(r, function(b) {
                    if (B < p._lastRequestCounter) h && h("iss-suggestion-processor:service-response-skipped", 1);
                    else {
                        h && h("iss-suggestion-processor:service-response-skipped", 0);
                        p._lastRequestCounter = B;
                        var e = new m(d),
                            u;
                        b && b.suggestions ? (u = e.processResults(b), h && h("iss-suggestion-processor:service-response-empty", 0)) : (f.logDebugWithTrace("Event based suggestion provider service call response is empty",
                            r), h && h("iss-suggestion-processor:service-response-empty", 1));
                        b = {
                            searchTerm: k,
                            keystroke: q,
                            suggestionSets: u.augmentedSuggestions,
                            suggestionTitleId: u.suggestionTitleId
                        };
                        e = c.createEvent("event-based", g.suggestionsReady);
                        a.eventBus.trigger(e, b)
                    }
                })
            }

            function t(b, c, f) {
                b = {
                    b2b: d.b2b,
                    fresh: d.fresh,
                    ks: c,
                    prefix: b,
                    event: f,
                    limit: "mobile" === k.name ? a.numSuggestions.MOBILE : a.numSuggestions.MAX_NUMBER_OF_SUGGESTIONS
                };
                q && delete b.ks;
                d.fb !== r && (b.fb = d.fb);
                d && d.isInternal && (b.wc = a.getWeblabOverrideFromCookie());
                return b
            }
            var q = !1 === d.isAPICachingDisabled,
                x = new b(d, "iss-api-v2", {
                    cache: q
                }),
                v = new u(d);
            a.eventBus.listen(g.eventBasedSuggestionsNeeded, p, this);
            return {
                getName: function() {
                    return "event-based"
                },
                produceSuggestions: p
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.Events", "sx.iss.AjaxCallProvider", "sx.iss.ISSAjaxUrlProvider", "sx.iss.SuggestionTypes", "sx.iss.V2ResponseReformatter").build("sx.iss.A9SuggestionProvider", function(d, a, c, e, f, b, u) {
        return function(m, k) {
            function h() {
                var a;
                a = q.aliases.split(",");
                var b = q.implicitAlias,
                    c = {},
                    f = "";
                c.aliases = b ? [b] : a;
                c.aliases && 1 === c.aliases.length && (c.alias = c.aliases[0]);
                a = c.alias || "aps";
                c = d.extend({}, {
                    cid: "amazon-search-ui-mobile",
                    action: "",
                    sugPrefix: "issDiv",
                    callback: "String"
                }, q);
                c.protocol = c.protocol || g.parent.document.location.protocol;
                var b = "\x26q\x3d" + encodeURIComponent(v) + "\x26search-alias\x3d" + a + "\x26client\x3d" + c.cid + "\x26mkt\x3d" + c.mkt + "\x26x\x3d" + c.callback,
                    e = "\x26sv\x3dmobile";
                q.sessionId && (e += "\x26s\x3d" + q.sessionId);
                q.requestId && (e += "\x26r\x3d" +
                    q.requestId);
                q.customerId && (e += "\x26c\x3d" + q.customerId);
                q.language && (e += "\x26l\x3d" + q.language);
                q.pageType && (e += "\x26p\x3d" + q.pageType);
                b += e;
                c.issPrimeEligible && -1 !== d.inArray(a, c.issPrimeEligible) ? f = "\x26pf\x3d1\x26fb\x3d0" : q.issXCat && (f = "\x26fb\x3d1");
                c.src || (c.src = c.host);
                y = c.protocol + "//" + c.src + "?method\x3dcompletion" + b + f
            }

            function l(b) {
                var d = ++x,
                    f, e;
                E = document.getElementsByTagName("head").item(0);
                A = "JscriptId" + d;
                w = document.createElement("script");
                w.setAttribute("type", "text/javascript");
                w.setAttribute("charset",
                    "utf-8");
                w.setAttribute("src", y);
                w.setAttribute("id", A);
                w.onload = w.onreadystatechange = function() {
                    if (!(f || this.readyState !== r && "loaded" !== this.readyState && "complete" !== this.readyState)) {
                        f = !0;
                        e = n.call(t, b);
                        this.onload = this.onreadystatechange = null;
                        try {
                            E.removeChild(w)
                        } catch (h) {}
                        g.completion = r;
                        a.timingProvider.stopTimer("a9", d);
                        var m = c.createEvent("a9", k.suggestionsReady);
                        a.eventBus.trigger(m, {
                            searchTerm: b,
                            suggestions: e
                        })
                    }
                };
                a.timingProvider.startTimer("a9", d);
                E.appendChild(w)
            }

            function n(b) {
                var c = g.completion[1],
                    d = 2 < g.completion.length ? g.completion[2] : [],
                    f = [],
                    e, h, k, m, p, n, u, l, x, t = "string" === typeof g.completion[4] ? g.completion[4] : r;
                k = "aps" === document.getElementById("nav-search-keywords-data").getAttribute("data-implicit-alias");
                var v = !1;
                if (0 < d.length && d[0].nodes !== r && !k && q.issXCat) {
                    m = !1;
                    for (e = 0; e < d[0].nodes.length; e++)
                        if ("aps" === d[0].nodes[e].alias) {
                            m = !0;
                            break
                        }
                    m || d[0].nodes.unshift({
                        alias: "aps",
                        name: q.apsName
                    })
                } else 0 < d.length && d[0].nodes === r && !k && q.issXCat && (d[0].nodes = [{
                    alias: "aps",
                    name: q.apsName
                }]);
                0 ===
                    c.length && 0 < b.length && !k && q.issXCat && (c = [b], d = [{
                        nodes: [{
                            alias: "aps",
                            name: q.apsName
                        }]
                    }], v = !0);
                var y = a.isHighlightDisabled(c);
                for (e = 0; e < c.length; e++)
                    if (k = c[e], m = encodeURIComponent(k), n = d && d[e] && "1" === d[e].sc, l = a.suggestionUtils.getPrefixPos(k, b), h = !1, q.issXCat && d && d[e] && d[e].source && d[e].source[0] && (h = "xo" === d[e].source[0] || "fb" === d[e].source[0]), y ? (x = k, l = u = "") : n || -1 === l ? (l = k, x = u = "") : (u = a.suggestionUtils.splitStringForDisplay(k, l, b.length), l = u.bprefix, x = u.prefix, u = u.suffix), v || h || f.push({
                            type: "a9",
                            crid: t,
                            spellCor: n,
                            bprefix: l,
                            prefix: x,
                            suffix: u,
                            keyword: k,
                            url: "/s?k\x3d" + m
                        }), p = d[e].nodes || [], !q.noXcats || q.issXCat)
                        for (h = 0; h < p.length; h++) f.push({
                            type: "a9",
                            spellCor: n,
                            bprefix: l,
                            prefix: x,
                            suffix: u,
                            keyword: k,
                            store: p[h].name,
                            storeText: q.searchboxSearchInMessage + p[h].name,
                            scope: p[h].alias,
                            url: "/s?k\x3d" + m + "\x26i\x3d" + encodeURIComponent(p[h].alias)
                        });
                return f || []
            }

            function p() {
                var a = q.aliases.split(","),
                    b = q.implicitAlias;
                return (a = b ? [b] : a) && 1 === a.length ? a[0] : "aps"
            }
            var t = this,
                q = m || {},
                x = 0,
                v, y, E, A, w, C = m.useApiV2Mobile,
                D, B;
            C && (D = new e(m, "iss-api-v2"), B = new f(m));
            t.getName = function() {
                return "a9"
            };
            m = c.createEvent("a9", k.suggestionsNeeded);
            a.eventBus.listen(m, function(f) {
                var e;
                if ((v = f.searchTerm) && v.length)
                    if (C) {
                        f = p();
                        var m = {
                            prefix: st,
                            alias: f
                        };
                        q.issPrimeEligible && -1 !== d.inArray(f, q.issPrimeEligible) ? m.fb = 0 : q.issXCat && (m.fb = 1);
                        f = B.buildUrl(m, [b.KeywordSuggestion.name]);
                        var w = ++x;
                        D.callService(f, function(b) {
                            b = u.reformat(b);
                            var d = v;
                            "undefined" !== typeof b ? (g.completion = b, b = n.call(t, d), g.completion = r, e = b) : e = [];
                            a.timingProvider.stopTimer("a9",
                                w);
                            b = c.createEvent("a9", k.suggestionsReady);
                            a.eventBus.trigger(b, {
                                searchTerm: v,
                                suggestions: e
                            })
                        });
                        a.timingProvider.startTimer("a9", w)
                    } else h.call(this), y && (e = l.call(this, v));
                else f = c.createEvent("a9", k.suggestionsReady), a.eventBus.trigger(f, {
                    searchTerm: v,
                    suggestions: []
                })
            }, t)
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.Events").build("sx.iss.RecentSearchSuggestionProvider", function(d, a, c) {
        return function(e) {
            var f = /[^\w]/;
            this.getName = function() {
                return "recent"
            };
            var b = c.createEvent("recent",
                e.suggestionsNeeded);
            a.eventBus.listen(b, function(b) {
                var m = [];
                b = b.searchTerm;
                if (g.sx && g.sx.searchsuggest && g.sx.searchsuggest.searchedText) {
                    var k = g.sx.searchsuggest.searchedText,
                        h = {},
                        l, n, p, t, q, x, v;
                    v = b && f.test(b) ? d("\x3cdiv\x3e\x3c/div\x3e").text(b).html() : b;
                    for (t = 0; t < k.length; t++) n = k[t].keywords, l = (l = n) && f.test(l) ? d("\x3cdiv\x3e\x3c/div\x3e").html(l).text() : l, p = a.suggestionUtils.getPrefixPosMultiWord(n, v), h[n] || -1 === a.suggestionUtils.getPrefixPosMultiWord(l, b) || (-1 === p ? (p = n, x = q = "") : (q = a.suggestionUtils.splitStringForDisplay(n,
                        p, v.length), p = q.bprefix, x = q.prefix, q = q.suffix), m.push({
                        type: "recent",
                        spellCor: !1,
                        bprefix: p,
                        prefix: x,
                        suffix: q,
                        keyword: l,
                        originalKeywords: n,
                        deleteUrl: k[t].deleteUrl
                    }), h[n] = 1)
                }
                k = c.createEvent("recent", e.suggestionsReady);
                a.eventBus.trigger(k, {
                    searchTerm: b,
                    suggestions: m
                })
            }, this)
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.TemplateEngine").build("sx.iss.SuggestionDisplayProvider", function(d, a, c) {
        return function(a, f, b) {
            var g, m;
            this.getDisplay = function(a) {
                if (!g(a)) return r;
                d.extend(a, b);
                return m(a)
            };
            g = "string" === typeof a ? function(b) {
                return b.type === a
            } : a;
            m = c.template(f)
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.SuggestionTypes", "sx.iss.TemplateEngine").build("sx.iss.WidgetDisplayProvider", function(d, a, c) {
        return function() {
            this.getDisplay = function(d) {
                return d && d.type && d.type.name && d.type.name === a.WidgetSuggestion.name ? c.template(d.template, d) : null
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils", "sx.iss.TemplateEngine").build("sx.iss.IssDisplayProvider", function(d, a) {
        return function(c, e, f, b) {
            var g = a.template(c),
                m = 0;
            d.eventBus.listen([b.parentFocused, b.searchTermChanged], function(a) {
                d.eventBus.trigger(b.suggestionsNeeded, a)
            }, this).listen(b.suggestionsReady, function(a) {
                var c = function(a) {
                        var b = {
                            "\x26": "\x26amp;",
                            "\x3c": "\x26lt;",
                            "\x3e": "\x26gt;",
                            '"': "\x26quot;",
                            "'": "\x26#39;",
                            "/": "\x26#x2F;"
                        };
                        return String(a).replace(/[&<>"'\/]/g, function(a) {
                            return b[a]
                        })
                    }(a.searchTerm),
                    l, n, p, t = m++;
                d.timingProvider.startTimer("IssDisplayProvider", t);
                n = e.sequence(a);
                for (a = 0; a < n.length; a++) {
                    n[a].suggestionId = "issDiv" + a;
                    for (l =
                        0; l < f.length && !(p = f[l].getDisplay(n[a])); l++);
                    n[a].display = p;
                    p = r
                }
                p = g({
                    suggestions: n
                });
                d.timingProvider.stopTimer("IssDisplayProvider", t);
                d.eventBus.trigger(b.suggestionsReadyForDisplay, {
                    searchTerm: c,
                    display: p,
                    suggestions: n
                })
            }, this)
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.Platform", "sx.iss.DebugUtils").build("sx.iss.NavConfigProvider", function(d, a, c, e) {
        return function(f) {
            function b() {
                var b = (f.protocol || g.parent.document.location.protocol || "http") + "//" + a.extractDomainFromUrl(f.src) + "/suggestions/nav_config/2017?client\x3damazon-search-ui\x26",
                    e = "";
                d.each({
                    mkt: f.mkt,
                    r: f.requestId,
                    s: f.sessionId,
                    c: f.customerId,
                    p: f.pageType,
                    l: f.language,
                    sv: c.name
                }, function(a, b) {
                    e += a + "\x3d" + b + "\x26"
                });
                return b + e
            }

            function u(a) {
                a && d.extend(f, {
                    weblabs: a.weblabTreatments
                });
                g.$Nav.publish("sx.iss.navready", f)
            }

            function m(a, b) {
                a = "iss:nav_config:" + a;
                k && k(a, (k(a) || 0) + b)
            }
            var k = g.ue && "function" === typeof g.ue.count && g.ue.count,
                h = "function" === typeof g.uet && g.uet,
                l = "function" === typeof g.uex && g.uex;
            (function() {
                "undefined" === typeof g.iss && (g.iss = {});
                if (f && f.disableNavConfigFetch) e.logDebugWithTrace("Disable Nav Config request"),
                    u(r);
                else {
                    m("ajax:init", 1);
                    h && h("bb", "navConfigAjax:success", {
                        wb: 1
                    });
                    h && h("bb", "navConfigAjax:failure", {
                        wb: 1
                    });
                    var a = b();
                    e.logDebugWithTrace("Issuing Nav config requests");
                    d.ajax({
                        url: a,
                        cache: !1,
                        dataType: "json",
                        timeout: 2E3,
                        success: function(a) {
                            h && h("cf", "navConfigAjax:success", {
                                wb: 1
                            });
                            m("ajax:success", 1);
                            u(a);
                            e.logDebugWithTrace("Successfully retrieved Nav config");
                            h && h("be", "navConfigAjax:success", {
                                wb: 1
                            });
                            l && l("ld", "navConfigAjax:success", {
                                wb: 1
                            })
                        },
                        error: function(a, b, c) {
                            h && h("cf", "navConfigAjax:failure", {
                                wb: 1
                            });
                            m("ajax:error", 1);
                            b && m("ajax:error:" + b, 1);
                            g.ueLogError && (g.ueLogError({
                                logLevel: "WARN",
                                attribution: "iss-nav-config",
                                message: "ISS Nav config call failed with responseText: " + (a && a.responseText) + ", pageType: " + (f && f.pageType) + ", status: " + b + ", error:" + c
                            }), u(r), e.logDebugWithTrace("Failed to retrieve Nav config"), h && h("be", "navConfigAjax:failure", {
                                wb: 1
                            }), l && l("ld", "navConfigAjax:failure", {
                                wb: 1
                            }))
                        }
                    })
                }
            })();
            return {
                getWeblabTreatment: function(a) {
                    return f && f.weblabs && f.weblabs[a] ? f.weblabs[a] : "C"
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.Platform", "sx.iss.Events", "sx.iss.SuggestionTypes").build("sx.iss.ISSAjaxUrlProvider", function(d, a, c, e, f, b) {
        return function(f) {
            function m(m, h) {
                var l = (f.protocol || g.parent.document.location.protocol || "http:") + "//" + a.extractDomainFromUrl(f.src) + "/api/2017/suggestions?",
                    n = {
                        "session-id": f.sessionId,
                        "customer-id": f.customerId,
                        "request-id": f.requestId,
                        "page-type": f.pageType,
                        lop: f.language,
                        "site-variant": e.name,
                        "client-info": e.cid
                    };
                f.obfMkt ?
                    n.mid = f.obfMkt : f.mkt && (n["plain-mid"] = f.mkt);
                c && "function" === typeof c.getAliasFromDropdown && (n.alias = c.getAliasFromDropdown(f));
                m && d.each(m, function(a, b) {
                    n[a] = b
                });
                h && Array.isArray(h) ? n["suggestion-type"] = h : n["suggestion-type"] = b.KeywordSuggestion.name;
                return l + d.param(n, !0)
            }
            return {
                buildUrl: function(a, b) {
                    return m(a, b)
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.Platform", "sx.iss.Events").build("sx.iss.AjaxCallProvider", function(d, a, c, e) {
        return function(a, b, c) {
            function e(a, c) {
                a = b + ":" + a;
                k && k(a, (k(a) || 0) + c)
            }
            var k = g.ue && "function" === typeof g.ue.count && g.ue.count,
                h = "function" === typeof g.uet && g.uet,
                l = "function" === typeof g.uex && g.uex;
            e("init", 1);
            var n = !1,
                p = "json",
                t = 2E3;
            c && (n = c.cache ? !0 : !1, p = c.dataType ? c.dataType : "json", t = c.timeout ? c.timeout : 2E3);
            return {
                callService: function(c, k, u) {
                    e("ajax:init", 1);
                    h && h("bb", b + ":success", {
                        wb: 1
                    });
                    h && h("bb", b + ":failure", {
                        wb: 1
                    });
                    d.ajax({
                        url: c,
                        cache: n,
                        dataType: p,
                        timeout: t,
                        success: function(a) {
                            h && h("cf", b + ":success", {
                                wb: 1
                            });
                            e("ajax:success", 1);
                            "function" === typeof k &&
                                k(a);
                            h && h("be", b + ":success", {
                                wb: 1
                            });
                            l && l("ld", b + ":success", {
                                wb: 1
                            })
                        },
                        error: function(c, d, k) {
                            h && h("cf", b + ":failure", {
                                wb: 1
                            });
                            e("ajax:error", 1);
                            d && e("ajax:error" + d, 1);
                            g.ueLogError && g.ueLogError({
                                logLevel: "WARN",
                                attribution: b,
                                message: "ISS AJAX call failed for " + b + " with responseText: " + (c && c.responseText) + ", pageType: " + (a && a.pageType) + ", status: " + d + ", error: " + k
                            });
                            "function" === typeof u && u();
                            h && h("be", b + ":failure", {
                                wb: 1
                            });
                            l && l("ld", b + ":failure", {
                                wb: 1
                            })
                        }
                    })
                },
                incrementCsmCount: e
            }
        }
    });
    "use strict";
    g.$Nav.when("$",
        "sx.iss.utils", "NavDomApi", "sx.iss.DebugUtils").build("sx.iss.BIAProvider", function(d, a, c, e) {
        return function(a) {
            var b = a.biaPurchasedText;
            return {
                getName: function() {
                    return "bia"
                },
                parseBIAResponse: function(a) {
                    var d = a.suggestions.filter(function(a) {
                        return a && "BUY_IT_AGAIN" === a.type
                    });
                    if (!(0 >= d.length)) {
                        for (var f = [], h = 0; h < d.length; h++) {
                            var g = {
                                type: "bia",
                                dp: "/dp/" + d[h].value + "/ref\x3d" + d[h].refTag + "?crid\x3d" + a.responseId,
                                title: d[h].asinTitle,
                                price: d[h].displayPrice,
                                image: d[h].imageUrl,
                                purchaseDate: d[h].purchaseDateDisplay,
                                purchasedText: b
                            };
                            "amazonfresh" === a.alias && (g.dp += "\x26ppw\x3dfresh");
                            f.push(g)
                        }
                        if ((d = c.getSearchBox().val()) && 0 !== d.length && d === a.prefix & 0 < f.length) return e.logDebug("BIA asins exist for given prefix: ", a, f), f;
                        1 > f.length && e.logDebug("No BIA ASINs for given prefix", a)
                    }
                }
            }
        }
    });
    "use strict";
    g.$Nav.build("sx.iss.CachingProvider.instance", function() {
        return new function() {
            var d = {};
            this.put = function(a, c, e) {
                if (!d[a] || 100 <= d[a].size) d[a] = {}, d[a].size = 0;
                d[a][c] === r && d[a].size++;
                d[a][c] = e
            };
            this.get = function(a,
                c) {
                return d[a] ? d[a][c] : r
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.SuggestionTypes", "sx.iss.Platform", "sx.iss.Events", "sx.iss.AjaxCallProvider", "sx.iss.ISSAjaxUrlProvider", "sx.iss.DebugUtils").build("sx.iss.TrendingProvider", function(d, a, c, e, f, b, g, m, k) {
        var h = e.trendSearch.name;
        return function(c, d) {
            function f(c) {
                for (var g = [], k = 0; k < c.suggestions.length; ++k) g.push({
                    suggestionId: "trending" + k,
                    alias: c.alias,
                    keyword: c.suggestions[k].value,
                    type: e.trendSearch.name,
                    browseNodeId: r,
                    completionResponseId: c.suggestions[k].responseId,
                    bprefix: "",
                    ghost: !1,
                    highlightFragments: [{
                        isHit: !0,
                        text: c.suggestions[k].value
                    }],
                    isDeepNode: !1,
                    isFallback: !1,
                    isSpellCorrected: !1,
                    prefix: "",
                    store: r,
                    suffix: r
                });
                c = {
                    suggestionSets: {
                        trendSearch: g
                    },
                    title: "Trending Searches",
                    searchTerm: ""
                };
                g = b.createEvent(h, d.suggestionsReady);
                a.eventBus.trigger(g, c)
            }
            this.getName = function() {
                return e.trendSearch.name
            };
            var k = new g(c, "iss-trending"),
                q;
            q = new m(c);
            c = b.createEvent(h, d.suggestionsNeeded);
            a.eventBus.listen(c, function(a) {
                f.searchTerm =
                    a;
                k.callService(q.buildUrl(r, [e.TrendingSearchesSuggestion.name]), f)
            }, this);
            this.supportsRequest = function(a) {
                return !a.searchTerm
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.DebugUtils", "sx.iss.KeywordSuggestionProcessor", "sx.iss.WidgetSuggestionProcessor").build("sx.iss.EventBasedSuggestionResultsProcessor", function(d, a, c, e, f) {
        var b = g.ue && "function" === typeof g.ue.count && g.ue.count;
        return function(a) {
            return {
                processResults: function(d) {
                    var g = {};
                    if (!d || !d.suggestions) return c.logDebugWithTrace("No suggestions in the response"),
                        g;
                    var g = {
                            KeywordSuggestion: new e(a, d)
                        },
                        h = new f(a, d);
                    g.WidgetSuggestion = h;
                    for (var h = d.suggestions, l, n, p = [], t = 0; t < h.length; t++) l = h[t], (n = (n = g[l.suggType]) && n.augmentSuggestion(l)) ? (p.push(n), b && b("iss-suggestion-processor:dropped", 0)) : (c.logDebugWithTrace("Parsing the suggestions encountered an error", l), b && b("iss-suggestion-processor:dropped", 1));
                    return g = {
                        augmentedSuggestions: p,
                        suggestionTitleId: d.suggestionTitleId
                    }
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.SuggestionTypes",
        "sx.iss.DebugUtils").build("sx.iss.KeywordSuggestionProcessor", function(d, a, c, e, f) {
        var b = g.ue && "function" === typeof g.ue.count && g.ue.count;
        return function(d, g) {
            function k(a) {
                if (a && a.value && a.value.length) {
                    b && b("iss-suggestion-processor:keyword:valid-content", 1);
                    if (!d.noXcats && a.scopes && a.scopes.length && "ALIAS" == a.scopes[0].type && a.scopes[0].display && a.scopes[0].display.length && a.scopes[0].value && a.scopes[0].value.length) {
                        b && b("iss-suggestion-processor:keyword:suppressed-xcat", 0);
                        var c = h(a);
                        c.type =
                            e.a9Xcat.name;
                        c.store = a.scopes[0].display;
                        c.alias = a.scopes[0].value;
                        c.url = l(a.value, c.alias);
                        return c
                    }
                    b && b("iss-suggestion-processor:keyword:suppressed-xcat", 1);
                    c = h(a);
                    c.type = e.a9.name;
                    c.alias = p;
                    c.store = r;
                    c.url = l(a.value, c.alias);
                    return c
                }
                b && b("iss-suggestion-processor:keyword:valid-content", 0)
            }

            function h(b) {
                var c, f, e;
                c = a.suggestionUtils.getPrefixPos(b.value, n);
                t ? (f = b.value, c = e = "") : b.isSpellCorrected || -1 === c ? (c = b.value, f = e = "") : (e = a.suggestionUtils.splitStringForDisplay(b.value, c, n.length || 0), c = e.bprefix,
                    f = e.prefix, e = e.suffix);
                var h = b.value,
                    k = b.spellCorrected,
                    p = b.fallback,
                    l = b.highlightFragments,
                    r = {};
                d.useServiceHighlighting ? r = l && l.length && !t ? l : [{
                    isHit: !1,
                    text: c
                }, {
                    isHit: !0,
                    text: f
                }, {
                    isHit: !1,
                    text: e
                }] : t || (r = [{
                    isHit: !1,
                    text: c
                }, {
                    isHit: !0,
                    text: f
                }, {
                    isHit: !1,
                    text: e
                }]);
                return {
                    keyword: h,
                    bprefix: c,
                    prefix: f,
                    suffix: e,
                    isSpellCorrected: k,
                    isFallback: p,
                    highlightDisabled: t,
                    highlightFragments: r,
                    browseNodeId: "",
                    qu: {},
                    ghost: b.ghost,
                    refTag: b.refTag,
                    completionResponseId: g.responseId
                }
            }

            function l(a, b) {
                a = "/s?k\x3d" + encodeURIComponent(a);
                typeof b !== r && (a += "\x26i\x3d" + encodeURIComponent(b));
                return a
            }
            if (g) {
                var n = g.prefix,
                    p = c.getAliasFromDropdown() || "aps",
                    t = a.isHighlightDisabledForAPIV2(g.suggestions);
                return {
                    augmentSuggestion: k
                }
            }
            f.logDebugWithTrace("Service response is empty")
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "sx.iss.SuggestionTypes", "sx.iss.DebugUtils", "sx.iss.TemplateEngine").build("sx.iss.WidgetSuggestionProcessor", function(d, a, c, e, f) {
        var b = g.ue && "function" === typeof g.ue.count && g.ue.count;
        return function(g, m) {
            return {
                augmentSuggestion: function(k) {
                    var h;
                    d("#" + k.template).length ? h = !0 : (e.logDebugWithTrace("Suggestion template does not exist or is not installed with an id in the HTML equal to the template id: " + k.template), h = !1);
                    if (!h) return b && b("iss-suggestion-processor:widget:valid-content", 0), null;
                    b && b("iss-suggestion-processor:widget:valid-content", 1);
                    h = {
                        type: c.WidgetSuggestion,
                        keyword: k.value,
                        refTag: k.refTag,
                        widgetId: k.widgetId,
                        template: k.template,
                        metadata: d.extend({}, k.metadata),
                        widgetItems: []
                    };
                    for (var l in k.widgetItems) h.widgetItems.push({
                        id: k.widgetItems[l].id,
                        type: k.widgetItems[l].type,
                        metadata: d.extend({}, k.widgetItems[l].metadata)
                    });
                    "promoted-suggestion" === h.template && (k = k.widgetItems[0].metadata, h.searchTerm = m.prefix, h.keyword = k.text, h.serviceHighlighting = k.serviceHighlighting ? k.serviceHighlighting : [], h.isHighlightDisabled = k.isHighlightDisabled ? !0 : !1, h.useServiceHighlighting = g.useServiceHighlighting, h.isSpellCorrected = !1, h.highlightFragments = a.suggestionUtils.buildHighlightFragments(h));
                    var n;
                    a: {
                        try {
                            f.templateWithOptions(h.template, {
                                allowUndefined: !1,
                                allowMalformedHtml: !1
                            }, h);
                            n = !0;
                            break a
                        } catch (p) {
                            e.logDebugWithTrace("Suggestion template " + h.template + " failed with suggestion " + JSON.stringify(h))
                        }
                        n = !1
                    }
                    if (!n) return b && b("iss-suggestion-processor:widget:template-filled", 0), b && b("iss-suggestion-processor:widget:" + h.widgetId + ":filled", 0), b && b("iss-suggestion-processor:widget:" + h.template + ":filled", 0), null;
                    b && b("iss-suggestion-processor:widget:template-filled", 1);
                    b && b("iss-suggestion-processor:widget:" + h.widgetId + ":filled", 1);
                    b && b("iss-suggestion-processor:widget:" +
                        h.template + ":filled", 1);
                    return h
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils").build("sx.iss.A9SearchSuggestionEventHandler", function(d) {
        return function(a) {
            var c;
            this.getDelegateReqs = function() {
                return {
                    selectors: ".a9_suggestion,.suggestion_with_query_builder,.cross_category_suggestion",
                    events: "click"
                }
            };
            this.handleEvent = function(e) {
                var f = e.target || e.srcElement;
                e = parseInt(e.currentTarget.id.substr(6), 10);
                f.className && -1 !== f.className.indexOf("suggest_builder") ? d.eventBus.trigger(a.updateSearchTerm, c.suggestions[e].keyword) :
                    d.eventBus.trigger(a.suggestionClicked, c.suggestions[e])
            };
            d.eventBus.listen(a.suggestionsDisplayed, function(a) {
                c = a
            }, this)
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils").build("sx.iss.RecentSearchSuggestionEventHandler", function(d) {
        return function(a) {
            function c(b) {
                var c, f, e, h;
                c = location.protocol + "//" + location.host + b.deleteUrl;
                f = g.sx.searchsuggest.searchedText;
                for (e = 0; e < f.length; e++)
                    if (f[e].keywords === b.originalKeywords) {
                        h = e;
                        break
                    } - 1 !== h && f.splice(h, 1);
                d.eventBus.trigger(a.focusOnParent);
                var l;
                g.XMLHttpRequest ?
                    l = new XMLHttpRequest : g.ActiveXObject && (l = new ActiveXObject("Microsoft.XMLHTTP"));
                if (l && c) try {
                    l.open("GET", c, !0), l.send(null)
                } catch (n) {}
            }
            var e = this,
                f;
            this.getDelegateReqs = function() {
                return {
                    selectors: ".recent_search_suggestion",
                    events: "click"
                }
            };
            this.handleEvent = function(b) {
                var g = b.target || b.srcElement;
                b = parseInt(b.currentTarget.id.substr(6), 10);
                g.className && -1 !== g.className.indexOf("iss_sh_delete") ? c.call(e, f.suggestions[b]) : d.eventBus.trigger(a.suggestionClicked, f.suggestions[b])
            };
            d.eventBus.listen(a.suggestionsDisplayed,
                function(a) {
                    f = a
                }, this)
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.DomUtils", "sx.iss.DebugUtils", "sx.iss.SuggestionTypes", "sx.iss.Events").build("sx.iss.BIASuggestionEventHandler", function(d, a, c, e, f, b, g) {
        return function(a, b, c) {
            c.delegate(".s-asin-sug-link", "mouseover", function(a) {
                d(a.currentTarget).find(".s-asin-sug-image").css("opacity", "0.5")
            }).delegate(".s-asin-sug-link", "mouseout", function(a) {
                d(a.currentTarget).find(".s-asin-sug-image").css("opacity", "1.0")
            })
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.DomUtils", "sx.iss.DebugUtils", "sx.iss.SuggestionTypes", "sx.iss.Events").build("sx.iss.QUSuggestionEventHandler", function(d, a, c, e, f, b, g) {
        var m = b && b.qu && b.qu.name,
            k = {
                AUTHOR: "field-author"
            };
        return function(b, g, n) {
            n.delegate(".s-qu-suggestion", "mouseover", function(a) {
                e.hoverOverEl(d(a.currentTarget))
            }).delegate(".s-qu-suggestion", "mouseout", function(a) {
                e.hoverOverEl(d(a.currentTarget))
            });
            a.eventBus.listen(g.searchBoxUpdated, function(a) {
                f.logDebug("searchBox updated event",
                    a);
                var b = a.attr("data-type") || "";
                if ("" !== b && b === m) {
                    var b = a.attr("data-qu-type"),
                        e = a.attr("data-qu-value"),
                        b = b || "",
                        e = e || "";
                    if ("" !== b && "" !== e) {
                        var g = c.getIssFieldRestrictionElem();
                        g && 0 < g.length && g.remove();
                        b = d('\x3cinput type\x3d"hidden" /\x3e').attr("id", "issFieldRestriction").attr("name", k[b]).attr("value", e);
                        c.getForm().append(b)
                    }
                    a = a.attr("data-keyword") || "";
                    0 < (c.getIssFieldRestrictionElem() || "").length && 1 > a.length && c.getSearchBox().val("")
                }
            })
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi",
        "sx.iss.ReftagBuilder", "sx.iss.DebugUtils", "sx.iss.SuggestionTypes", "sx.iss.Events").build("sx.iss.GhostSuggestionEventHandler", function(d, a, c, e, f, b, g) {
        var m = /(ref=[\-\w]+)/,
            k = [a.uiKeycode.BACKSPACE, a.uiKeycode.DELETE, a.uiKeycode.DOWN, a.uiKeycode.END, a.uiKeycode.ENTER, a.uiKeycode.ESCAPE, a.uiKeycode.HOME, a.uiKeycode.LEFT, a.uiKeycode.PAGE_DOWN, a.uiKeycode.PAGE_UP, a.uiKeycode.RIGHT, a.uiKeycode.TAB, a.uiKeycode.UP];
        return function(b, d) {
            function g(a) {
                if ("object" !== typeof a || "string" !== typeof a.searchTerm ||
                    a.inputcopyselect || !Array.isArray(a.suggestions)) return !1;
                var b = a.suggestions || [];
                return -1 < k.indexOf(a.keystroke) || b === [] || b[0] === r ? !1 : (a = b[0]) && a.ghost
            }
            var p = !1;
            c.getDropdown();
            var t = c.getSearchBox(),
                q = c.getForm();
            a.eventBus.listen(d.suggestionsRendered, function(a) {
                if (g(a)) {
                    f.logDebug("renderGhostSuggestion: ", a);
                    var b = a.searchTerm,
                        d = c.getKeyword();
                    b && d && b === d ? (b = b.length, a = a.suggestions[0].keyword, d = a.length, t.val(a), t.focus(), t[0].setSelectionRange(b, d), p = !0) : p = !1
                } else p = !1
            });
            a.eventBus.listen(d.reftagUpdatedAfterRender,
                function(a) {
                    if (g(a) && p) {
                        a = a.searchTerm;
                        a = {
                            suggestion: c.getDropdown().find(".s-suggestion").first(),
                            searchTerm: a,
                            previousSearchTerm: ""
                        };
                        a = (new e).build(a, !1);
                        var b = q.attr("action");
                        m.test(b) ? b = b.replace(m, e.CONSTANTS.reftagBase + a) : ("/" !== b.charAt(b.length - 1) && (b += "/"), b += a);
                        q.attr("action", b)
                    }
                })
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.utils", "NavDomApi", "sx.iss.SuggestionTypes", "sx.iss.ReftagBuilder").build("sx.iss.HelpSuggestionClickedUtil", function(d, a, c, e, f) {
        var b = /(ref=[\-\w]+)/;
        return function(a,
            f) {
            this.modifyForm = function(a) {
                if (a && a.keyword) {
                    c.getIssPrefixElem().remove();
                    c.getIssBrowseNodeIdElem().remove();
                    c.getIssFieldRestrictionElem().remove();
                    c.getIssCridElem().remove();
                    var f = c.getForm();
                    f.attr("action");
                    var e;
                    e = f.attr("action");
                    e = b.exec(e);
                    e = Array.isArray(e) && e[1] ? e[1] : "";
                    f.attr("action", "/gp/help/customer/display.html/" + e);
                    a = d('\x3cinput type\x3d"hidden" /\x3e').attr("id", "iss-help-keywords").attr("name", "help_keywords").attr("value", a.keyword);
                    f.append(a)
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils",
        "sx.iss.Events", "sx.iss.MetricsLoggerMobile").build("sx.iss.SuggestionAggregator", function(d, a, c) {
        return function(e, f, b) {
            function g(a) {
                var c = k[a.searchTerm];
                if (a.suggestions && a.suggestions[0] && a.suggestions[0].type && (c.suggestionsSets[a.suggestions[0].type] = a, "a9" === a.suggestions[0].type))
                    for (var e = c.suggestionsSets.a9.suggestions, h = 0; h < e.length; h++) e[h].scope && (e[h].type = "a9xc");
                --c.remaining || (delete k[c.searchTerm], b && b.isISSmWebRefactorEnabled && (c.suggestionsSets = a.suggestionSets), d.eventBus.trigger(f.suggestionsReady,
                    c))
            }
            for (var m = new c, k = {}, h = 0; h < e.length; h++) {
                var l = a.createEvent(e[h], f.suggestionsReady);
                d.eventBus.listen(l, g, this)
            }
            d.eventBus.listen(f.suggestionsNeeded, function(c) {
                var g;
                b && b.isISSmWebRefactorEnabled ? g = c.searchTerm : (g = c, c = {
                    searchTerm: g
                });
                m.startEndToEndLogging();
                if (!k[g])
                    for (k[g] = {
                            remaining: e.length,
                            searchTerm: g,
                            suggestionsSets: {}
                        }, g = 0; g < e.length; g++) {
                        var h = a.createEvent(e[g], f.suggestionsNeeded);
                        d.eventBus.trigger(h, c)
                    }
            }, this)
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.utils").build("sx.iss.SuggestionSequencerMobile",
        function(d) {
            return function(a) {
                this.sequence = function(c) {
                    if (a && a.isISSmWebRefactorEnabled) return c.suggestionsSets;
                    var e = c.suggestionsSets,
                        f = e.recent;
                    c = e.a9;
                    var b = e.crossCategory,
                        e = c && c.suggestions && 0 < c.suggestions.length ? c.suggestions.length : 0,
                        g = b && b.suggestions && 0 < b.suggestions.length ? b.suggestions.length : 0,
                        m = d.numSuggestions.MOBILE,
                        k, h, l = [],
                        n = {};
                    k = Math.min(f && f.suggestions && 0 < f.suggestions.length ? f.suggestions.length : 0, 0 < e ? 2 : 6);
                    for (h = 0; h < g; h++) l.push(b.suggestions[h]);
                    for (h = 0; h < k; h++) n[f.suggestions[h].keyword] = !0, l.push(f.suggestions[h]);
                    f = Math.min(e, m - l.length);
                    for (b = h = 0; h < e && b < f; h++) n[c.suggestions[h].keyword] || (b++, l.push(c.suggestions[h]));
                    for (h = 0; h < l.length; h++) l[h].dispIdx = h;
                    return l
                }
            }
        });
    "use strict";
    g.$Nav.when("sx.iss.utils", "sx.iss.Events", "sx.iss.MetricsTags", "sx.iss.CSMLogger").build("sx.iss.MetricsLoggerMobile", function(d, a, c, e) {
        return function(a) {
            var b = a || e;
            return {
                startEndToEndLogging: function() {
                    b.isEnabled() && b.uet(c.BODY_BEGIN, c.A9_END_TO_END_MOBILE, c.CUSTOM_WIDGET_OBJ)
                },
                stopEndToEndLogging: function() {
                    b.isEnabled() &&
                        (b.uet(c.CRITICAL_FEATURE, c.A9_END_TO_END_MOBILE, c.CUSTOM_WIDGET_OBJ), b.uet(c.BODY_END, c.A9_END_TO_END_MOBILE, c.CUSTOM_WIDGET_OBJ), b.uex(c.PAGE_LOAD, c.A9_END_TO_END_MOBILE, c.CUSTOM_WIDGET_OBJ))
                }
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils").build("sx.iss.MetricsTags", function() {
        return {
            INIT: "iss-init-pc",
            A9_END_TO_END: "iss-end-to-end-a9",
            A9_END_TO_END_MOBILE: "iss-end-to-end-a9-mobile",
            CRITICAL_FEATURE: "cf",
            BODY_END: "be",
            BODY_BEGIN: "bb",
            PAGE_LOAD: "ld",
            CUSTOM_WIDGET_OBJ: {
                wb: 1
            }
        }
    });
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils").build("sx.iss.CSMLogger",
        function(d) {
            var a = "function" === typeof uet && "function" === typeof uex;
            return {
                isEnabled: function() {
                    return a
                },
                uet: function() {
                    a ? uet.apply(this, arguments) : d.logDebugWithTrace("UET is undefined, unable to call with arguments: ", arguments)
                },
                uex: function() {
                    a ? uex.apply(this, arguments) : d.logDebugWithTrace("UEX is undefined, unable to call with arguments: ", arguments)
                },
                ue: function() {
                    a ? ue.apply(this, arguments) : d.logDebugWithTrace("UE is undefined, unable to call with arguments: ", arguments)
                }
            }
        });
    "use strict";
    g.$Nav.when("$",
        "sx.iss.utils", "sx.iss.Events", "sx.iss.MetricsLoggerMobile").build("sx.iss.IssParentCoordinatorMobile", function(d, a, c, e) {
        return function(c, b, u, m, k) {
            function h(a) {
                return a.charCode ? a.target.value + String.fromCharCode(a.charCode) : a.target.value
            }

            function l() {}

            function n() {
                A && (A.remove(), A = r)
            }

            function p(a, b) {
                if (a && 0 < a.length) a.attr("value", b.value);
                else if (b.hasOwnProperty("value") && b.value) {
                    a = d("\x3cinput\x3e");
                    for (var c in b) b.hasOwnProperty(c) && a.attr(c, b[c]);
                    a.appendTo(w)
                }
            }

            function t(a) {
                a = a || [];
                a.forEach(function(a) {
                    a &&
                        0 < a.length && w[0].removeChild(a[0])
                })
            }

            function q() {
                var a = document.getElementById("issprefix"),
                    b = document.getElementById("issAlias");
                return A ? (D = setTimeout(function() {
                    D = null;
                    n();
                    a && w[0].removeChild(a);
                    b && w[0].removeChild(b)
                }, 300), !1) : !0
            }

            function x() {
                g.setTimeout(function() {
                    c.focus()
                }, 0)
            }

            function v(b) {
                m && m.isISSmWebRefactorEnabled ? a.eventBus.triggerThrottledEvent(k.searchTermChanged, {
                    searchTerm: z,
                    event: k.onKeyPress.name,
                    keystroke: b && b.keyCode
                }, 100) : a.eventBus.triggerThrottledEvent(k.searchTermChanged,
                    z, 100)
            }

            function y(b) {
                if ("focus" === b.type) {
                    E = !0;
                    if (null == m.autoScroll || m.autoScroll) {
                        var c = C.offset();
                        g.scrollTo(0, c.top)
                    }
                    D && (clearTimeout(D), D = null);
                    z = h(b);
                    m && m.isISSmWebRefactorEnabled ? a.eventBus.trigger(k.parentFocused, {
                        searchTerm: z,
                        event: z && "" !== z ? k.onFocusWithSearchTerm.name : k.onFocusEmptySearchTerm.name,
                        keystroke: b.keyCode
                    }) : a.eventBus.trigger(k.parentFocused, z)
                } else "keyup" === b.type && (13 === b.keyCode ? n() : 27 === b.keyCode ? q() : (B = z = h(b), v(b)))
            }
            var E, A, w, C, D = null,
                B, z, G = m.implicitAlias,
                F = m.issXCat,
                H = !1,
                I = new e;
            C = d(c);
            c = d(c);
            b = b ? d(b) : c.parent();
            w = c.closest("form");
            u = u || [];
            B = c.val();
            c.bind("focus", this, y).bind("keyup", this, y);
            d(document).ready(function() {
                C.is(":focus") && C.trigger("focus", "norefresh")
            });
            d(document.body).bind("click", this, function(b) {
                var e = d(b.target || b.srcElement),
                    g = e.hasClass("suggest_builder"),
                    e = e.hasClass("iss_sh_delete");
                "click" !== b.type || document.activeElement == c[0] || e || g || (E = !1, a.eventBus.trigger(k.parentLostFocus), q())
            });
            d(document).bind("searchAjaxTransition", this, n);
            g.setInterval(function() {
                var a = c.val();
                a !== z && (z = B = a, v())
            }, 20);
            a.eventBus.listen(k.suggestionsReadyForDisplay, function(c) {
                var e, f;
                if (E && c && z === c.searchTerm.replace(/&amp;/g, "\x26").replace(/&lt;/g, "\x3c").replace(/&gt;/g, "\x3e").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x2F;/g, "/"))
                    if (c.suggestions && 0 !== c.suggestions.length) {
                        e = d(c.display);
                        I.stopEndToEndLogging();
                        F && !H && (H = !0, ue.count("SEARCH:IssXCatImpression", 1));
                        if (A) A.html(e.children());
                        else
                            for (A = e, b.after(A), e = 0; e < u.length; e++) f =
                                u[e].getDelegateReqs(), A.delegate(f.selectors, f.events, u[e], function(a) {
                                    return a.data.handleEvent(a)
                                });
                        d(g).resize(l);
                        a.eventBus.trigger(k.suggestionsDisplayed, c)
                    } else n()
            }, this).listen(k.suggestionClicked, function(a) {
                var b;
                b = m && m.isISSmWebRefactorEnabled ? a.crid : a.completionResponseId;
                c.val(a.keyword);
                z = a.keyword;
                t([d("input[name\x3d'crid']"), d("input[name\x3d'sprefix']")]);
                var e, g = B,
                    h = a.dispIdx;
                if (0 <= h || m && m.isISSmWebRefactorEnabled) {
                    a.spellCor ? e = "ss_sc" : "recent" === a.type ? e = "ss_sh" : F ? "a9xc" === a.type ?
                        e = "aps" === a.scope ? "ss_c_aw_aps" : "ss_c_aw_cat" : (a.scope = G, e = "ss_i") : e = "crossCategory" === a.type ? "aps" === a.scope ? "ss_c_aw_aps" : "ss_c_aw_cat" : "ss_i";
                    F && "a9xc" === a.type ? ue.count("SEARCH:IssXCatClick", 1) : F && ue.count("SEARCH:IssTopCatClick", 1);
                    if (F) {
                        var k = a.scope ? a.scope : G,
                            l;
                        "a9xc" === a.type && F && ((l = d("input[name\x3d'n']")) && 0 < l.length && p(l, {
                            value: "",
                            name: "n",
                            type: "hidden"
                        }), (l = d("input[name\x3d'bbn']")) && 0 < l.length && p(l, {
                            value: "",
                            name: "bbn",
                            type: "hidden"
                        }), (l = d("input[name\x3d'srs']")) && 0 < l.length && p(l, {
                            value: "",
                            name: "srs",
                            type: "hidden"
                        }));
                        p(d("#issAlias"), {
                            value: "i:" + k,
                            name: "rh",
                            type: "hidden"
                        });
                        (l = d("input[name\x3d'search-alias']")) && 0 < l.length && p(l, {
                            value: k,
                            name: "search-alias",
                            type: "hidden"
                        });
                        l = d("input[name\x3d'n']");
                        "aps" === k && l && 0 < l.length && p(l, {
                            value: "",
                            name: "n",
                            type: "hidden"
                        });
                        l = d("input[name\x3d'srs']");
                        "aps" === k && l && 0 < l.length && p(l, {
                            value: "",
                            name: "srs",
                            type: "hidden"
                        });
                        l = d("input[name\x3d'bbn']");
                        "aps" === k && l && 0 < l.length && p(l, {
                            value: "",
                            name: "bbn",
                            type: "hidden"
                        })
                    }
                    k = "";
                    F && a.scope && (k = a.scope);
                    l = e;
                    var n = g.length,
                        q = k;
                    e = w[0].getAttribute("action");
                    k = /(ref=[\w-]+)/;
                    h = l + "_" + h + "_" + n;
                    q && 0 < q.length && (h = h + "_" + q);
                    a = "ref\x3d" + a.refTag;
                    h = "ref\x3dnb_sb_" + h;
                    m && m.isISSmWebRefactorEnabled && (h = a);
                    k.test(e) ? e = e.replace(k, h) : ("/" != e.charAt(e.length - 1) && (e += "/"), e += h);
                    w[0].setAttribute("action", e);
                    p(d("#issprefix"), {
                        value: g,
                        name: "sprefix",
                        type: "hidden"
                    })
                }
                p(null, {
                    value: b,
                    name: "crid",
                    type: "hidden"
                });
                if (document.createEvent && (b = document.createEvent("Event"), b.initEvent("submit", !0, !0), !w[0].dispatchEvent(b))) return;
                w[0].submit()
            }, this).listen(k.focusOnParent, x, this).listen(k.updateSearchTerm, function(a) {
                z = a;
                C.val(a);
                x()
            }, this)
        }
    });
    "use strict";
    g.$Nav.importEvent("jQuery", {
        as: "$",
        global: "jQuery"
    });
    g.$Nav.when("sx.iss.Events", "sx.iss.A9SuggestionProvider", "sx.iss.EventBasedSuggestionProvider", "sx.iss.A9SearchSuggestionEventHandler", "sx.iss.RecentSearchSuggestionProvider", "sx.iss.RecentSearchSuggestionEventHandler", "sx.iss.SuggestionAggregator", "sx.iss.SuggestionSequencerMobile", "sx.iss.SuggestionDisplayProvider",
        "sx.iss.IssDisplayProvider", "sx.iss.IssParentCoordinatorMobile").build("sx.iss", function(d, a, c, e, f, b, g, m, k, h, l) {
        return {
            Events: d,
            A9SuggestionProvider: a,
            EventBasedSuggestionProvider: c,
            A9SearchSuggestionEventHandler: e,
            RecentSearchSuggestionProvider: f,
            RecentSearchSuggestionEventHandler: b,
            SuggestionAggregator: g,
            SuggestionSequencerMobile: m,
            SuggestionDisplayProvider: k,
            IssDisplayProvider: h,
            IssParentCoordinatorMobile: l
        }
    });
    g.$Nav.when("sx.iss").run(function(d) {
        g.$Nav.publish("sx.iss", d)
    });
    "use strict";
    g.$Nav.when("$",
        "sx.iss.SuggestionTypes").build("sx.iss.FilterIss", function(d, a) {
        return function(c) {
            return {
                removeFilteredAliases: function(e) {
                    c.filterAliases && e[a.a9Xcat.name] && (e[a.a9Xcat.name] = d.grep(e[a.a9Xcat.name], function(a) {
                        return -1 === d.inArray(a.alias, c.filterAliases)
                    }));
                    return e
                }
            }
        }
    });
    (function(d) {
        g.$Nav.when("config", "sx.iss.DebugUtils", "sx.iss.SuggestionTypes").run("initISS", function(a, c, d) {
            if ("undefined" !== typeof a && a && a.searchISS) {
                var f = a.searchISS;
                f.isInternal && c.init(g.location.search);
                var b = f.cxNoiseReductionTreatment;
                g.P && g.P.AUI_BUILD_DATE && g.P.when("A", "sx.iss", "load").execute("initNavISS", function(a, c) {
                    var k = document.getElementById("nav-search-keywords"),
                        h = document.getElementById("search-ac-init-data"),
                        l = document.getElementById("nav-search-keywords-data"),
                        n = [],
                        p = 1 === f.isInIssXCatWeblabTreatment,
                        t = 0 === f.autoScrollUpSearchBoxTreatment ? !1 : !0,
                        q = "",
                        r = "";
                    p && (g.ue.count("SEARCH:IssImpression", 1), q = (r = a.state("NAV:Constants")) && r.aa_searchBox_in ? r.aa_searchBox_in + " " : "in ", r = r && r.aa_all_departments ? r.aa_all_departments +
                        " " : "All Departments ");
                    if (h) {
                        l = l.getAttribute("data-implicit-alias") || "aps";
                        a = k.getAttribute("placeholder");
                        h = {
                            aliases: f.aliases,
                            ime: h.getAttribute("data-ime"),
                            mkt: f.mktID,
                            src: h.getAttribute("data-src"),
                            implicitAlias: l,
                            noXcats: !0,
                            placeholder: a,
                            issPrimeEligible: n,
                            issXCat: p,
                            autoScroll: t,
                            searchboxSearchInMessage: q,
                            apsName: r,
                            host: f.host,
                            sessionId: f.sessionId,
                            requestId: f.requestId,
                            customerId: f.customerId,
                            language: f.language,
                            pageType: f.pageType,
                            useApiV2Mobile: f.useApiV2Mobile,
                            isISSmWebRefactorEnabled: f.isISSmWebRefactorEnabled
                        };
                        g.ue && g.uet("bb", "iss-init-aw", {
                            wb: 1
                        });
                        if (!g.initAutocomplete) {
                            g.initAutocomplete = !0;
                            t = "";
                            p && (t = "\x3cdiv class\x3d'suggest_delete suggest_builder'\x3e\x3c/div\x3e");
                            p = "suggest_link";
                            n = "suggestions";
                            q = "\x3c#\x3d bprefix #\x3e\x3cb\x3e\x3c#\x3d prefix #\x3e\x3c/b\x3e\x3c#\x3d suffix #\x3e\x3c/span\x3e\x3c/div\x3e";
                            b && (p = "suggest_link2", n = "suggestions2", q = "\x3cb\x3e\x3c#\x3d bprefix #\x3e\x3c/b\x3e\x3c#\x3d prefix #\x3e\x3cb\x3e\x3c#\x3d suffix #\x3e\x3c/span\x3e\x3c/b\x3e\x3c/div\x3e");
                            t = "\x3cdiv id\x3d'\x3c#\x3d suggestionId #\x3e'class\x3d'suggest_row a9_suggestion'\x3e\x3cdiv class\x3d'" +
                                p + "' dir\x3d'auto'\x3e\x3cspan\x3e " + q + t + "\x3c/div\x3e";
                            p = document.createElement("script");
                            p.setAttribute("type", "text/html");
                            p.setAttribute("id", "a9-suggestion-template");
                            p.innerHTML = t;
                            t = "\x3cdiv id\x3d'suggestions-template'\x3e\x3cdiv id\x3d'" + n + "' class\x3d''\x3e\x3c# if (typeof suggestions !\x3d\x3d 'undefined') { for(var i\x3d0; i \x3c suggestions.length; i++){ var displayString \x3d suggestions[i].display; #\x3e\x3c#\x3d displayString #\x3e \x3c# } } #\x3e \x3c/div\x3e \x3c/div\x3e";
                            n = document.createElement("script");
                            n.setAttribute("type", "text/html");
                            n.setAttribute("id", "suggestions-template");
                            n.innerHTML = t;
                            t = document.createElement("script");
                            t.setAttribute("type", "text/html");
                            t.setAttribute("id", "a9xc-suggestion-template");
                            t.innerHTML = "\x3cdiv id\x3d'\x3c#\x3d suggestionId #\x3e' class\x3d'suggest_row cross_category_suggestion'\x3e\x3cdiv class\x3d'suggest_link' dir\x3d'auto'\x3e \x3cspan\x3e \x3c#\x3d bprefix #\x3e\x3cb\x3e\x3c#\x3d prefix #\x3e\x3c/b\x3e\x3c#\x3d suffix #\x3e \x3c/span\x3e\x3cspan class\x3d'suggestion_search_scope'\x3e\x3c#\x3d storeText #\x3e \x3c/span\x3e\x3c/div\x3e\x3cdiv class\x3d'suggest_delete suggest_builder'\x3e\x3c/div\x3e\x3c/div\x3e";
                            q = document.getElementsByTagName("body")[0];
                            q.appendChild(p);
                            q.appendChild(n);
                            q.appendChild(t);
                            var v;
                            c.hasOwnProperty("Events") && (v = c.Events.createInstance());
                            q = new c.A9SuggestionProvider(h, v);
                            t = new c.RecentSearchSuggestionProvider(v);
                            p = [];
                            n = [];
                            f && f.isISSmWebRefactorEnabled ? (f.src = f.host, f.mkt = f.mktID, f.noXcats = !0, q = new c.EventBasedSuggestionProvider(f, v), p.push(q.getName(), t.getName()), n.push(new c.SuggestionDisplayProvider(d.a9.name, d.a9.templateId))) : (p.push(q.getName(), t.getName()), n.push(new c.SuggestionDisplayProvider("a9",
                                "a9-suggestion-template"), new c.SuggestionDisplayProvider("a9xc", "a9xc-suggestion-template")));
                            t = [new c.RecentSearchSuggestionEventHandler(v), new c.A9SearchSuggestionEventHandler(v)];
                            new c.SuggestionAggregator(p, v, f);
                            new c.IssDisplayProvider("suggestions-template", new c.SuggestionSequencerMobile(f), n, v);
                            new c.IssParentCoordinatorMobile(k, document.getElementById("nav"), t, h, v)
                        }
                        g.ue && "function" === typeof g.ue.tag && g.ue.tag(k === document.activeElement ? "iss-late-aw" : "iss-on-time-aw");
                        g.ue && (g.uet("cf", "iss-init-aw", {
                            wb: 1
                        }), g.uex("ld", "iss-init-aw", {
                            wb: 1
                        }))
                    }
                })
            }
        })
    })(g.$Nav);
    "use strict";
    g.$Nav.when("sx.iss.DebugUtils").build("sx.iss.CompletionServiceWarmupConfig", function() {
        return {
            warmUpEnabled: function(d) {
                switch (d) {
                    case "A1PA6795UKMFR9":
                    case "A2EUQ1WTGCTBG2":
                    case "A21TJRUUN4KGV":
                    case "ATVPDKIKX0DER":
                        d = !0;
                        break;
                    default:
                        d = !1
                }
                return d
            }
        }
    });
    "use strict";
    g.$Nav.when("$", "sx.iss.DebugUtils", "sx.iss.CompletionServiceWarmupConfig", "sx.iss.SuggestionTypes", "sx.iss.ISSAjaxUrlProvider", "sx.iss.AjaxCallProvider").build("sx.iss.CompletionServiceConnectionWarmer",
        function(d, a, c, e, f, b) {
            return function(d, g, k) {
                this.initConnectionToSvc = function() {
                    if (c.warmUpEnabled(g)) {
                        var h = new b(d, "iss-warmup"),
                            k = (new f(d)).buildUrl({
                                searchTerm: "a"
                            }, [e.KeywordSuggestion.name, e.WidgetSuggestion.name]);
                        h.callService(k)
                    } else a.logDebug("Warming up a connection to the completion svc is not enabled")
                }
            }
        })
});