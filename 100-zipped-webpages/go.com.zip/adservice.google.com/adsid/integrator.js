processGoogleToken({
    "newToken": "ChAI8K377AUQ2M__gqiooptUEi8AnMhKYW3TmAt5ODvndtY6RPWDNYt61Q5I16oXpR2g5xTsF35f5sMQm4OxPiLcmQ",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2019-10-10-11",
    "pucrd": ""
});