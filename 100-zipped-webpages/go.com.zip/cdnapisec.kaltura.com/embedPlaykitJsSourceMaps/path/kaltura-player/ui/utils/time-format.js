//@flow

/**
 * Formatting seconds input into time format
 *
 * @param {number} input number of seconds
 * @returns {string} formatted time string
 */
function toHHMMSS(input: number): string {
    const sec_num = parseInt(input, 10);
    let hours = Math.floor(sec_num / 3600);
    let minutes = Math.floor((sec_num - hours * 3600) / 60);
    let seconds = sec_num - hours * 3600 - minutes * 60;

    if (hours < 10) {
        hours = '0' + hours;
    }
    if (minutes < 10) {
        minutes = '0' + minutes;
    }
    if (seconds < 10) {
        seconds = '0' + seconds;
    }

    return `${hours !== '00' ? hours + ':' : ''}${minutes}:${seconds}`;
}

/**
 * Converting formatted time into seconds
 *
 * @param {string} input formatted time
 * @returns {number} number of seconds
 */
function toSecondsFromHHMMSS(input: string): number {
    const parts = input.split(':');
    let seconds = 0;
    if (parts.length === 2) {
        if (parseInt(parts[0]) > 59 || parseInt(parts[1]) > 59) {
            return 0;
        }
        seconds += parseInt(parts[0]) * 60;
        seconds += parseInt(parts[1]);
    }
    return seconds;
}

export {
    toHHMMSS,
    toSecondsFromHHMMSS
};



// WEBPACK FOOTER //
// ./utils/time-format.js


// WEBPACK FOOTER //
// ui/utils/time-format.js