export {
    CVAAOverlay
}
from './cvaa-overlay';



// WEBPACK FOOTER //
// ./components/cvaa-overlay/index.js


// WEBPACK FOOTER //
// ui/components/cvaa-overlay/index.js