export {
    PlayPauseControl
}
from './play-pause';



// WEBPACK FOOTER //
// ./components/play-pause/index.js


// WEBPACK FOOTER //
// ui/components/play-pause/index.js