export {
    SettingsControl
}
from './settings';



// WEBPACK FOOTER //
// ./components/settings/index.js


// WEBPACK FOOTER //
// ui/components/settings/index.js