export {
    LiveTag
}
from './live-tag';



// WEBPACK FOOTER //
// ./components/live-tag/index.js


// WEBPACK FOOTER //
// ui/components/live-tag/index.js