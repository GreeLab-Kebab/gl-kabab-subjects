export {
    ErrorOverlay
}
from './error-overlay';



// WEBPACK FOOTER //
// ./components/error-overlay/index.js


// WEBPACK FOOTER //
// ui/components/error-overlay/index.js