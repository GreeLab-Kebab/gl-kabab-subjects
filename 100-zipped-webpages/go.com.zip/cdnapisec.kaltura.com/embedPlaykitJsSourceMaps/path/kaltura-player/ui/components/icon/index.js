export default from './icon';
export {
    Icon,
    IconType
}
from './icon';



// WEBPACK FOOTER //
// ./components/icon/index.js


// WEBPACK FOOTER //
// ui/components/icon/index.js