export {
    Slider
}
from './slider';



// WEBPACK FOOTER //
// ./components/slider/index.js


// WEBPACK FOOTER //
// ui/components/slider/index.js