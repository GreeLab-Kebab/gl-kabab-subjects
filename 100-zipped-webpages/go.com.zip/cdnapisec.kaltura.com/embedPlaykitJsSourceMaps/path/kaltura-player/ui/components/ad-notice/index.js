export {
    AdNotice
}
from './ad-notice';



// WEBPACK FOOTER //
// ./components/ad-notice/index.js


// WEBPACK FOOTER //
// ui/components/ad-notice/index.js