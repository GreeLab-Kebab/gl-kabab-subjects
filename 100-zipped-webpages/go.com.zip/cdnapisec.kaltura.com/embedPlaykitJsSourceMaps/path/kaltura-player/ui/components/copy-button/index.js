export {
    CopyButton
}
from './copy-button';



// WEBPACK FOOTER //
// ./components/copy-button/index.js


// WEBPACK FOOTER //
// ui/components/copy-button/index.js