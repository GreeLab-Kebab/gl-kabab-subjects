export {
    VideoPlayer
}
from './video-player';



// WEBPACK FOOTER //
// ./components/video-player/index.js


// WEBPACK FOOTER //
// ui/components/video-player/index.js