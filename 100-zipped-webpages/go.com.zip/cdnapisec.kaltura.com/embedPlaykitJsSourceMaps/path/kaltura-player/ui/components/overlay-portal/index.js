export {
    OverlayPortal
}
from './overlay-portal';



// WEBPACK FOOTER //
// ./components/overlay-portal/index.js


// WEBPACK FOOTER //
// ui/components/overlay-portal/index.js