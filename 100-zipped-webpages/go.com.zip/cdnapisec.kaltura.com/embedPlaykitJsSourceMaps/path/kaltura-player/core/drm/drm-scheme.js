// @flow
export const DrmScheme = {
    WIDEVINE: 'com.widevine.alpha',
    PLAYREADY: 'com.microsoft.playready',
    FAIRPLAY: 'com.apple.fairplay'
};



// WEBPACK FOOTER //
// ./drm/drm-scheme.js


// WEBPACK FOOTER //
// core/drm/drm-scheme.js