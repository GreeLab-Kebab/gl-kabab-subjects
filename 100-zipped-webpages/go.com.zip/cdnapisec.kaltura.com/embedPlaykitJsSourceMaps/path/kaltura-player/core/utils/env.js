// @flow
import UAParser from 'ua-parser-js';
const Env = new UAParser().getResult();
export default Env;



// WEBPACK FOOTER //
// ./utils/env.js


// WEBPACK FOOTER //
// core/utils/env.js