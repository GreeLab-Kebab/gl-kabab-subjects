// @flow
const CorsType: PKCorsTypes = {
    ANONYMOUS: 'anonymous',
    USE_CREDENTIALS: 'use-credentials'
};

export {
    CorsType
};



// WEBPACK FOOTER //
// ./engines/html5/cors-types.js


// WEBPACK FOOTER //
// core/engines/html5/cors-types.js