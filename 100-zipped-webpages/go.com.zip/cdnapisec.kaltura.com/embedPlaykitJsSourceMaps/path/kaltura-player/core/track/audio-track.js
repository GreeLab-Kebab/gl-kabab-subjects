//@flow
import Track from './track';

/**
 * Audio track representation of the player.
 * @classdesc
 */
export default class AudioTrack extends Track {}



// WEBPACK FOOTER //
// ./track/audio-track.js


// WEBPACK FOOTER //
// core/track/audio-track.js