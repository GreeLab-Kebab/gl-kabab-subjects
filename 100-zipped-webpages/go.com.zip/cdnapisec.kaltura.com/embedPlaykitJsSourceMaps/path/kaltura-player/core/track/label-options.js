// @flow

const LabelOptions = {
    AUDIO: 'audio',
    CAPTIONS: 'captions',
    QUALITIES: 'qualities'
};

export {
    LabelOptions
};



// WEBPACK FOOTER //
// ./track/label-options.js


// WEBPACK FOOTER //
// core/track/label-options.js