// @flow
const AbrMode: PKAbrModes = {
    MANUAL: 'manual',
    AUTO: 'auto'
};

export {
    AbrMode
};



// WEBPACK FOOTER //
// ./track/abr-mode-type.js


// WEBPACK FOOTER //
// core/track/abr-mode-type.js