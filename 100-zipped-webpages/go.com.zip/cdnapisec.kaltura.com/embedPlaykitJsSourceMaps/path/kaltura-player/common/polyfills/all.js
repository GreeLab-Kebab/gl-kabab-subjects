import './performance-now';
import './prepend';
import 'proxy-polyfill/proxy.min.js';



// WEBPACK FOOTER //
// ./common/polyfills/all.js