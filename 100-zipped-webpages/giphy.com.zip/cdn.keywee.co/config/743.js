! function() {
    var i = {
        fbPixelId: "1204363429592640",
        domain: ".giphy.com",
        appId: 743,
        in_eu: !0,
        ping_activity: !0,
        snowplow_src: "//cdn.keywee.co/dist/sp-2.9.1.js"
    };
    window && window.kwa && window.kwa("loadConfig", i)
}();