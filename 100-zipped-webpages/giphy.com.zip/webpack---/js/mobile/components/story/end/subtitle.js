import styled from 'styled-components'

export default styled.p `
    font-size: 14px;
    font-weight: bold;
    margin: 0 0 10px;
    text-transform: capitalize;
    -webkit-font-smoothing: antialiased;
`