import styled from 'styled-components'

export default styled.h1 `
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    text-transform: capitalize;
`