export const PRELOADED_STATE_NAME = '__PRELOADED_STATE__'

export const getPreloadedState = () => global[PRELOADED_STATE_NAME]