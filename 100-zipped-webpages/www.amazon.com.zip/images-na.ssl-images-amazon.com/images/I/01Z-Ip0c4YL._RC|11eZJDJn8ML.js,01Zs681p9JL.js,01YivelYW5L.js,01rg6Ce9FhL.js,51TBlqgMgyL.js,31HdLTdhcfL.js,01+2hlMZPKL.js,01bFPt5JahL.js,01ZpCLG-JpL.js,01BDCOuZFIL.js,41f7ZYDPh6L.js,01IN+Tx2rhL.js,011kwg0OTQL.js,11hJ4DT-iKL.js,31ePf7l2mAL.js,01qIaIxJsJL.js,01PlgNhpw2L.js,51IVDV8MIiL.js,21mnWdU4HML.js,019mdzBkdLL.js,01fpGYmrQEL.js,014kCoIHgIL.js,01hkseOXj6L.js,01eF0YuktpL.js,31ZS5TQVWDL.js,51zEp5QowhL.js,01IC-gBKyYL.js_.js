(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("INSoftlinesDetailPageAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(f) {
    var e = window.AmazonUIPageJS || window.P,
        l = e._namespace || e.attributeErrors,
        a = l ? l("AmazonsChoiceAssets", "") : e;
    a.guardFatal ? a.guardFatal(f)(a, window) : a.execute(function() {
        f(a, window)
    })
})(function(f, e, l) {
    f.when("A", "a-popover", "ready").execute(function(a, k) {
        var h = a.$;
        h(document).delegate("#why-we-love-this-product-link", "click mouseenter", function(a) {
            k.get(h("#ac-badge-popover-declarative")).show();
            a.preventDefault()
        })
    });
    "use strict";
    f.when("A", "atf", "dp-refresh-handler").execute(function(a,
        k, h) {
        k = a.state("acState");
        a = {
            featureName: "acBadge"
        };
        k !== l && (k = k.acAsin, (new h(a)).addParams({
            acAsin: k
        }))
    });
    f.when("A", "ready").execute(function(a) {
        e.submitACFeedback = function(a, h, c, e, d, g) {
            var b = {};
            b.asin = h;
            b.query = a;
            b.customerFeedback = c;
            b.deviceType = e;
            b.modalityType = d;
            b.modalityDescription = g;
            return ue.event(b, "amazons_choice", "amazons_choice.AmazonsChoiceDPXFeedback.2")
        };
        e.emitACPopoverShownEvent = function(a, e, c, f, d) {
            var g = {};
            g.asin = e;
            g.query = a;
            g.deviceType = c;
            g.modalityType = f;
            g.modalityDescription =
                d;
            return ue.event(g, "amazons_choice", "amazons_choice.AmazonsChoicePopoverShown.2")
        }
    });
    f.when("A", "a-sheet", "a-switch").execute(function(a, f, h) {
        var c = a.$,
            m, d, g = h.getSwitch(c("#feedback_widget_toggle_switch"));
        a.on("a:sheet:afterShow:amazons_choice_bottom_sheet", function() {
            m = f.get("amazons_choice_bottom_sheet");
            try {
                var b = a.state("ac-feedback-mobile");
                e.emitACPopoverShownEvent(b.acKeywords, b.acAsin && 0 < b.acAsin.length ? b.acAsin : b.acAsinToRender, "Mobile", b.acModalityType, b.acModalityDescription)
            } catch (c) {}
        });
        a.on("ready", function() {
            function b(a, b) {
                m.changeHeight({
                    duration: .3,
                    height: a
                });
                b ? (c("#feedback-form").addClass("aok-hidden"), c("#feedback_toggle_text")[0].innerText = d.acGiveFeedbackText) : (c("#feedback-form").removeClass("aok-hidden"), c("#feedback_toggle_text")[0].innerText = d.acHideFeedbackText)
            }
            d = a.state("ac-feedback-mobile");
            c("#feedback_submit").click(function() {
                var a = c("input[name\x3dfeedback-option]:checked").val(),
                    b = d.acAsin && 0 < d.acAsin.length ? d.acAsin : d.acAsinToRender;
                a !== l && (e.submitACFeedback(d.acKeywords,
                    b, a, "Mobile", d.acModalityType, d.acModalityDescription) ? (c("#acThankYouText").removeClass("aok-hidden"), setTimeout(function() {
                    m.hide()
                }, 3E3)) : c("#acErrorText").removeClass("aok-hidden"), c("#acFeedbackPrompt")[0].className = "aok-hidden")
            });
            a.declarative("show-feedback-options", "click", function() {
                g.toggle();
                g.isOn() ? b(850, !1) : b(210, !0);
                return !0
            })
        })
    })
});
/* ******** */
(function(a) {
    var b = window.AmazonUIPageJS || window.P,
        e = b._namespace || b.attributeErrors,
        c = e ? e("WestlakeAssets", "") : b;
    c.guardFatal ? c.guardFatal(a)(c, window) : c.execute(function() {
        a(c, window)
    })
})(function(a, b, e) {
    a.when("A", "jQuery").register("alw-delay-load-images", function(c, b) {
        function d() {
            if (null !== document.getElementById("skycity-soft-merge"))
                for (var a = document.querySelectorAll(".skycity-image-html"), d = 0; d < a.length; d++) {
                    var e = b(a[d]);
                    e.hasClass("skycity-image-loaded") || (a[d].insertAdjacentHTML("afterend",
                        a[d].getAttribute("data-html")), e.addClass("skycity-image-loaded"))
                }
            c.trigger("skycity-image-loaded")
        }
        c.on("a:pageUpdate", d);
        a.when("atf").execute("alw-load-images", d)
    });
    "use strict";
    a.when("A").register("alw-delay-load-widget", function(a) {
        function b() {
            var a = document.getElementById("skycity-soft-merge");
            null !== a && (a.style.display = "block")
        }
        b();
        a.on("a:pageUpdate", b)
    })
});
/* ******** */
(function(a) {
    var c = window.AmazonUIPageJS || window.P,
        e = c._namespace || c.attributeErrors,
        b = e ? e("DetailPagePRSubsWidgetAssets", "") : c;
    b.guardFatal ? b.guardFatal(a)(b, window) : b.execute(function() {
        a(b, window)
    })
})(function(a, c, e) {
    a.when("A", "jQuery", "ready", "cf").execute(function(b, d) {
        function a() {
            d(".prsubswidget-asin-title, .prsubswidget-asin-image").unbind("mousedown.prsubswidget");
            d(".prsubswidget-asin-title, .prsubswidget-asin-image").bind("mousedown.prsubswidget", function(a) {
                if (c.ue && c.ue.event && d(a.target).parents("a")) {
                    var b =
                        d(a.target).parents("a").data("subsAsin");
                    a = d(a.target).parents("a").data("surfacedAsinRequestId");
                    b && a && c.ue.event({
                        producerId: "prservices_subs_feedback_loop",
                        schemaId: "prservices.ClickedSubstituteEvent.3",
                        subsAsin: b,
                        surfacedAsinRequestId: a
                    }, "producer", "schema")
                }
            })
        }
        a();
        b.on("a:pageUpdate", a)
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageInstallmentCalculatorAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(p) {
    var r = window.AmazonUIPageJS || window.P,
        q = r._namespace || r.attributeErrors,
        m = q ? q("DetailPageSTSAssets", "") : r;
    m.guardFatal ? m.guardFatal(p)(m, window) : m.execute(function() {
        p(m, window)
    })
})(function(p, r, q) {
    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a,
        b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }

    function m(a, b) {
        if (!(a instanceof b)) throw new TypeError("Cannot call a class as a function");
    }
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store-offer-helper",
        "ship-to-store-item-association-helper", "ship-to-store").register("ship-to-store-atc", function(a, b, e, d, k, h) {
        var n = a.$,
            g = JSON.parse(n("[data-a-state*\x3dvas-common-vm]").html());
        g && g.isShipToStore && (g.hijackMBCATC = !1, g.populateMBCATC = !1, g.showEnhancedUpsellBundle = !1, g.showFakeTwisterBundles = !1, n("[data-a-state*\x3dvas-common-vm]").html(JSON.stringify(g)));
        return new function f() {
            var l = this;
            m(this, f);
            this.init = function(a) {
                l.$addProfessionalServicesRow = n("#addProfessionalServicesRow");
                l.$atcButton = n("#add-to-cart-button");
                l.$buyNowFeatureDiv = n("[id\x3dbuyNow_feature_div]");
                l.$oneClickContainer = n("[id^\x3doneClickAvailable]");
                l.addedToCart = !1;
                l.atcClickIntercepted = !1;
                l.itemAssociationHelper = h;
                l.offerHelper = k;
                l.modal = a;
                l.atcSiEnabled = b.get("atcSiEnabled");
                n("body").undelegate(l.$atcButton.selector, "click.lsatc").delegate(l.$atcButton.selector, "click.lsatc", l.atcClicked)
            };
            this.atcClicked = function() {
                l.atcClickIntercepted = !0;
                e.publish(d.ATC_CLICK);
                l.$addProfessionalServicesRow.is(":visible") ? l.offerHelper.getAcceptedOffer() ||
                    l.modal.openCount || !l.atcSiEnabled ? l.clickATCButton() : l.modal.modalInstance && (e.publish(d.ATC_CLICK_MODAL_SHOWN), l.modal.modalInstance.show()) : (e.publish(d.ATC_CLICK_INGRESS_HIDDEN), l.offerHelper.declineOffer(), l.clickATCButton());
                return !1
            };
            this.clickATCButton = function() {
                l.atcClickIntercepted && n("body").undelegate(l.$atcButton.selector, "click.lsatc", l.atcClicked);
                var a = l.offerHelper.getAcceptedOffer();
                a ? (e.publish(d.ATC_CLICK_WITH_OFFER), e.tag(b.get("refTagPrefix") + "mapping_set_winning_" + a.mappingSet)) :
                    e.publish(d.ATC_CLICK_WITHOUT_OFFER);
                var h = l.offerHelper.getAccepterOfferTypeName().toLowerCase(),
                    h = "mobile" !== h && "at_home" !== h;
                l.itemAssociationHelper.removeServices().then(l.itemAssociationHelper.addService(a, h)).finally(function() {
                    l.addedToCart = !0;
                    l.$atcButton.click()
                })
            };
            this.offerAcceptedCallback = function() {
                l.hideBuyNowOneClickButtons()
            };
            this.hideBuyNowOneClickButtons = function() {
                a.hide(l.$buyNowFeatureDiv);
                a.hide(l.$oneClickContainer)
            };
            this.offerDeclinedCallback = function() {
                l.showBuyNowOneClickButtons();
                l.itemAssociationHelper.removeServices()
            };
            this.showBuyNowOneClickButtons = function() {
                a.show(l.$buyNowFeatureDiv);
                a.show(l.$oneClickContainer)
            };
            this.modalOffersGenerated = function(a) {
                a.offerCount || (l.showBuyNowOneClickButtons(), l.itemAssociationHelper.removeServices())
            };
            this.modalClosedCallback = function() {
                l.atcClickIntercepted && !l.addedToCart && l.clickATCButton()
            };
            a.on("ship-to-store:modal:closed", this.modalClosedCallback);
            a.on("ship-to-store:modal:offers-generated", this.modalOffersGenerated);
            a.on("ship-to-store:offer-accepted",
                this.offerAcceptedCallback);
            a.on("ship-to-store:offer-declined", this.offerDeclinedCallback)
        }
    });
    "use strict";
    var t = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(a) {
        return typeof a
    } : function(a) {
        return a && "function" === typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    };
    (function() {
        try {
            var a = function() {
                var a = document.querySelectorAll('.a-declarative[data-action\x3d"aw-mash"]');
                if (!a) return {
                    v: void 0
                };
                var e = !1;
                p.when("aw-mash-handler").execute(function() {
                    e = !0
                });
                for (var d = !1, k = null, h = function l(a) {
                        isNaN(k) || (e && d && (r.ue.count("pdx-mash-atc-click-before-ready-reclick", k), a.currentTarget.removeEventListener("click", l)), e || (d || r.ue.count("pdx-mash-atc-click-before-ready", k), d = !0))
                    }, n = 0; n < a.length; n++) {
                    var g = a[n],
                        c = JSON.parse(g.getAttribute("data-aw-mash"));
                    !k && c && c.inputs && (k = parseFloat(c.inputs["log-buybox-metrics-price.0"]));
                    (g = g.querySelector('input[type\x3d"submit"]')) && g.addEventListener("click", h)
                }
            }();
            if ("object" === ("undefined" === typeof a ? "undefined" :
                    t(a))) return a.v
        } catch (b) {}
    })();
    "use strict";
    p.when("A", "ship-to-store-atc", "ship-to-store-settings", "ship-to-store-helper", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "query-param", "ship-to-store-offer-helper", "ship-to-store-item-association-helper", "ship-to-store").execute(function(a, b, e, d, k, h, n, g, c) {
        var f = function() {
            k.logRefTag(e.get("refTagPrefix"), {
                deviceType: e.get("deviceType")
            });
            k.tag(e.get("ueTag"));
            a.each(e.get("mappingSets"), function(a) {
                k.tag(e.get("refTagPrefix") + "mapping_set_" +
                    a)
            });
            d.isShipToStoreEnabled(e.get("winningWidgetName"), e.get("offerCollections")) && ((e.get("modalParams") || {}).hasOwnProperty("name") ? p.when("ship-to-store-ingress", "ship-to-store-modal").execute(function(l, d) {
                k.publish(h.LOADED);
                var e = a.$;
                (new function u() {
                    var f = this;
                    m(this, u);
                    this.quantityChanged = function(a) {
                        f.updateSelectedQuantity(a.value)
                    };
                    this.updateSelectedQuantity = function(c) {
                        c && f.offerHelper.setQuantity(c);
                        f.offerHelper.setVisibleOffers();
                        if (!f.offerHelper.getAsinForQuantity()) return k.publish(h.SELECTED_QTY_NOT_MAPPED_TO_ASIN), !1;
                        if (!f.offerHelper.hasVisibleOffers()) return k.publish(h.SELECTED_QTY_MAPPED_TO_ASIN_WO_OFFERS), !1;
                        k.publish(h.SELECTED_QTY_MAPPED_TO_ASIN_W_OFFERS);
                        a.trigger("ship-to-store:generate-html")
                    };
                    this.modalOffersGenerated = function(c) {
                        c.offerCount ? a.show(f.$shipToStoreFeatureDiv) : (a.hide(f.$shipToStoreFeatureDiv), f.showQuickPurchaseIngress())
                    };
                    this.offerAcceptedCallback = function() {
                        f.queryParam.setParameter("sts-ao", f.offerHelper.getAcceptedOffer().storeId)
                    };
                    this.offerDeclinedCallback = function() {
                        k.publish(h.OFFER_DECLINED_CLICK);
                        k.publish(h.OFFER_DECLINED);
                        f.queryParam.removeParameter("sts-ao")
                    };
                    this.modalClosedCallback = function() {
                        f.offerHelper.getAcceptedOffer() ? f.queryParam.setParameter("sts-ao", f.offerHelper.getAcceptedOffer().storeId) : f.queryParam.removeParameter("sts-ao")
                    };
                    this.initModules = function() {
                        f.$shipToStoreFeatureDiv = e("#shipToStoreBuyBox_feature_div");
                        f.ingress.init();
                        f.offerHelper.init();
                        f.modal.init();
                        f.addToCart.init(f.modal);
                        f.updateSelectedQuantity(1)
                    };
                    this.init = function() {
                        k.publish(h.INIT);
                        f.ingress = l;
                        f.itemAssociationHelper = c;
                        f.offerHelper = g;
                        f.modal = d;
                        f.addToCart = b;
                        f.initModules();
                        p.when("a-dropdown").execute(function(a) {
                            (a = a.getSelect("mobileQuantityDropDown")) && f.updateSelectedQuantity(a.val())
                        });
                        k.publish(h.OFFERS_ON_PAGE_LOAD, f.offerHelper.getNumberOfOffers());
                        a.on("a:dropdown:mobileQuantityDropDown:select", f.quantityChanged);
                        a.on("ship-to-store:ingress:offered-click", f.offerHelper.setVisibleOffers);
                        a.on("ship-to-store:offer-accepted", f.offerAcceptedCallback);
                        a.on("ship-to-store:offer-declined",
                            f.offerDeclinedCallback);
                        a.on("ship-to-store:modal:closed", f.modalClosedCallback);
                        a.on("ship-to-store:modal:offers-generated", f.modalOffersGenerated);
                        f.queryParam = new n;
                        if (f.queryParam.parameterExists("sts-ao")) {
                            var e = f.queryParam.getParameter("sts-ao");
                            (e = f.offerHelper.getOfferByStoreId(e)) ? (k.publish(h.PAGE_RELOAD_OFFER_NOT_FOUND), f.offerHelper.setVisibleOffers(e.offerType.name), a.trigger("ship-to-store:query-param-offer-found", e)) : k.publish(h.PAGE_RELOAD_OFFER_FOUND)
                        }
                    }
                }).init()
            }) : d.hideShipToStore("#shipToStoreBuyBox_feature_div"))
        };
        a.on("a:pageUpdate", f);
        f()
    });
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store-offer-helper", "ship-to-store").register("ship-to-store-ingress", function(a, b, e, d, k) {
        var h = a.$;
        return new function g() {
            var c = this;
            m(this, g);
            this.selectedIngressChangeClick = function() {
                a.trigger("ship-to-store:ingress:selected-change-click");
                a.trigger("ship-to-store:modal:show");
                e.publish(d.SELECTED_INGRESS_CHANGE_CLICK);
                c.modalIsReady || e.publish(d.SELECTED_INGRESS_CHANGE_CLICK_MODAL_NOT_READY)
            };
            this.offeredIngressClick = function(f) {
                a.trigger("ship-to-store:ingress:offered-click", f.currentTarget.dataset.offerType);
                a.trigger("ship-to-store:modal:show");
                e.publish(d.OFFER_INGRESS_CLICK);
                switch (f.currentTarget.dataset.offerType) {
                    case "IN_STORE":
                        e.publish(d.OFFER_INGRESS_CLICK_IN_STORE);
                        break;
                    case "AT_HOME":
                    case "MOBILE":
                        e.publish(d.OFFER_INGRESS_CLICK_AT_HOME)
                }
                c.modalIsReady || e.publish(d.OFFER_INGRESS_CLICK_MODAL_NOT_READY)
            };
            this.offerAcceptedCallback = function() {
                var f = c.offerHelper.getAcceptedOffer(),
                    h = c.offerHelper.getSelectedOfferTypeCollection();
                c.$selected.find("#ship-to-store-selected-service-provider-address").text(f.displayAddress);
                c.$selected.find("#ship-to-store-selected-service-provider-name").text(f.merchantName);
                c.$selectedBelowAddress.html(f.priceAndServiceCount);
                var d = c.$offerPriceTemplate.clone();
                d.html(f.localizedPrice);
                d.removeAttr("id");
                a.show(d);
                c.$selectedBelowAddress.find(".price").html(d);
                if (f.hasPromotion) {
                    var e = c.$offerPriceStrikethroughTemplate.clone();
                    e.html(f.localizedPriceWithoutPromotion);
                    e.removeAttr("id");
                    a.show(e);
                    d.append(" ");
                    d.after(e)
                }
                c.$selectedIngressOfferType.html(h.modalTabButtonString);
                f = c.offerHelper.getAsinForQuantity();
                c.$selectedBelowPrice.html(h.upsellAsinSpecificStrings[f].selectedIngressBelowPrice);
                a.hide(c.$offered);
                a.show(c.$selected);
                a.show(c.$addProfessionalServicesRow)
            };
            this.offerDeclinedCallback = function() {
                a.hide(c.$selected);
                a.show(c.$offered)
            };
            this.generateHTML = function() {
                a.each(b.get("offerCollections"), function(f) {
                    var d = h(".ship-to-store-ingress-bullet-points." +
                            f.offerType.name),
                        e = h(".ship-to-store-ingress-bullet-points.inactive." + f.offerType.name);
                    if (f.hasOffers) {
                        if (f.upsellAsinSpecificStrings) {
                            var b = c.offerHelper.getAsinForQuantity(null, f);
                            if (f = f.upsellAsinSpecificStrings[b]) d.html(f.bulletPoints), a.show(d), a.hide(e)
                        }
                    } else e.html(f.ingressBulletsInactiveString), a.hide(d), a.show(e)
                });
                if (performance) {
                    performance.mark("ship-to-store-ingress-end");
                    performance.measure(d.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY, "ship-to-store-ingress-start", "ship-to-store-ingress-end");
                    var f = performance.getEntriesByName(d.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY);
                    if (f.length) {
                        var g = f[0].duration;
                        e.publish(d.INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY, f[0].startTime + g);
                        e.publish(d.INGRESS_SHOWING_SINCE_MODULE_LOAD_LATENCY, g)
                    }
                }
            };
            this.quantityChangedCallback = function() {
                c.offerHelper.hasOfferForQuantity() ? (e.publish(d.QUANTITY_SUPPORTED), a.show(c.$addProfessionalServicesRow)) : (e.publish(d.QUANTITY_NOT_SUPPORTED), a.hide(c.$addProfessionalServicesRow))
            };
            this.modalReadyCallback = function() {
                p.when("ship-to-store-ingress-button").execute(function(f) {
                    a.each(b.get("offerCollections") || [], function(a) {
                        a.hasOffers && a.offerType && a.offerType.name && f.enable(a.offerType.name)
                    });
                    c.modalIsReady = !0
                })
            };
            this.init = function() {
                c.$addProfessionalServicesRow = h("#addProfessionalServicesRow");
                c.$offered = h("#ship-to-store-ingress-offered");
                c.$offerPriceTemplate = h("#ship-to-store-modal-offer-price-text-template");
                c.$offerPriceStrikethroughTemplate = h("#ship-to-store-ingress-offer-price-text-strikethrough-template");
                c.$selected = h("#ship-to-store-ingress-selected");
                c.$selectedBelowAddress = h("#ship-to-store-selected-service-below-address");
                c.$selectedBelowPrice = h("#ship-to-store-selected-service-below-price");
                c.$selectedIngressOfferType = h(".ship-to-store-ingress-header-primary-text .offer-type");
                c.offerHelper.init()
            };
            performance && performance.mark("ship-to-store-ingress-start");
            this.offerHelper = k;
            this.modalIsReady = !1;
            var f = h("body");
            f.delegate(".ship-to-store-ingress-button", "click", this.offeredIngressClick);
            f.delegate("#ship-to-store-change-installation", "click", this.selectedIngressChangeClick);
            a.on("ship-to-store:offer-accepted", this.offerAcceptedCallback);
            a.on("ship-to-store:offer-declined", this.offerDeclinedCallback);
            a.on("ship-to-store:generate-html", this.generateHTML);
            a.on("ship-to-store:quantity-changed", this.quantityChangedCallback);
            a.on("ship-to-store:modal:ready", this.modalReadyCallback)
        }
    });
    "use strict";
    p.when("ship-to-store").register("ship-to-store-ingress-button", function() {
        var a = function e() {
            m(this, e)
        };
        a.enable = function(a) {
            p.when("jQuery").execute(function(d) {
                d = d('.ship-to-store-ingress-button[data-offer-type\x3d"' + a + '"]');
                d.removeClass("disabled");
                d.find('[name\x3d"ship-to-store-offer-selected"').attr("disabled", !1)
            })
        };
        return a
    });
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store").register("ship-to-store-metric-names", function(a, b) {
        var e = {
            ATC_CLICK: "add_to_cart_button_click",
            ATC_CLICK_MODAL_SHOWN: "add_to_cart_button_click_modal_shown",
            ATC_CLICK_WITH_OFFER: "add_to_cart_button_click_with_offer",
            ATC_CLICK_WITHOUT_OFFER: "add_to_cart_button_click_without_offer",
            ATC_CLICK_INGRESS_HIDDEN: "add_to_cart_button_click_ingress_hidden",
            ATC_FORM_APPEND_FAIL: "add_to_cart_form_append_fail",
            ATC_FORM_APPEND_SUCCESS: "add_to_cart_form_append_success",
            ATC_FORM_REMOVE_FAIL: "add_to_cart_form_remove_fail",
            ATC_FORM_REMOVE_SUCCESS: "add_to_cart_form_remove_success",
            ATC_POST_DONE: "add_to_cart_post_done",
            ATC_POST_FAIL: "add_to_cart_post_fail",
            ATC_POST_STARTED: "add_to_cart_post_started",
            ATC_POST_SUCCESS: "add_to_cart_post_success",
            ATC_UBB_CLICK: "add_to_cart_ubb_button_click",
            CHANGED_QUANTITY: "changed_quantity_event",
            INCLUDED_SERVICES_DESKTOP_HOVER: "included_services_desktop_hover",
            INCLUDED_SERVICES_MOBILE_CLICK: "included_services_mobile_click",
            INCLUDED_SERVICES_NUMBER_OF_SERVICES: "included-services-number-of-services",
            INGRESS_SHOWING_SINCE_MODULE_LOAD_LATENCY: "ingress-showing-since-module-load-latency",
            INGRESS_SHOWING_SINCE_PAGE_LOAD_LATENCY: "ingress-showing-since-page-load-latency",
            INIT: "init",
            LOADED: "loaded",
            MODAL_OPENED_AFTER_MILLISECONDS: "modal_opened_after_milliseconds",
            NO_ACTIVE_OFFER_TYPE: "no_active_offer_type",
            NO_OFFERS_ON_PAGE_LOAD: "no_offers_on_page_load",
            OFFER_ACCEPTED: "offer_accepted",
            OFFER_ACCEPTED_CLICK: "offer_accepted_click",
            OFFER_DECLINED: "offer_declined",
            OFFER_DECLINED_CLICK: "offer_declined_click",
            OFFER_INGRESS_CLICK: "offer_ingress_click",
            OFFER_INGRESS_CLICK_IN_STORE: "offer_ingress_click_in_store",
            OFFER_INGRESS_CLICK_AT_HOME: "offer_ingress_click_at_home",
            OFFER_INGRESS_CLICK_MODAL_NOT_READY: "offer_ingress_click_modal_not_ready",
            OFFER_LIST_CLOSED: "offer_list_closed",
            OFFER_LIST_OPENED: "offer_list_opened",
            OFFER_SELECTED: "offer_selected",
            OFFER_PRICE_FALSY: "offer_price_falsy",
            OFFERS_GENERATED: "offers_generated",
            OFFERS_ON_PAGE_LOAD: "offers_on_page_load",
            OFFERS_ON_ZIP_UPDATE: "offers_on_zip_update",
            PAGE_RELOAD_OFFER_FOUND: "page_reload_offer_found",
            PAGE_RELOAD_OFFER_NOT_FOUND: "page_reload_offer_not_found",
            PAGE_RELOAD_OFFER_NOT_SPECIFIED: "page_reload_offer_not_specified",
            QUANTITY_SUPPORTED: "quantity_supported",
            QUANTITY_NOT_SUPPORTED: "quantity_not_supported",
            SELECTED_INGRESS_CHANGE_CLICK: "selected_ingress_change_click",
            SELECTED_INGRESS_CHANGE_CLICK_MODAL_NOT_READY: "selected_ingress_change_click_modal_not_ready",
            SELECTED_QTY_MAPPED_TO_ASIN_W_OFFERS: "selected_quantity_mapped_to_asin_with_offers",
            SELECTED_QTY_MAPPED_TO_ASIN_WO_OFFERS: "selected_quantity_mapped_to_asin_with_no_offers",
            SELECTED_QTY_NOT_MAPPED_TO_ASIN: "selected_quantity_not_mapped_to_asin",
            ZIP_UPDATE_ERROR: "zip_update_error",
            ZIP_UPDATE_HIDE: "zip_update_hide",
            ZIP_UPDATE_HIDE_CLICK: "zip_update_hide_click",
            ZIP_UPDATE_INVALID_ZIP_ENTERED: "zip_update_invalid_zip_entered",
            ZIP_UPDATE_NO_OFFERS: "zip_update_no_offers",
            ZIP_UPDATE_SHOW: "zip_update_show",
            ZIP_UPDATE_SHOW_CLICK: "zip_update_show_click",
            ZIP_UPDATE_SUCCESS: "zip_update_success"
        };
        a.each(e, function(a, k) {
            e[k] = "" + b.get("refTagPrefix") + a
        });
        return e
    });
    "use strict";
    p.when("jQuery", "ship-to-store-function", "query-param", "ship-to-store").register("ship-to-store-metric-publisher", function(a, b, e) {
        var d = function h() {
            m(this, h)
        };
        d.logError = function(a, d) {
            b.try(function() {
                r.ueLogError(a, {
                    logLevel: "ERROR",
                    attribution: d
                })
            })
        };
        d.logRefTag = function(d) {
            var b = 1 < arguments.length && arguments[1] !== q ? arguments[1] : {};
            a.get("/gp/ls/impress.html/ref\x3d" + encodeURIComponent(d) + "?" + e.createQueryStringFromObject(b))
        };
        d.publish = function(a) {
            var d = 1 < arguments.length && arguments[1] !== q ? arguments[1] : 1;
            b.try(function() {
                r.ue.count(a, d)
            })
        };
        d.tag = function(a) {
            b.try(function() {
                r.ue.tag(a)
            })
        };
        d.tag("pdpShipToStoreWidget");
        return d
    });
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store-offer-helper", "ship-to-store").register("ship-to-store-modal", function(a, b, e, d, k) {
        var h = a.$;
        return new function g() {
            var c = this;
            m(this, g);
            this.acceptOfferClick = function() {
                c.modalInstance.hide();
                c.offerHelper.acceptOffer(c.selectedOffer);
                e.publish(d.OFFER_ACCEPTED_CLICK)
            };
            this.declineOfferClick = function() {
                c.modalInstance.hide();
                c.offerHelper.declineOffer();
                e.publish(d.OFFER_DECLINED_CLICK)
            };
            this.queryParamOfferFound = function(a) {
                c.selectedOffer = a;
                c.offerHelper.acceptOffer(c.selectedOffer)
            };
            this.selectionChanged = function(a) {
                c.changeSelectedOffer(h(a.currentTarget))
            };
            this.changeSelectedOffer = function(a) {
                a && a.length && a.is(c.$highlightedOffer) || (c.$highlightedOffer.removeClass("selected"), c.$highlightedOffer =
                    a, c.selectHighlightedOffer())
            };
            this.selectHighlightedOffer = function() {
                var f = c.$highlightedOffer.data("storeId");
                c.selectedOffer = c.offerHelper.getOfferByStoreId(f);
                c.$highlightedOffer.addClass("selected");
                c.$offersScrollerContainer.length && c.$highlightedOffer.length && (c.$offersScrollerContainer.animate({
                    scrollLeft: c.$highlightedOffer.offset().left - c.$offersScrollerContainer.offset().left + c.$offersScrollerContainer.scrollLeft()
                }), a.trigger("ship-to-store:offer-selected", f))
            };
            this.getDefaultOffer = function() {
                var a =
                    c.offerHelper.getDefaultOffer();
                return c.$modal.find(".ship-to-store-modal-offer-wrapper." + a.storeId)
            };
            this.beforeShow = function() {
                if (performance) {
                    performance.mark("ship-to-store-modal-opened");
                    performance.measure(d.MODAL_OPENED_AFTER_MILLISECONDS, "ship-to-store-modal-init", "ship-to-store-modal-opened");
                    var f = a.map(performance.getEntriesByName(d.MODAL_OPENED_AFTER_MILLISECONDS), function(a) {
                        return a.duration
                    }).shift();
                    f && e.publish(d.MODAL_OPENED_AFTER_MILLISECONDS, f)
                }
                a.off("a:sheet:beforeShow:" + b.get("modalName"),
                    c.beforeShow)
            };
            this.afterShow = function() {
                e.publish(d.OFFER_LIST_OPENED);
                c.openCount++;
                p.when("a-sheet").execute(function(a) {
                    c.modalInstance = a.get(c.modalName);
                    c.modalInstance.$container.height("auto")
                });
                c.clickSelectedOfferTypeButton()
            };
            this.clickSelectedOfferTypeButton = function() {
                c.$offerTypeButtonsRow.find(".ship-to-store-modal-offer-type-button." + c.offerHelper.selectedOfferType).click()
            };
            this.afterHide = function() {
                e.publish(d.OFFER_LIST_CLOSED);
                a.trigger("ship-to-store:modal:closed")
            };
            this.offerTypeButtonClick =
                function(a) {
                    c.$offerTypeButtonsRow.find(".ship-to-store-modal-offer-type-button").removeClass("checked");
                    h(a.currentTarget).addClass("checked");
                    c.offerHelper.setVisibleOffers(a.currentTarget.dataset.offerType);
                    c.$offerTypeDescription.html(c.offerHelper.getSelectedOfferTypeCollection().modalTabHeaderString);
                    c.generateHTML()
                };
            this.includedServicesPopoverHover = function() {
                e.publish(d.INCLUDED_SERVICES_DESKTOP_HOVER)
            };
            this.getOfferAddress = function() {
                c.$highlightedOffer && c.$highlightedOffer.find(".ship-to-store-merchant-address").val()
            };
            this.showIncludedServices = function(c, b) {
                if (b.includedServicesList && 0 < b.includedServicesList.length) {
                    b.includedServicesList.sort();
                    c.find(".ship-to-store-modal-included-services-number-of-services").html(b.includedServicesNumberOfServicesNoPreviewString);
                    var g = c.find(".ship-to-store-modal-included-services-popover-trigger"),
                        k = h(".ship-to-store-modal-included-services-popover-content-template").clone();
                    k.find(".ship-to-store-modal-included-services-all-providers").html(b.includedServicesAllProviders);
                    var m = h.map(b.includedServicesList, function(a) {
                        var c = document.createElement("li");
                        c.innerHTML = a;
                        return c
                    });
                    k.find(".ship-to-store-modal-included-services-list").append(m);
                    k = {
                        name: "includedServicesPopover",
                        header: h(".ship-to-store-modal-included-services-popover-header").get(0).outerHTML,
                        inlineContent: k.get(0).outerHTML
                    };
                    a.declarative.create(g, "a-modal", k);
                    a.show(c.find(".ship-to-store-modal-included-services-container"));
                    e.publish(d.INCLUDED_SERVICES_NUMBER_OF_SERVICES, b.includedServicesList.length)
                }
            };
            this.generateHTML = function() {
                c.getOfferAddress();
                c.$highlightedOffer = null;
                var f = 0;
                c.$offersScroller.empty();
                var h = b.get("priceHTMLMap") || {},
                    k = b.get("priceStrikethroughHTMLMap") || {};
                a.each(c.offerHelper.getVisibleOffers(), function(b) {
                    var g = h[b.localizedPrice];
                    if (g) {
                        var m = c.$offerTemplate.clone();
                        m.find(".ship-to-store-merchant-name").html(b.merchantName);
                        m.find(".ship-to-store-merchant-address").html(b.address ? b.address.displayAddressShort : "");
                        m.find(".ship-to-store-merchant-ratings").html(b.ratingsAndReviews);
                        m.find(".ship-to-store-merchant-price").html(b.priceAndServiceCount);
                        c.includedServicesEnabled && c.showIncludedServices(m, b);
                        m.attr("id", "ship-to-store-offer-merchant-row-" + f);
                        m.addClass(b.storeId);
                        m.data("storeId", b.storeId);
                        b.hasPromotion && k.hasOwnProperty(b.localizedPriceWithoutPromotion) && (g = g + " " + k[b.localizedPriceWithoutPromotion]);
                        m.find(".ship-to-store-merchant-price .price").html(g);
                        b.priceAndServiceCount = m.find(".ship-to-store-merchant-price").html();
                        f++;
                        a.show(m);
                        c.$offersScroller.append(m)
                    } else e.publish(d.OFFER_PRICE_FALSY)
                });
                e.publish(d.OFFERS_GENERATED, f);
                a.trigger("ship-to-store:modal:offers-generated", {
                    offerCount: f
                });
                c.$highlightedOffer = c.getDefaultOffer();
                c.selectHighlightedOffer()
            };
            this.show = function() {
                c.modalInstance && c.modalInstance.show()
            };
            this.init = function() {
                performance && performance.mark("ship-to-store-modal-init");
                c.$offersScroller = h("#ship-to-store-modal-offers-scroller");
                c.$offersScrollerContainer = h("#ship-to-store-modal-offers-scroller-container");
                c.$offerTemplate = h("#ship-to-store-modal-offer-wrapper-template");
                c.$offerTypeButtonsRow = h(".ship-to-store-modal-offer-type-buttons");
                c.$offerTypeDescription = h(".ship-to-store-modal-offer-type-description");
                c.$modal = h("#ship-to-store-pdp-only-modal");
                c.includedServicesEnabled = b.get("includedServicesEnabled");
                c.numberOfServicesPreviewed = 2;
                c.offerHelper = k;
                a.each(h(".ship-to-store-modal-offer-type-button"), function(a) {
                    a = h(a);
                    var b = a.find(".ship-to-store-offer-img");
                    c.offerHelper.getSelectedOfferTypeCollection(a.data("offer-type")).hasOffers ? (a.removeClass("disabled"),
                        b.removeClass("disabled")) : (a.addClass("disabled"), b.addClass("disabled"))
                });
                p.when("a-sheet").execute(function(f) {
                    c.modalName && (c.modalInstance = f.create(c.sheetParams), a.trigger("ship-to-store:modal:ready"))
                })
            };
            this.selectedOffer = null;
            this.openCount = 0;
            this.modalInstance = null;
            this.sheetParams = b.get("modalParams") || {};
            this.modalName = this.sheetParams.name || "";
            h("body").delegate(".ship-to-store-modal-offer-wrapper", "click", this.selectionChanged).delegate(".ship-to-store-modal-offer-type-button", "click",
                this.offerTypeButtonClick).delegate(".ship-to-store-modal-accept-offer", "click", this.acceptOfferClick).delegate(".ship-to-store-modal-decline-offer", "click", this.declineOfferClick);
            a.on("a:popover:afterShow:includedServicesPopover", this.includedServicesPopoverHover);
            a.on("ship-to-store:query-param-offer-found", this.queryParamOfferFound);
            a.on("a:sheet:beforeShow:" + this.modalName, this.beforeShow);
            a.on("a:sheet:afterShow:" + this.modalName, this.afterShow);
            a.on("a:sheet:afterHide:" + this.modalName, this.afterHide);
            a.on("ship-to-store:modal:show", this.show)
        }
    });
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store").register("ship-to-store-offer-helper", function(a, b, e, d) {
        return new function h(n) {
            var g = this;
            m(this, h);
            this.visibleOffers = [];
            this.determineOfferType = function() {
                if (g.selectedOfferType in g.offerCollectionsMap && g.offerCollectionsMap[g.selectedOfferType].hasOffers) return g.selectedOfferType;
                var c = void 0;
                a.each(b.get("offerCollections"),
                    function(a) {
                        a.hasOffers && c === q && (c = a.offerType.name)
                    });
                if (c) return c;
                e.publish(d.NO_ACTIVE_OFFER_TYPE)
            };
            this.getNumberOfOffers = function() {
                return a.reduce(b.get("offerCollections") || [], function(c, b) {
                    return c + (b && a.isArray(b.offers) ? b.offers.length : 0)
                }, 0)
            };
            this.getSelectedOfferTypeCollection = function(a) {
                return g.offerCollectionsMap[a || g.selectedOfferType]
            };
            this.setVisibleOffers = function(c) {
                c && (g.selectedOfferType = c);
                var b = g.getAsinForQuantity();
                g.visibleOffers = [];
                a.each(g.getSelectedOfferTypeCollection().offers,
                    function(a) {
                        a.asin === b && g.visibleOffers.push(a)
                    })
            };
            this.getOfferAtAddress = function(a, b) {
                for (var d = 0; d < a.length; d++)
                    if (a[d].displayAddress === b) return a[d];
                return null
            };
            this.setQuantity = function(c) {
                c = parseInt(c);
                if (g.selectedQuantity !== c) {
                    var b = g.selectedQuantity;
                    g.selectedQuantity = c;
                    c = g.acceptedOffer;
                    g.setVisibleOffers();
                    c && ((c = g.getOfferAtAddress(g.getVisibleOffers(), c.displayAddress)) ? g.acceptOffer(c) : g.declineOffer());
                    a.trigger("ship-to-store:quantity-changed", {
                        previousQuantity: b,
                        quantity: g.selectedQuantity
                    })
                }
            };
            this.getAsinForQuantity = function(a, b) {
                b = b || g.getSelectedOfferTypeCollection();
                a = a || g.selectedQuantity;
                return b.quantityToUpsellAsinMap[a]
            };
            this.getVisibleOffers = function() {
                return g.visibleOffers
            };
            this.getOfferByStoreId = function(c) {
                return a.reduce(g.offerMap[c] || [], function(a, c) {
                    return c.quantity === g.selectedQuantity ? c : a
                }, null)
            };
            this.getSelectedQuantity = function() {
                return g.selectedQuantity
            };
            this.hasVisibleOffers = function() {
                return g.visibleOffers && g.visibleOffers.length
            };
            this.hasOfferForQuantity = function(c) {
                c =
                    c || g.selectedQuantity;
                return a.reduce(b.get("offerCollections") || [], function(a, b) {
                    return a || g.getAsinForQuantity(c, b)
                }, !1)
            };
            this.getDefaultOffer = function() {
                return g.acceptedOffer && g.getSelectedOfferTypeCollection().offerType.name === g.acceptedOffer.offerType.name ? g.acceptedOffer : g.getSelectedOfferTypeCollection().offers[0]
            };
            this.getAcceptedOffer = function() {
                return g.acceptedOffer
            };
            this.getAccepterOfferTypeName = function() {
                var a = g.getAcceptedOffer();
                return a && a.offerType && a.offerType.name || ""
            };
            this.acceptOffer =
                function(c) {
                    g.acceptedOffer = c;
                    g.selectedOfferType = c.offerType.name;
                    e.publish(d.OFFER_ACCEPTED);
                    a.trigger("ship-to-store:offer-accepted")
                };
            this.declineOffer = function() {
                g.acceptedOffer = null;
                e.publish(d.OFFER_DECLINED);
                a.trigger("ship-to-store:offer-declined")
            };
            this.init = function() {
                g.offerCollectionsMap = {};
                a.each(b.get("offerCollections"), function(a) {
                    g.offerCollectionsMap[a.offerType.name] = a
                });
                g.offerMap = {};
                a.each(b.get("offerCollections"), function(c) {
                    a.each(c.offers, function(a) {
                        g.offerMap[a.storeId] ||
                            (g.offerMap[a.storeId] = []);
                        g.offerMap[a.storeId].push(a)
                    })
                });
                g.selectedOfferType = g.determineOfferType();
                g.acceptedOffer = null
            };
            if (h.instance) return h.instance;
            h.instance = this;
            this.init(n);
            this.selectedQuantity = null
        }
    });
    "use strict";
    t = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(a) {
        return typeof a
    } : function(a) {
        return a && "function" === typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    };
    p.when("A", "ship-to-store").register("ship-to-store-settings", function(a) {
        var b =
            function k() {
                m(this, k)
            };
        b.get = function(a) {
            if (a && e) return e[a]
        };
        b.set = function(b) {
            b && "object" === ("undefined" === typeof b ? "undefined" : t(b)) && !a.isArray(b) && (e = b)
        };
        b.parsePageState = function() {
            var b = 0 < arguments.length && arguments[0] !== q ? arguments[0] : a.$("body");
            return a.parseJSON(b.find("[data-a-state*\x3dship-to-store-view-model]").html())
        };
        var e = b.parsePageState();
        return b
    });
    "use strict";
    p.when("ship-to-store-settings", "3p-promise").register("ship-to-store-function", function(a, b) {
        var e = function k() {
            m(this,
                k)
        };
        e.try = function(e) {
            return (new b(function(a, b) {
                e(a, b)
            })).catch(function(b) {
                p.when("ship-to-store-metric-publisher").execute(function(e) {
                    e.logError(b, a.get("attribution"))
                });
                throw b;
            })
        };
        return e
    });
    "use strict";
    var v = Object.assign || function(a) {
        for (var b = 1; b < arguments.length; b++) {
            var e = arguments[b],
                d;
            for (d in e) Object.prototype.hasOwnProperty.call(e, d) && (a[d] = e[d])
        }
        return a
    };
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store-uuid", "ship-to-store-function",
        "ship-to-store").register("ship-to-store-item-association-helper", function(a, b, e, d, k, h) {
        var n = a.$,
            g = ["aw-mash", "add-to-cart", "one-click", "show-services-interstitial", "show-uss-interstitial"];
        return new function f() {
            var l = this;
            m(this, f);
            this.addService = function(a) {
                var f = 1 < arguments.length && arguments[1] !== q ? arguments[1] : !0;
                return h.try(function(h, g) {
                    if (a && a.offerListingId) {
                        var m = k.generate();
                        l.addItemAssociationToProduct(m).then(function() {
                            e.publish(d.ATC_POST_STARTED);
                            var k = "/gp/aw/detail/ajax/add-to-cart/ref\x3d" +
                                encodeURIComponent(b.get("refTagPrefix")) + "dpatc_" + encodeURIComponent(a.asin) + "_" + encodeURIComponent(b.get("productAsin")),
                                l = {
                                    verificationSessionID: b.get("sessionId"),
                                    a: a.asin,
                                    o: "add",
                                    oid: a.offerListingId,
                                    quantity: 1,
                                    clientName: "ShipToStoreMobile"
                                };
                            f && (l = v({}, l, {
                                "custom-name.1": "itemAssoc",
                                "custom-value.1": m
                            }));
                            n.post(k, l).done(function(a) {
                                a.ok ? (e.publish(d.ATC_POST_SUCCESS), h()) : (e.publish(d.ATC_FORM_REMOVE_FAIL), g())
                            }).fail(function() {
                                e.publish(d.ATC_FORM_REMOVE_FAIL);
                                g()
                            }).always(function() {
                                e.publish(d.ATC_POST_DONE)
                            })
                        })
                    } else g()
                })
            };
            this.addItemAssociationToProduct = function(a) {
                return b.get("isApp") ? l.addItemAssociationToProductApp(a) : l.addItemAssociationToProductWeb(a)
            };
            this.addItemAssociationToProductWeb = function(b) {
                return h.try(function(d) {
                    if (b) {
                        var e = n("#addToCart"),
                            f = e.find('input[name^\x3d"custom-name."]'),
                            f = a.reduce(f, function(a, b) {
                                b = n(b).attr("name").split(".").pop();
                                return b > a ? b : a
                            }, 0) + 1;
                        e.append('\x3cinput type\x3d"hidden" class\x3d"atcFormServiceAsinData" name\x3d"custom-name.' + f + '" value\x3d"itemAssoc" /\x3e\n              \x3cinput type\x3d"hidden" class\x3d"atcFormServiceAsinData" name\x3d"custom-value.' +
                            f + '" value\x3d"' + b + '" /\x3e\n              \x3cinput type\x3d"hidden" class\x3d"atcFormServiceAsinData" name\x3d"custom-name.' + (f + 1) + '" value\x3d"UNIQ-itemAssoc" /\x3e\n              \x3cinput type\x3d"hidden" class\x3d"atcFormServiceAsinData" name\x3d"custom-value.' + (f + 1) + '" value\x3d"' + b + '" /\x3e')
                    }
                    d()
                }).then(function() {
                    e.publish(d.ATC_FORM_APPEND_SUCCESS)
                }, function() {
                    e.publish(d.ATC_FORM_APPEND_FAIL)
                })
            };
            this.addItemAssociationToProductApp = function(b) {
                return h.try(function(d) {
                    var e = !0,
                        f = !1,
                        h = q;
                    try {
                        for (var k = g[Symbol.iterator](), m; !(e = (m = k.next()).done); e = !0) a.declarative(m.value, "click", function(a) {
                            l.applyItemAssociationToProduct(a, b)
                        })
                    } catch (n) {
                        f = !0, h = n
                    } finally {
                        try {
                            !e && k.return && k.return()
                        } finally {
                            if (f) throw h;
                        }
                    }
                    d()
                })
            };
            this.applyItemAssociationToProduct = function(b, d) {
                if (d && b.data && b.data.inputs) {
                    var e = Object.keys(b.data.inputs).filter(function(a) {
                            return a.startsWith("custom-name.")
                        }),
                        e = a.reduce(e, function(a, b) {
                            b = parseInt(b.split(".").pop());
                            return b > a ? b : a
                        }, 0) + 1;
                    b.data.inputs["custom-name." +
                        e] = "itemAssoc";
                    b.data.inputs["custom-value." + e] = d;
                    b.data.inputs["custom-name." + (e + 1)] = "UNIQ-itemAssoc";
                    b.data.inputs["custom-value." + (e + 1)] = d;
                    b.$currentTarget.data("aw-mash", b.data)
                }
            };
            this.removeServices = function() {
                return h.try(function(a) {
                    n(".atcFormServiceAsinData").remove();
                    e.publish(d.ATC_FORM_REMOVE_SUCCESS);
                    a()
                }).catch(function(a) {
                    e.publish(d.ATC_FORM_REMOVE_FAIL);
                    throw a;
                })
            }
        }
    });
    "use strict";
    t = "function" === typeof Symbol && "symbol" === typeof Symbol.iterator ? function(a) {
        return typeof a
    } : function(a) {
        return a &&
            "function" === typeof Symbol && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a
    };
    p.when("a-util").register("query-param", function(a) {
        var b = function d() {
            var b = this;
            m(this, d);
            this._queryString = "";
            this._parameters = {};
            this.getParameters = function() {
                var a = d._getQueryStringFromBrowser();
                if (a === b._queryString) return b._parameters;
                b._queryString = a;
                b._queryString.slice(1).split("\x26").map(function(a) {
                    a = a.split("\x3d");
                    if (a.length && a[0].length) {
                        var d = decodeURIComponent(a[0]);
                        switch (a.length) {
                            case 2:
                                b._parameters[d] =
                                    decodeURIComponent(a[1]);
                                break;
                            case 1:
                                b._parameters[d] = null
                        }
                    }
                });
                return b._parameters
            };
            this.getParameter = function(a) {
                return b.getParameters()[a]
            };
            this.parameterExists = function(a) {
                return b.getParameters().hasOwnProperty(a)
            };
            this.setParameters = function(h) {
                if ("object" !== ("undefined" === typeof h ? "undefined" : t(h)) || a.isArray(h)) return !1;
                b._queryString = "?" + d.createQueryStringFromObject(h);
                d._setQueryStringOnBrowser(b._queryString);
                return b
            };
            this.setParameter = function(a, d) {
                if (!a || !a.length) return !1;
                var g =
                    b.getParameters();
                g[a] = d;
                return b.setParameters(g)
            };
            this.removeParameter = function(a) {
                if (!a || !a.length) return !1;
                var d = b.getParameters();
                delete d[a];
                return b.setParameters(d)
            };
            this.getQueryString = function() {
                return b._queryString
            }
        };
        b.createQueryStringFromObject = function(a) {
            var b = [];
            Object.keys(a).forEach(function(h) {
                if (!a.hasOwnProperty(h) || "" === h || "" === a[h]) return !1;
                b.push(encodeURIComponent(h) + "\x3d" + encodeURIComponent(a[h]))
            });
            return b.join("\x26")
        };
        b._getQueryStringFromBrowser = function() {
            return location.search.valueOf()
        };
        b._setQueryStringOnBrowser = function(a) {
            "function" === typeof history.replaceState ? history.replaceState({}, document.title, a) : location.search = a
        };
        return b
    });
    "use strict";
    p.when("A", "ship-to-store-settings", "ship-to-store-metric-publisher", "ship-to-store-metric-names", "ship-to-store").register("ship-to-store-helper", function(a, b, e, d) {
        var k = a.$,
            h = !1,
            n = function c() {
                m(this, c)
            };
        n.isShipToStoreEnabled = function(b, f) {
            !(b = "stsPdpOnly" === b) || a.isArray(f) && f.length || (n.hideShipToStore(), b = !1, h || (e.publish(d.NO_OFFERS_ON_PAGE_LOAD),
                e.publish(d.OFFERS_ON_PAGE_LOAD, 0)));
            h = !0;
            return b
        };
        n.hideShipToStore = function() {
            a.hide(k(0 < arguments.length && arguments[0] !== q ? arguments[0] : "#addProfessionalServicesRow"))
        };
        return n
    });
    "use strict";
    var w = function() {
        function a(a, e) {
            for (var d = 0; d < e.length; d++) {
                var k = e[d];
                k.enumerable = k.enumerable || !1;
                k.configurable = !0;
                "value" in k && (k.writable = !0);
                Object.defineProperty(a, k.key, k)
            }
        }
        return function(b, e, d) {
            e && a(b.prototype, e);
            d && a(b, d);
            return b
        }
    }();
    p.when("ship-to-store").register("ship-to-store-uuid", function() {
        var a =
            function() {
                function a() {
                    m(this, a)
                }
                w(a, null, [{
                    key: "getRandomValue",
                    value: function() {
                        var a = crypto || msCrypto;
                        if (a) {
                            var b = new Uint8Array(1);
                            a.getRandomValues(b);
                            return b[0] % 16
                        }
                        return 16 * Math.random()
                    }
                }]);
                return a
            }();
        a.generate = function(b) {
            return b ? (b ^ a.getRandomValue() >> b / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, a.generate)
        };
        return a
    })
});
/* ******** */
(function(q) {
    var e = window.AmazonUIPageJS || window.P,
        y = e._namespace || e.attributeErrors,
        a = y ? y("DetailPageAlohaAssets", "") : e;
    a.guardFatal ? a.guardFatal(q)(a, window) : a.execute(function() {
        q(a, window)
    })
})(function(q, e, y) {
    q.when("A", "a-secondary-view", "a-checkbox", "aloha-simplebundle-common", "ready").execute(function(a, e, v, d) {
        function l(c, d) {
            a.$(b.SB_ROOT + " " + b.SB_CHECKBOX).filter(function() {
                return a.$(this).data("asin") === c
            }).find("input[type\x3d'checkbox']").prop("checked", d).change()
        }

        function c(a) {
            (a = e.get("SBPopover_" +
                a)) && a.hide()
        }

        function t() {
            var c = a.$(b.BUY_BOX).find(b.A_DECLARATIVE).has(b.ADD_TO_CART_BUTTON);
            return 1 === c.length ? c : c = a.$(b.ATC_DECLARATIVE)
        }

        function m(b) {
            function d() {
                b.logExpandedLink()
            }
            a.declarative("add-to-order", "click", function(a) {
                l(a.data.targetAsin, !0);
                c(a.data.targetAsin)
            });
            a.declarative("hide-secondary-view", "click", function(a) {
                l(a.data.targetAsin, !1);
                c(a.data.targetAsin)
            });
            a.on("a:popover:afterShow:modal-expanded-items", d);
            a.one("a:pageUpdate", function() {
                a.off("a:popover:afterShow:modal-expanded-items",
                    d)
            })
        }
        var b = {
                ADD_TO_CART_FORM: "#addToCart, #mobile-installments",
                ADD_TO_CART_BUTTON: "#add-to-cart-button, #installments-button",
                SESSION_ID: "#verificationSessionID",
                ATC_DECLARATIVE: "#atc-declarative",
                A_DECLARATIVE: ".a-declarative",
                BUY_BOX: "#buybox",
                INPUT_TYPE_CHECKBOX: "input[type\x3d'checkbox']",
                BASE_PRODUCT_PRICE: "#base-product-price",
                BASE_PRODUCT_PRICE_DATA: "base-product-price",
                ACCORDION_BUYBOX: "#buyBoxAccordion",
                ACCORDION_BUYBOX_ROW_CONTENT: "#buyBoxAccordion .accordion-row-content",
                SB_ROOT: ".showBundleAsins.simpleBundleFeatureContainer",
                SB_DETAILS_LINK_PREFIX: ".sb-touch-link-",
                SB_CHECKBOX: ".sb-checkbox",
                SB_BUYBOX_CHECKBOX_PREFIX: ".sb-buybox-item-checkbox-",
                SB_EXPANDED_CHECKBOX_PREFIX: ".sb-expanded-item-checkbox-",
                SB_BUYBOX_CHECKBOX_CONTAINER_PREFIX: ".sb-buybox-item-section-",
                SB_EXPANDED_CHECKBOX_CONTAINER_PREFIX: ".sb-buybox-item-container-"
            },
            q = !1;
        v = a.debounce(function() {
            var c = a.$(b.SB_ROOT);
            if (c.length) {
                var l = a.$(b.ADD_TO_CART_FORM),
                    e = 0 < l.find(":submit").length,
                    A = a.$(b.ADD_TO_CART_BUTTON),
                    w = t(),
                    F = (w = w.data("aw-mash") || w.data("show-services-interstitial") ||
                        w.data("show-attach-interstitial")) && w.inputs && w.inputs.verificationSessionID;
                if (e || w) {
                    var g = d.getSimpleBundlePageState() || {},
                        B = g.expandedBuyboxEnabled,
                        u = g.selectionMode || "SINGLE",
                        n = g.items || [],
                        p = [],
                        r = F || a.$(b.SESSION_ID).val(),
                        e = {
                            baseAsin: g.baseAsin,
                            baseItemPrice: a.$(b.BASE_PRODUCT_PRICE).data(b.BASE_PRODUCT_PRICE_DATA),
                            clientType: "aloha-simplebundle-mobile",
                            currencyOfPreferenceSupported: g.currencyOfPreferenceSupported || !1
                        },
                        h = d.createMetricsLogger(e);
                    m(h);
                    n.forEach(function(a, k) {
                        var r = c.find(b.SB_DETAILS_LINK_PREFIX +
                            k);
                        r.unbind("click.MiniDpClickHandler");
                        r.bind("click.MiniDpClickHandler", function() {
                            h.logItemLink(k);
                            h.logNexusOpenMiniDP(k, a);
                            h.logMiniDPRefTag(k)
                        });
                        d.setupCheckboxes(p, k, B, a.asin, g.maxBuyboxItemsMobile, b.SB_BUYBOX_CHECKBOX_PREFIX + k + " " + b.INPUT_TYPE_CHECKBOX, b.SB_EXPANDED_CHECKBOX_PREFIX + k + " " + b.INPUT_TYPE_CHECKBOX, b.SB_BUYBOX_CHECKBOX_CONTAINER_PREFIX + k, b.SB_EXPANDED_CHECKBOX_CONTAINER_PREFIX + k, u)
                    });
                    q || (q = !0, a.defer(function() {
                        var a = n.filter(function(a, h) {
                            return p[h] && p[h].isVisible()
                        });
                        h.logNexusImpression(a);
                        h.logImpressionRefTag()
                    }));
                    w ? A.each(function() {
                        var f = a.$(this),
                            k;
                        k = a.$(b.ACCORDION_BUYBOX).length ? f.closest(b.ACCORDION_BUYBOX_ROW_CONTENT) : a.$(b.BUY_BOX);
                        d.setupAddToCartForDeclarative(f, p, n, h, r, B, k)
                    }) : d.setupAddToCart(l, p, n, h, r, B);
                    l = a.$("#buyNowCheckout");
                    d.setupAddToCart(l, p, n, h, r, B)
                } else c.hide()
            }
        }, 200);
        v();
        a.on("a:pageUpdate", v)
    });
    "use strict";
    q.when("A", "a-checkbox", "aloha-uatc", "aloha-buy-now-integration", "aloha-buybox-form-util").register("aloha-simplebundle-common", function(a, E, v, d, l) {
        function c(b,
            c) {
            var d = a.$(b);
            d.change(function() {
                d.prop("checked", this.checked)
            });
            var g = a.$(c);
            g.length || (g = d);
            return {
                $element: d,
                $container: g,
                api: E(b),
                show: function() {
                    g.hasClass(z.AUI_HIDDEN) && g.removeClass(z.AUI_HIDDEN);
                    g.show()
                },
                hide: function() {
                    g.hasClass(z.AUI_HIDDEN) || g.addClass(z.AUI_HIDDEN)
                },
                isVisible: function() {
                    return !g.hasClass(z.AUI_HIDDEN)
                }
            }
        }

        function t(a, b, c) {
            b.forEach(function(b) {
                a.addItem(b.asin, b.offerListingId, b.quantity);
                c.logCheckboxSelected(b.index, b.quantity);
                c.logAddToCartRefTag(b.index)
            })
        }

        function m(a, b, c) {
            var g = [],
                d = [];
            b.forEach(function(b, l) {
                var p = a[l];
                b.api.isChecked() ? g.push({
                    asin: p.asin,
                    offerListingId: p.offerListingId,
                    ourPrice: p.ourPrice,
                    ourPriceAmount: p.ourPriceAmount,
                    ourPriceSymbol: p.ourPriceSymbol,
                    ourPriceCode: p.ourPriceCode,
                    index: l,
                    quantity: c
                }) : d.push({
                    asin: p.asin,
                    ourPrice: p.ourPrice,
                    ourPriceAmount: p.ourPriceAmount,
                    ourPriceSymbol: p.ourPriceSymbol,
                    ourPriceCode: p.ourPriceCode,
                    index: l,
                    isVisible: b.isVisible()
                })
            });
            return {
                selectedLineItems: g,
                unselectedItems: d
            }
        }
        var b = /[^\d,\.]/g,
            D = /,/g,
            C = /\./g,
            y = /(^\D+|\D+$)/,
            z = {
                AUI_HIDDEN: "aok-hidden"
            };
        return {
            createMetricsLogger: function(c) {
                function d(a, b) {
                    e.ue && e.ue.count && e.ue.count("aloha-simplebundle-" + a, b)
                }

                function l() {
                    var a;
                    a = c.currencyOfPreferenceSupported ? {
                        priceFormatted: c.baseItemPrice,
                        priceDecimal: null,
                        currencySymbol: null
                    } : n(c.baseItemPrice);
                    return {
                        baseAsin: c.baseAsin,
                        baseItemPrice: a.priceFormatted,
                        baseItemCurrencySymbol: a.currencySymbol,
                        baseItemPriceDecimal: a.priceDecimal,
                        clientType: c.clientType,
                        feature: "abb"
                    }
                }

                function g(a, b) {
                    e.ue &&
                        e.ue.event && e.ue.event(a, "atch", b)
                }

                function m(b) {
                    a.ajax("/gp/product/ajax-handlers/reftag.html?ref_\x3d" + b, {
                        method: "get"
                    })
                }

                function u(a) {
                    return c.currencyOfPreferenceSupported ? {
                        priceFormatted: a.ourPrice,
                        priceDecimal: parseFloat(a.ourPriceAmount) || null,
                        currencySymbol: a.ourPriceSymbol
                    } : n(a.ourPrice)
                }

                function n(a) {
                    a = a || "";
                    var c = a.lastIndexOf(","),
                        h = a.lastIndexOf("."),
                        f;
                    c > h ? (h = C, f = D) : (h = D, f = C);
                    (c = a.match(y)) && (c = c[0].trim());
                    h = a.replace(b, "").replace(h, "").replace(f, ".");
                    h = parseFloat(h);
                    return {
                        priceFormatted: a,
                        currencySymbol: c,
                        priceDecimal: h
                    }
                }
                a.defer(function() {
                    d("view", 1)
                });
                return {
                    logAddToCart: function(a) {
                        d("addtocart", a)
                    },
                    logExpandedLink: function() {
                        d("buybox-expanded-link", 1)
                    },
                    logCheckboxSelected: function(a, b) {
                        d("checkbox-" + (a + 1), b)
                    },
                    logItemLink: function(a) {
                        d("link-" + (a + 1), 1)
                    },
                    logImpressionRefTag: function() {
                        m("dp_atch_abb_i")
                    },
                    logAddToCartRefTag: function(a) {
                        m("dp_atch_abb_atc_" + (a + 1))
                    },
                    logMiniDPRefTag: function(a) {
                        m("dp_atch_abb_smdp_" + (a + 1))
                    },
                    logNexusImpression: function(a) {
                        var b = l();
                        b.accessories = a.map(function(a,
                            b) {
                            var c = u(a);
                            return {
                                asin: a.asin,
                                displayPosition: b + 1,
                                price: c.priceFormatted,
                                currencySymbol: c.currencySymbol,
                                priceDecimal: c.priceDecimal
                            }
                        });
                        g(b, "attach.ABBImpression.3")
                    },
                    logNexusAddBaseToCart: function(a, b, c) {
                        var f = l();
                        f.baseQuantity = Number(c);
                        f.accessoriesAdded = a.map(function(a) {
                            var b = u(a);
                            return {
                                asin: a.asin,
                                displayPosition: a.index + 1,
                                quantity: Number(a.quantity),
                                price: b.priceFormatted,
                                currencySymbol: b.currencySymbol,
                                priceDecimal: b.priceDecimal
                            }
                        });
                        f.accessoriesNotAdded = b.map(function(a) {
                            var b = u(a);
                            return {
                                asin: a.asin,
                                displayPosition: a.index + 1,
                                price: b.priceFormatted,
                                currencySymbol: b.currencySymbol,
                                priceDecimal: b.priceDecimal
                            }
                        });
                        g(f, "attach.ABBAddBaseToCart.7")
                    },
                    logNexusOpenMiniDP: function(a, b) {
                        var c = u(b),
                            f = l();
                        f.accessoryAsin = b.asin;
                        f.accessoryDisplayPosition = Number(a) + 1;
                        f.accessoryPrice = c.priceFormatted;
                        f.accessoryItemCurrencySymbol = c.currencySymbol;
                        f.accessoryItemPriceDecimal = c.priceDecimal;
                        g(f, "attach.ABBShowMiniDP.3")
                    }
                }
            },
            getSimpleBundlePageState: function() {
                var b = a.$(".simpleBundleJavascriptParameters").find("script").html();
                return a.parseJSON(b)
            },
            getCheckboxCollectionObject: c,
            setupAddToCart: function(b, c, l, g, q, u) {
                function n(b, f) {
                    if (p) {
                        var k = a.$(b.currentTarget);
                        if (d.isBuyNow(k)) {
                            var x = u ? 1 : r.find("*[name\x3d'quantity']").val() || 1,
                                n = m(l, c, x);
                            d.checkoutWith(n.selectedLineItems, k)
                        } else return
                    }
                    var A = v.createAddToCartRequest(q, function() {
                            f()
                        }, function() {
                            e.ueLogError && e.ueLogError({
                                message: "[There was an error while adding items to the cart using the universal add to cart api.]"
                            }, {
                                logLevel: "ERROR",
                                attribution: "SimpleBundle"
                            });
                            f()
                        }),
                        x = u ? 1 : r.find("*[name\x3d'quantity']").val() || 1,
                        n = m(l, c, x);
                    t(A, n.selectedLineItems, g);
                    k = n.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    g.logNexusAddBaseToCart(n.selectedLineItems, k, x);
                    x = A.count();
                    0 !== x && (k = a.$(b.currentTarget), d.isBuyNow(k) ? d.checkoutWith(n.selectedLineItems, k) : (p = !0, b.preventDefault(), g.logAddToCart(x), A.call()))
                }
                var p = !1,
                    r = b;
                b.unbind("submit.SimpleBundleSubmitHandler");
                b.bind("submit.SimpleBundleSubmitHandler", function(b) {
                    var c = a.$(this);
                    n(b, function() {
                        c.submit()
                    })
                });
                b.find(":submit").unbind("click.SBB");
                b.find(":submit").bind("click.SBB", function(b) {
                    var c = a.$(this),
                        d = c.closest(".a-accordion-row-container");
                    d.length && (r = d, n(b, function() {
                        c.click()
                    }))
                })
            },
            setupAddToCartForDeclarative: function(a, b, c, d, l, u, n) {
                a.unbind("click.SimpleBundleClickHandler");
                a.bind("click.SimpleBundleClickHandler", function(a) {
                    a = v.createAddToCartRequest(l, function() {
                            q.now("attach-external-atc-interceptor").execute(function(a) {
                                a && h.selectedLineItems.forEach(function(b) {
                                    a.updateAttachModule(b.asin)
                                })
                            })
                        },
                        function() {
                            e.ueLogError && e.ueLogError({
                                message: "[There was an error while adding items to the cart using the universal add to cart api.]"
                            }, {
                                logLevel: "ERROR",
                                attribution: "SimpleBundle"
                            })
                        });
                    var r = u ? 1 : n.find("*[name\x3d'quantity']").val() || 1,
                        h = m(c, b, r);
                    t(a, h.selectedLineItems, d);
                    var f = h.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    d.logNexusAddBaseToCart(h.selectedLineItems, f, r);
                    if (r = a.count()) d.logAddToCart(r), a.call()
                })
            },
            setupCheckboxes: function(a, b, d, l, m, e, n, p, r, h) {
                var f = c(e, p);
                a.push(f);
                f.api.enable();
                f.$element.data("asin", l);
                if (d) {
                    var k = c(n, r);
                    k.api.enable();
                    k.api.check(f.api.isChecked());
                    k.$element.change(function() {
                        var a = k.api.isChecked();
                        f.api.check(a)
                    });
                    f.$element.change(function() {
                        var b = f.api.isChecked();
                        k.api.check(b);
                        var c = 0;
                        a.forEach(function(a) {
                            c < m && a.api.isChecked() ? (c++, a.show()) : a.hide()
                        });
                        c < m && a.forEach(function(a) {
                            c < m && a.api.isUnchecked() && (c++, a.show())
                        })
                    })
                } else "SINGLE" === h && f.$element.change(function() {
                    f.api.isChecked() && a.forEach(function(a, c) {
                        b !== c && a.api.uncheck()
                    })
                });
                0 < a.length && a[0].$element.change()
            },
            setupAddToCartForButton: function(b, c, d, g, e, v, n) {
                function p() {
                    var a = v ? 1 : r.find("*[name\x3d'quantity']").val() || 1,
                        b = m(d, c, a);
                    l.addItems(n, b.selectedLineItems, g);
                    var k = b.unselectedItems.filter(function(a) {
                        return a.isVisible
                    });
                    q.now("attach-external-atc-interceptor").execute(function(a) {
                        a && b.selectedLineItems.forEach(function(b) {
                            a.updateAttachModule(b.asin)
                        })
                    });
                    g.logNexusAddBaseToCart(b.selectedLineItems, k, a);
                    g.logAddToCart(b.selectedLineItems.length)
                }
                var r = n;
                b.unbind("click.button.SBB");
                b.bind("click.button.SBB", function() {
                    var b = a.$(this).closest(".a-accordion-row-container");
                    b.length && (r = b);
                    p()
                })
            }
        }
    });
    "use strict";
    q.when("A").register("aloha-uatc", function(a) {
        function e(q, d, l, c, t) {
            var m = 0;
            t = t || 5E3;
            c = c || l;
            var b = {
                clientName: "AmazonWireless"
            };
            b.verificationSessionID = q;
            return {
                count: function() {
                    return m
                },
                call: function() {
                    m && a.post("/gp/add-to-cart/json", {
                        timeout: t,
                        params: b,
                        success: d,
                        error: l,
                        abort: c
                    })
                },
                addItem: function(a, c, d) {
                    b["ASIN." + m] = a;
                    b["offerListingID." + m] = c;
                    b["quantity." + m] = d || 1;
                    m++
                }
            }
        }
        return {
            createAddToCartRequest: e,
            createSingleFinalCallbackAddToCartRequest: function(a, d) {
                return e(a, d, d, d)
            }
        }
    });
    "use strict";
    q.when("ready").register("aloha-buy-now-integration", function() {
        var a = {};
        q.when("turbo-checkout-buy-now-integration").execute(function(e) {
            a = e
        });
        return {
            isBuyNow: function(e) {
                return "function" === typeof a.isBuyNow && a.isBuyNow(e)
            },
            checkoutWith: function(e, q) {
                return a.checkoutWith(e, q)
            }
        }
    });
    "use strict";
    q.when("A").register("aloha-buybox-form-util", function(a) {
        function e(a) {
            for (var c =
                    2; 0 < a.find('input[name\x3d"asin.' + c + '"]').length || 0 < a.find('input[name\x3d"offeringID.' + c + '"]').length;) c++;
            return c
        }

        function q(d, c) {
            return [a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "asin." + c,
                value: d.asin,
                class: "aloha-accessory-form-input"
            }), a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "offeringID." + c,
                value: d.offerListingId,
                class: "aloha-accessory-form-input"
            }), a.$("\x3cinput /\x3e", {
                type: "hidden",
                name: "quantity." + c,
                value: d.quantity || 1,
                class: "aloha-accessory-form-input"
            })]
        }
        var d = [];
        a.on("aloha:detailPage:reappear",
            function() {
                d = [];
                a.$(".aloha-accessory-form-input").remove()
            });
        return {
            addItems: function(a, c, t) {
                var m = e(a);
                c.forEach(function(b) {
                    if (b !== y && b.asin && b.offerListingId) {
                        var c = q(b, m);
                        c.forEach(function(b) {
                            a.append(b)
                        });
                        d.push(c);
                        m++;
                        t && (t.logCheckboxSelected(b.index, b.quantity), t.logAddToCartRefTag(b.index))
                    }
                });
                c = a.find('input[name\x3d"itemCount"]');
                0 === c.length ? a.append('\x3cinput type\x3d"hidden" name\x3d"itemCount" value\x3d"' + m + '"\x3e') : c[0].value = m
            }
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageBTFSubNavAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageEstimatedExtraTaxAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPagePrePurchaseSupportAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageMiniDPAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(m) {
    var h = window.AmazonUIPageJS || window.P,
        e = h._namespace || h.attributeErrors,
        c = e ? e("ABPricingFreeFormQuantityPickerAssets", "") : h;
    c.guardFatal ? c.guardFatal(m)(c, window) : c.execute(function() {
        m(c, window)
    })
})(function(m, h, e) {
    m.when("jQuery", "A", "ready").execute(function(c, k) {
        function l(c) {
            h.ue !== e && h.ue.count !== e && h.ue.count(c, (h.ue.count(c) || 0) + 1)
        }

        function n() {
            return k.state("ABPricingFreeFormQuantityPicker")
        }

        function g(c, a) {
            return 0 !== c.find('option[value\x3d"' + a.toString() + '"]').length
        }

        function q() {
            p ||
                n() === e || (p = !0, m.register("abPricingFfqp_utils", function() {
                    return {
                        PACKAGE_PREFIX: "ABPricingFreeFormQuantityPicker",
                        getPageState: n,
                        incrementMetricByOne: l,
                        dropdownContainsQuantity: g
                    }
                }))
        }
        var p = !1;
        q();
        m.register("abPricingFfqp_lazyInitializer", function() {
            return {
                tryInitialize: q
            }
        })
    });
    "use strict";
    m.when("jQuery", "A", "abPricingFfqp_utils").register("abPricingFfqp_quantityManager", function(c, k, l) {
        function n(b) {
            for (var a = "", f = 0; f < b; f++) a += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(Math.floor(62 *
                Math.random()));
            return a
        }

        function g(b, a) {
            return (b = (new RegExp("(?:^|\\?|\x26)" + a + "\x3d(?:([^\x26#]*)|\x26|#|$)")).exec(b)) ? b[1] ? decodeURIComponent(b[1].replace(/\+/g, " ")) : "" : e
        }

        function q(b, a, f) {
            var c = b.split("#");
            b = c[0];
            b = "?" === b[0] ? b.substr(1) : b;
            c = c[1];
            f !== e ? (f = a + "\x3d" + f, a = new RegExp("(^|\x26)(" + a + "\x3d[^\x26]*)"), b = a.test(b) ? b.replace(a, "$1" + f) : b + ((0 !== b.length ? "\x26" : "") + f)) : (a = new RegExp("(^|\x26)(" + a + "\x3d[^\x26]*)"), a.test(b) && (b = b.replace(a, ""), "\x26" === b[0] && (b = b.substr(1))));
            return "?" +
                b + (c !== e ? "#" + c : "")
        }

        function p(b) {
            var a = h.location.protocol + "//" + h.location.host + h.location.pathname,
                f = h.location.search,
                c;
            for (c in b) b.hasOwnProperty(c) && (f = q(f, c, b[c]));
            return a + f
        }

        function d(b) {
            if (h.history !== e && h.history.pushState !== e) {
                var a = {};
                a.qty = b;
                h.history.pushState({}, "", p(a))
            }
        }

        function a() {
            var b = parseInt(g(h.location.search, "qty"));
            this.currentQuantity = isNaN(b) ? 1 : b;
            this.wireUpSelectorBasedEvents()
        }
        var b = l.PACKAGE_PREFIX + ".QuantityRefreshCheckError",
            f = l.PACKAGE_PREFIX + ".PriceTableLoadError";
        a.prototype.getCurrentQuantity = function() {
            return this.currentQuantity
        };
        a.prototype.wireUpSelectorBasedEvents = function() {
            var b = this;
            m.when("A", "jQuery", "quanityChangePriceUpdate").execute(function(a, f, c) {
                b.quantityChangePriceUpdater = c;
                a.on("a:pageUpdate", function() {
                    b.handleTwisterPageRefresh()
                })
            })
        };
        a.prototype.update3PPriceBlock = function() {
            if (!(this.leastMinimumOrderQuantity === e || 1 >= this.leastMinimumOrderQuantity)) {
                var b = c(".price3P");
                b.hasClass("updatedPrice3P") || (b.addClass("updatedPrice3P"), this.quantityChangePriceUpdater.ajaxCall({
                    qt: this.leastMinimumOrderQuantity,
                    quantityPriceField: "quantity_price"
                }))
            }
        };
        a.prototype.handleTwisterPageRefresh = function() {
            this.update3PPriceBlock()
        };
        a.prototype.reloadPageForQuantity = function(b, a) {
            var f = {};
            f.qty = b;
            f.psc = 1;
            a !== e && (a.refTag !== e && (f.ref_ = a.refTag), a.activeBuyBoxId !== e && (f.selectObb = a.activeBuyBoxId));
            h.location.href = p(f)
        };
        a.prototype.notifyQuantityChanged = function(a, f) {
            k.trigger("buyBoxQuantityChanged", f.senderId, a);
            this.currentQuantity = a;
            d(a);
            if (!0 !== f.preventRefreshCheck) {
                var c = this,
                    g = l.getPageState();
                k.trigger("quantityRefreshCheckStarted");
                k.get("/gp/product/ajax-handlers/quantity-page-refresh.html", {
                    params: {
                        asin: g.asin,
                        quantity: a,
                        refreshData: g.lastRefreshData,
                        activeBuyBoxId: f.activeBuyBoxId
                    },
                    timeout: 4E3,
                    error: function() {
                        l.incrementMetricByOne(b);
                        c.reloadPageForQuantity(a, {
                            activeBuyBoxId: f.activeBuyBoxId
                        })
                    },
                    success: function() {
                        k.trigger("quantityRefreshCheckFinished")
                    }
                })
            }
        };
        a.prototype.fetchAllTiersForQuantityDiscountTable = function() {
            var b = l.getPageState();
            "T1" === b.weblab_DPX_AB_VAP_NEW_QUANTITY_PICKER_210547 && k.get("/gp/product/ajax-handlers/quantity-price-table.html", {
                params: {
                    ref: "b2b_qd_dp",
                    asin: b.asin,
                    cb: n(20),
                    qptResponseFormat: "json"
                },
                timeout: 4E3,
                error: function() {
                    l.incrementMetricByOne(f)
                },
                success: function(b) {
                    k.trigger("fetchQuantityDiscountTableCompleted", b)
                }
            })
        };
        return {
            EVENT__BUY_BOX_QUANTITY_CHANGED: "buyBoxQuantityChanged",
            EVENT__QUANTITY_REFRESH_CHECK_STARTED: "quantityRefreshCheckStarted",
            EVENT__QUANTITY_REFRESH_CHECK_FINISHED: "quantityRefreshCheckFinished",
            EVENT__FETCH_QUANTITY_DISCOUNT_TABLE_COMPLETED: "fetchQuantityDiscountTableCompleted",
            getUrlParameter: g,
            replaceUrlParameter: q,
            singleton: new a
        }
    });
    "use strict";
    m.when("jQuery", "A", "a-dropdown", "a-button", "abPricingFfqp_utils", "abPricingFfqp_quantityManager").register("abPricingFfqp_quantityPickerLogic", function(c, k, l, n, g, h) {
        function p(b) {
            return b.prop("selectedIndex") + 1 === b.prop("length")
        }

        function d(b, a) {
            if (!g.dropdownContainsQuantity(b, a)) {
                var c = document.createElement("option");
                c.value = a;
                c.text = a.toString();
                b.append(c)
            }
        }

        function a(b) {
            this.id = b.id;
            this.buyBoxId = b.buyBoxId;
            this.quantityHiddenFieldSelector =
                b.quantityHiddenFieldSelector;
            this.leastMinimumOrderQuantity = b.leastMinimumOrderQuantity;
            this.predefinedQuantitiesDropdownSelector = b.predefinedQuantitiesDropdownSelector;
            this.predefinedQuantitiesDropdownContainerSelector = b.predefinedQuantitiesDropdownContainerSelector;
            this.freeQuantityTextInputSelector = b.freeQuantityTextInputSelector;
            this.freeQuantityTextInputOuterSelector = b.freeQuantityTextInputOuterSelector;
            this.updateButtonSelector = b.updateButtonSelector;
            this.addToCartButtonSelector = b.addToCartButtonSelector;
            this.wireUpSelectorBasedEvents()
        }
        a.prototype.wireUpSelectorBasedEvents = function() {
            var b = this,
                a = c(this.predefinedQuantitiesDropdownSelector);
            k.on("a:dropdown:" + a[0].id + ":select", function(a) {
                b.handleDropdownOptionClicked(a.value)
            });
            k.on(h.EVENT__BUY_BOX_QUANTITY_CHANGED, function(a, f) {
                b.handleQuantityChangedOnOtherBuyBox(a, f)
            });
            k.on(h.EVENT__QUANTITY_REFRESH_CHECK_STARTED, function() {
                b.handleQuantityRefreshCheckStarted()
            });
            k.on(h.EVENT__QUANTITY_REFRESH_CHECK_FINISHED, function() {
                b.handleQuantityRefreshCheckFinished()
            })
        };
        a.prototype.wireUpReferenceBasedEvents = function() {
            var b = this,
                a = c(this.freeQuantityTextInputSelector),
                d = c(this.updateButtonSelector);
            a.keydown(function(a) {
                b.handleTextInputKeyDown(a)
            });
            a.keyup(function(a) {
                b.handleTextInputKeyUp(a)
            });
            a.focus(function() {
                b.handleTextInputFocused()
            });
            d.click(function() {
                b.handleButtonClick()
            })
        };
        a.prototype.attachToDOM = function() {
            this.wireUpReferenceBasedEvents();
            p(c(this.predefinedQuantitiesDropdownSelector)) ? this.switchToFreeQuantityUI() : this.switchToPredefinedQuantitiesUI();
            this.enableUI();
            this.lastSelectedQuantity = this.getCurrentQuantity();
            h.singleton.leastMinimumOrderQuantity = this.leastMinimumOrderQuantity
        };
        a.prototype.getCurrentQuantity = function() {
            if (this.isTextInputVisible()) {
                var b = c(this.freeQuantityTextInputSelector);
                return parseInt(b.val())
            }
            return this.isDropdownVisible() ? (b = c(this.predefinedQuantitiesDropdownSelector), parseInt(b.find(":selected").val())) : e
        };
        a.prototype.handleQuantityRefreshCheckStarted = function() {
            this.doesDOMExist() && this.disableUI()
        };
        a.prototype.handleQuantityRefreshCheckFinished =
            function() {
                this.doesDOMExist() && this.enableUI()
            };
        a.prototype.handleDropdownOptionClicked = function(b) {
            var a = c(this.predefinedQuantitiesDropdownSelector);
            p(a) ? (b = c(this.freeQuantityTextInputSelector), b.val(this.lastSelectedQuantity.toString()), this.switchToFreeQuantityUI(), b.focus(), g.incrementMetricByOne("freeFormQtyPickerMaxQtySelected")) : (this.lastSelectedQuantity = b = parseInt(b), this.updateQuantityHiddenField(b), h.singleton.notifyQuantityChanged(b, {
                senderId: this.id,
                activeBuyBoxId: this.buyBoxId
            }))
        };
        a.prototype.handleTextInputFocused = function() {
            c(this.freeQuantityTextInputSelector).select()
        };
        a.prototype.handleTextInputKeyUp = function(b) {
            13 !== b.keyCode && n(this.updateButtonSelector).show()
        };
        a.prototype.handleTextInputKeyDown = function(b) {
            13 === b.keyCode && (b.preventDefault(), c(this.updateButtonSelector).click(), c(this.addToCartButtonSelector).focus())
        };
        a.prototype.clampQuantity = function(b) {
            999 < b && (b = 999);
            this.leastMinimumOrderQuantity !== e && b < this.leastMinimumOrderQuantity && (b = this.leastMinimumOrderQuantity);
            return b
        };
        a.prototype.handleButtonClick = function() {
            var b = c(this.predefinedQuantitiesDropdownSelector),
                a = l.getSelect(b[0]),
                d = c(this.freeQuantityTextInputSelector),
                k = d.val(),
                e = parseInt,
                p = k.match(/[1-9][0-9]*/),
                e = e(null === p ? "1" : p[0]),
                e = this.clampQuantity(e);
            g.dropdownContainsQuantity(b, e) ? (this.switchToPredefinedQuantitiesUI(), a.setValue(e.toString()), this.handleDropdownOptionClicked(e)) : (b = e.toString(), b !== k && d.val(b), n(this.updateButtonSelector).hide(), this.updateQuantityHiddenField(e), h.singleton.notifyQuantityChanged(e, {
                senderId: this.id,
                activeBuyBoxId: this.buyBoxId
            }))
        };
        a.prototype.doesDOMExist = function() {
            return 0 < c(this.predefinedQuantitiesDropdownSelector).length && 0 < c(this.freeQuantityTextInputSelector).length && 0 < c(this.updateButtonSelector).length
        };
        a.prototype.handleQuantityChangedOnOtherBuyBox = function(b, a) {
            if (b !== this.id && this.doesDOMExist() && this.getCurrentQuantity() !== a) {
                b = c(this.predefinedQuantitiesDropdownSelector);
                var d = l.getSelect(b[0]);
                g.dropdownContainsQuantity(b, a) ? (d.setValue(a.toString()), this.lastSelectedQuantity =
                    a, this.switchToPredefinedQuantitiesUI()) : (c(this.freeQuantityTextInputSelector).val(a.toString()), this.switchToFreeQuantityUI());
                "T1" === g.getPageState().weblab_DP_RD_BUZZ_FFQP_186811 && this.updateQuantityHiddenField(a)
            }
        };
        a.prototype.showDropdown = function() {
            c(this.predefinedQuantitiesDropdownContainerSelector).removeClass("aok-hidden")
        };
        a.prototype.hideDropdown = function() {
            c(this.predefinedQuantitiesDropdownContainerSelector).addClass("aok-hidden")
        };
        a.prototype.isDropdownVisible = function() {
            return !c(this.predefinedQuantitiesDropdownContainerSelector).hasClass("aok-hidden")
        };
        a.prototype.showTextInput = function() {
            "mobile" === g.getPageState().platform ? c(this.freeQuantityTextInputOuterSelector).removeClass("aok-hidden") : c(this.freeQuantityTextInputSelector).removeClass("aok-hidden")
        };
        a.prototype.hideTextInput = function() {
            "mobile" === g.getPageState().platform ? c(this.freeQuantityTextInputOuterSelector).addClass("aok-hidden") : c(this.freeQuantityTextInputSelector).addClass("aok-hidden")
        };
        a.prototype.isTextInputVisible = function() {
            return "mobile" === g.getPageState().platform ? !c(this.freeQuantityTextInputOuterSelector).hasClass("aok-hidden") :
                !c(this.freeQuantityTextInputSelector).hasClass("aok-hidden")
        };
        a.prototype.disableTextInput = function() {
            if ("mobile" === g.getPageState().platform) {
                var b = c(this.freeQuantityTextInputSelector),
                    a = c(this.freeQuantityTextInputOuterSelector);
                b.prop("disabled", "disabled");
                a.addClass("a-form-disabled")
            } else b = c(this.freeQuantityTextInputSelector), b.prop("disabled", "disabled"), b.addClass("a-form-disabled")
        };
        a.prototype.enableTextInput = function() {
            if ("mobile" === g.getPageState().platform) {
                var b = c(this.freeQuantityTextInputSelector),
                    a = c(this.freeQuantityTextInputOuterSelector);
                b.removeProp("disabled");
                a.removeClass("a-form-disabled")
            } else b = c(this.freeQuantityTextInputSelector), b.removeProp("disabled"), b.removeClass("a-form-disabled")
        };
        a.prototype.switchToFreeQuantityUI = function() {
            this.hideDropdown();
            this.showTextInput();
            n(this.updateButtonSelector).hide()
        };
        a.prototype.switchToPredefinedQuantitiesUI = function() {
            this.showDropdown();
            this.hideTextInput();
            n(this.updateButtonSelector).hide()
        };
        a.prototype.disableUI = function() {
            var b =
                l.getSelect(this.predefinedQuantitiesDropdownSelector),
                a = n(this.updateButtonSelector);
            b.update({
                status: "disabled"
            });
            this.disableTextInput();
            a.disable()
        };
        a.prototype.enableUI = function() {
            var b = l.getSelect(this.predefinedQuantitiesDropdownSelector),
                a = n(this.updateButtonSelector);
            b.update({
                status: "normal"
            });
            this.enableTextInput();
            a.enable()
        };
        a.prototype.updateQuantityHiddenField = function(b) {
            var a = c(this.quantityHiddenFieldSelector);
            a.is("select") ? (d(a, b), l.getSelect(a).val(b)) : a.val(b.toString());
            "mobile" ===
            g.getPageState().platform && "select#mobileQuantityDropDown" !== this.quantityHiddenFieldSelector && (a = c("select#mobileQuantityDropDown")) && a.is("select") && (d(a, b), l.getSelect(a).val(b))
        };
        return {
            QuantityPickerLogic: a
        }
    });
    "use strict";
    (function(c) {
        c.forEach(function(c) {
            c.hasOwnProperty("append") || Object.defineProperty(c, "append", {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                value: function() {
                    var c = Array.prototype.slice.call(arguments),
                        e = document.createDocumentFragment();
                    c.forEach(function(c) {
                        e.appendChild(c instanceof Node ? c : document.createTextNode(String(c)))
                    });
                    this.appendChild(e)
                }
            })
        })
    })([Element.prototype, Document.prototype, DocumentFragment.prototype]);
    (function(c) {
        c.forEach(function(c) {
            c.hasOwnProperty("prepend") || Object.defineProperty(c, "prepend", {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                value: function() {
                    var c = Array.prototype.slice.call(arguments),
                        e = document.createDocumentFragment();
                    c.forEach(function(c) {
                        e.appendChild(c instanceof Node ? c : document.createTextNode(String(c)))
                    });
                    this.insertBefore(e, this.firstChild)
                }
            })
        })
    })([Element.prototype,
        Document.prototype, DocumentFragment.prototype
    ]);
    m.when("jQuery", "A", "a-dropdown", "abPricingFfqp_utils", "abPricingFfqp_quantityManager").register("abPricingFfqpV2_quantityPickerLogic", function(c, k, l, n, g) {
        function m(a) {
            return 0 === a.length ? 0 : parseInt(a)
        }

        function p(a, b) {
            if (!n.dropdownContainsQuantity(a, b)) {
                var c = document.createElement("option");
                c.value = b;
                c.text = b.toString();
                a.append(c)
            }
        }

        function d(a) {
            this.id = a.id;
            this.buyBoxId = a.buyBoxId;
            this.quantityHiddenFieldSelector = a.quantityHiddenFieldSelector;
            this.leastMinimumOrderQuantity = a.leastMinimumOrderQuantity;
            this.quantityPickerSelector = a.quantityPickerSelector;
            this.quantityTextInputSelector = c(this.quantityPickerSelector).find(".quantity-text-input");
            this.quantityDiscountTableSelector = c(this.quantityPickerSelector).find(".quantity-discount-table");
            this.accordionRowContainerSelector = a.accordionRowContainerSelector;
            this.buyboxAccordionContainerSelector = a.buyboxAccordionContainerSelector;
            this.loadMoreMessage = a.loadMoreMessage;
            this.fetchTheBestPricesMessage =
                a.fetchTheBestPricesMessage;
            this.isLoadMoreButtonClicked = !1;
            this.wireUpSelectorBasedEvents()
        }
        d.prototype.wireUpSelectorBasedEvents = function() {
            var a = this;
            k.on(g.EVENT__FETCH_QUANTITY_DISCOUNT_TABLE_COMPLETED, function(b) {
                a.wireUpQuantityDiscountTableData(b);
                a.generateQuantityDiscountTable()
            });
            k.on(g.EVENT__BUY_BOX_QUANTITY_CHANGED, function(b, c) {
                a.handleQuantityChangedOnOtherBuyBox(b, c)
            });
            k.on(g.EVENT__QUANTITY_REFRESH_CHECK_STARTED, function() {
                a.handleQuantityRefreshCheckStarted()
            });
            k.on(g.EVENT__QUANTITY_REFRESH_CHECK_FINISHED,
                function() {
                    a.handleQuantityRefreshCheckFinished()
                })
        };
        d.prototype.wireUpQuantityDiscountTableData = function(a) {
            this.priceTiers = a
        };
        d.prototype.wireUpReferenceBasedEvents = function() {
            var a = this,
                b = c(this.quantityTextInputSelector);
            b.focus(function() {
                a.showQuantityDiscountTable()
            });
            b.blur(function() {
                a.updateQuantityAndHideQuantityDiscountTable()
            });
            b.keypress(function(b) {
                a.isValidQuantityTextInputKeyCode(b)
            });
            b.live("click change paste keyup", function() {
                a.clampQuantity(b.val());
                a.generateQuantityDiscountTable()
            })
        };
        d.prototype.attachToDOM = function() {
            this.wireUpReferenceBasedEvents();
            this.enableUI();
            g.singleton.leastMinimumOrderQuantity = this.leastMinimumOrderQuantity
        };
        d.prototype.isValidQuantityTextInputKeyCode = function(a) {
            var b = h.event ? a.keyCode : a.which;
            8 !== b && 46 !== b && (13 === b ? (this.updateQuantityAndHideQuantityDiscountTable(), a.preventDefault()) : (b = String.fromCharCode(b), /\d/.test(b) || a.preventDefault()))
        };
        d.prototype.getCurrentQuantity = function() {
            var a = c(this.quantityTextInputSelector);
            return m(a.val())
        };
        d.prototype.handleQuantityRefreshCheckStarted =
            function() {
                this.doesDOMExist() && this.disableUI()
            };
        d.prototype.handleQuantityRefreshCheckFinished = function() {
            this.doesDOMExist() && this.enableUI()
        };
        d.prototype.clampQuantity = function(a) {
            var b = a;
            999 < a && (b = 999);
            this.leastMinimumOrderQuantity !== e && a < this.leastMinimumOrderQuantity && (b = this.leastMinimumOrderQuantity);
            return b
        };
        d.prototype.doesDOMExist = function() {
            return 0 < c(this.quantityTextInputSelector).length
        };
        d.prototype.handleQuantityChangedOnOtherBuyBox = function(a, b) {
            a !== this.id && this.doesDOMExist() &&
                this.getCurrentQuantity() !== b && (c(this.quantityTextInputSelector).val(b), this.updateQuantityHiddenField(b))
        };
        d.prototype.showQuantityDiscountTable = function() {
            var a = c(this.quantityPickerSelector),
                b = c(this.accordionRowContainerSelector),
                f = c(this.buyboxAccordionContainerSelector);
            0 < b.length && (b.get(0).setAttribute("style", "overflow:visible"), b = b.find(".a-accordion-inner.accordion-row-content"), 0 < b.length && b.get(0).setAttribute("style", "overflow:visible"));
            0 < f.length && (f.get(0).setAttribute("style", "overflow:visible"),
                f = f.find(".a-accordion-inner"), 0 < f.length && f.get(0).setAttribute("style", "overflow:visible"));
            a.addClass("open")
        };
        d.prototype.hideQuantityDiscountTable = function() {
            c(this.quantityPickerSelector).removeClass("open")
        };
        d.prototype.updateQuantityAndHideQuantityDiscountTable = function() {
            var a = c(this.quantityDiscountTableSelector),
                b = c(this.quantityTextInputSelector),
                f = this.clampQuantity(b.val());
            b.val(f);
            this.updateQuantityHiddenField(f);
            g.singleton.notifyQuantityChanged(f, {
                senderId: this.id,
                activeBuyBoxId: this.buyBoxId
            });
            this.isLoadMoreButtonClicked = !1;
            this.hideQuantityDiscountTable();
            a.empty()
        };
        d.prototype.disableUI = function() {
            var a = c(this.quantityTextInputSelector),
                b = c(this.quantityDiscountTableSelector);
            a.attr("disabled", !0);
            a.addClass("quantity-text-input-disabled");
            b.attr("disabled", !0)
        };
        d.prototype.enableUI = function() {
            var a = c(this.quantityTextInputSelector),
                b = c(this.quantityDiscountTableSelector);
            a.attr("disabled", !1);
            a.removeClass("quantity-text-input-disabled");
            b.attr("disabled", !1);
            this.hideQuantityDiscountTable()
        };
        d.prototype.updateQuantityHiddenField = function(a) {
            var b = c(this.quantityHiddenFieldSelector);
            b.is("select") ? (p(b, a), l.getSelect(b).val(a)) : b.val(a.toString());
            "mobile" === n.getPageState().platform && "select#mobileQuantityDropDown" !== this.quantityHiddenFieldSelector && (b = c("select#mobileQuantityDropDown")) && b.is("select") && (p(b, a), l.getSelect(b).val(a))
        };
        d.prototype.generateVisibleTiersList = function(a, b) {
            for (var c = [], d = 0; b < this.priceTiers.length && (this.isLoadMoreButtonClicked || 3 > d);) {
                var e = this.priceTiers[b];
                c.push({
                    quantity: 0 === d ? Math.max(a, e.quantity) : e.quantity,
                    savingsMessage: e.savingsMessage,
                    quantityPickerPriceText: e.quantityPickerPriceText,
                    isDiscountUnlocked: 0 === d ? 0 === b && "BUSINESS_VOLUME_AWARE_PRICING" === e.program : !1,
                    isFirstTier: 0 === d
                });
                d++;
                b++
            }
            return c
        };
        d.prototype.findStartIndexOfQuantityDiscountTierTable = function(a) {
            for (var b = 0, c = this.priceTiers.length - 1; b <= c;) {
                var d = parseInt((b + c) / 2),
                    e = m(this.priceTiers[d].quantity);
                if (e === a) return d;
                e > a ? c = d - 1 : b = d + 1
            }
            return Math.max(0, c)
        };
        d.prototype.generateQuantityDiscountTable =
            function() {
                this.cleanOutQuantityDiscountTable();
                var a = c(this.quantityDiscountTableSelector);
                this.priceTiers === e ? a.append(this.generateFetchInProcessTableUnorderedList()) : a.append(this.generateQuantityDiscountTableUnorderedList())
            };
        d.prototype.cleanOutQuantityDiscountTable = function() {
            c(this.quantityDiscountTableSelector).empty()
        };
        d.prototype.generateQuantityDiscountTableUnorderedList = function() {
            var a = c(this.quantityTextInputSelector),
                b = m(a.val()),
                a = this.findStartIndexOfQuantityDiscountTierTable(b),
                b = this.generateVisibleTiersList(b, a),
                f = document.createElement("ul");
            f.setAttribute("class", "qdt-ul");
            for (var d = 0; d < b.length; d++) f.append(this.generateQuantityDiscountTierOption(b[d]));
            !this.isLoadMoreButtonClicked && 3 < this.priceTiers.length - a && f.append(this.generateLoadMoreOption());
            return f
        };
        d.prototype.generateFetchInProcessTableUnorderedList = function() {
            var a = document.createElement("ul");
            a.setAttribute("class", "qdt-ul");
            a.append(this.generateFetchInProcessOption());
            return a
        };
        d.prototype.generateQuantityDiscountTierOption =
            function(a) {
                var b = this,
                    c = document.createElement("li"),
                    d = document.createElement("div"),
                    g = document.createElement("div"),
                    h = document.createElement("div");
                a.isFirstTier ? (g.textContent = a.quantity, c.setAttribute("class", "qdt-dropdown-item qdt-active")) : (g.textContent = a.quantity + "+", c.setAttribute("class", "qdt-dropdown-item"));
                h.textContent = a.quantityPickerPriceText;
                g.setAttribute("class", "option-tier");
                h.setAttribute("class", "option-price");
                if (a.savingsMessage != e) {
                    var k = document.createElement("div"),
                        l = document.createElement("div");
                    l.textContent = a.savingsMessage;
                    if (a.isDiscountUnlocked) {
                        var m = document.createElement("div");
                        m.setAttribute("class", "option-unlocked-saving-message-icon");
                        l.prepend(m);
                        l.setAttribute("class", "option-unlocked-saving-message")
                    } else l.setAttribute("class", "option-saving-message");
                    d.setAttribute("class", "qdt-dropdown-option-regular");
                    k.setAttribute("class", "option-price-and-saving-message");
                    k.appendChild(h);
                    k.appendChild(l);
                    d.appendChild(g);
                    d.appendChild(k)
                } else d.setAttribute("class", "qdt-dropdown-option-no-saving-message"),
                    d.appendChild(g), d.appendChild(h);
                c.appendChild(d);
                c.addEventListener("mousedown", function() {
                    b.handleQuantityDiscountTableOptionClicked(a.quantity)
                });
                return c
            };
        d.prototype.generateLoadMoreOption = function() {
            var a = this,
                b = document.createElement("li"),
                c = document.createElement("div");
            c.textContent = this.loadMoreMessage;
            b.setAttribute("class", "qdt-dropdown-item");
            c.setAttribute("class", "qdt-dropdown-option-load-more");
            b.setAttribute("id", "qdt-dropdown-load-more");
            b.appendChild(c);
            b.addEventListener("mousedown",
                function(b) {
                    a.handleLoadMoreOptionClicked(b)
                });
            return b
        };
        d.prototype.generateFetchInProcessOption = function() {
            var a = document.createElement("li"),
                b = document.createElement("div"),
                c = document.createElement("div"),
                d = document.createElement("div"),
                e = document.createElement("img");
            e.src = "https://m.media-amazon.com/images/G/01/AmazonBusiness/vapLoading3._CB1556651073_.gif";
            c.textContent = this.fetchTheBestPricesMessage;
            e.setAttribute("class", "fetching-in-progress-img");
            a.setAttribute("class", "qdt-dropdown-item qdt-inactive");
            b.setAttribute("class", "qdt-dropdown-option-fetch-in-progress");
            d.appendChild(e);
            b.appendChild(d);
            b.appendChild(c);
            a.setAttribute("id", "qdt-dropdown-fetch-in-progress");
            a.appendChild(b);
            return a
        };
        d.prototype.handleLoadMoreOptionClicked = function(a) {
            this.isLoadMoreButtonClicked = !0;
            this.generateQuantityDiscountTable();
            a.preventDefault()
        };
        d.prototype.handleQuantityDiscountTableOptionClicked = function(a) {
            c(this.quantityTextInputSelector).val(a);
            this.updateQuantityAndHideQuantityDiscountTable()
        };
        return {
            QuantityPickerLogicV2: d
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("A2IDetailPageAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageQuantityAwarePriceAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(f) {
    var g = window.AmazonUIPageJS || window.P,
        d = g._namespace || g.attributeErrors,
        b = d ? d("DetailPageSoftlinesPSSAssets", "") : g;
    b.guardFatal ? b.guardFatal(f)(b, window) : b.execute(function() {
        f(b, window)
    })
})(function(f, g, d) {
    f.when("A", "jQuery").register("pss-metric-utils", function(b, c) {
        return {
            updateRefTagCounters: function(b) {
                if ("object" !== typeof b) throw "Options is not an object";
                b.refTag !== d && c.ajax({
                    url: "/pss/reftag?ref_\x3d" + b.refTag,
                    type: "POST"
                })
            }
        }
    });
    "use strict";
    f.when("A", "jQuery", "a-button", "pdp-aui-utils",
        "pss-metric-utils", "pdp-common-widget", "pdp-common-utils").execute(function(b, c, f, d, h, m, e) {
        function v() {
            c("#" + n).bind("touchend", function(a) {
                a.preventDefault();
                h.updateRefTagCounters({
                    refTag: "pss_delete_profile_link_click"
                });
                e.showSpinner();
                w()
            })
        }

        function x() {
            c("#" + p).bind("touchend", function() {
                h.updateRefTagCounters({
                    refTag: "pss_delete_profile_delete_button_click"
                });
                e.showSpinner();
                y()
            });
            c("#" + q).bind("touchend", function() {
                h.updateRefTagCounters({
                    refTag: "pss_delete_profile_cancel_button_click"
                });
                e.showFooter();
                e.showProfileCard()
            });
            c("#" + r).bind("touchend", function() {
                h.updateRefTagCounters({
                    refTag: "pss_delete_profile_when_no_profile_done_button_click"
                });
                e.showFooter();
                e.showProfileCard()
            })
        }

        function w() {
            k = e.getProfileIdAndAsin();
            c.ajax("/pss/delete-get", {
                data: {
                    profileId: k.profileId,
                    asin: k.asin
                },
                type: "get",
                success: function(a) {
                    c("#pdpDeleteProfileCard").html(a);
                    a = d.getState("pss-delete-profile-meta-data");
                    t = a.deleteProfileConfirmationCardId;
                    q = a.deleteProfileCancelButtonId;
                    p = a.deleteProfileDeleteButtonId;
                    r = a.deleteNoProfileInfoDoneButtonId;
                    u = d.getState("pss-csrf-token").pssCsrfToken;
                    x();
                    m.showCard(t)
                },
                error: l
            })
        }

        function y() {
            c.ajax("/pss/delete-profile", {
                data: {
                    profileId: k.profileId,
                    asin: k.asin,
                    pssCsrfToken: u
                },
                type: "POST",
                success: function(a) {
                    var b = z;
                    a && a._metadata && a._metadata.redirect && !0 === a._metadata.redirect ? (h.updateRefTagCounters({
                        refTag: "pss_delete_profile_signin_redirect"
                    }), c(location).attr("href", a._metadata.location)) : b && b(a)
                },
                error: l
            })
        }

        function z(a) {
            a && a.success ? g.location.reload(!0) : l()
        }

        function l() {
            m.showGenericErrorCard()
        }
        var u, r, q, t, p, k, n;
        b.on(d.profileCardLoadEvent, function() {
            n = d.getState("fit-pdp-privacy").deleteInfoTextId;
            v()
        })
    })
});
/* ******** */
(function(g) {
    var t = window.AmazonUIPageJS || window.P,
        l = t._namespace || t.attributeErrors,
        c = l ? l("DetailPageSoftlinesPDPAssets", "") : t;
    c.guardFatal ? c.guardFatal(g)(c, window) : c.execute(function() {
        g(c, window)
    })
})(function(g, t, l) {
    g.when("A", "jQuery", "pdp-aui-utils").register("softlinesPDPIngress-size-update", function(c, a, e) {
        c.on(e.sizeRecCardLoadEvent, function(d) {
            a("#softlinesPDPIngress_sizeRecommendation").length && a("#softlinesPDPIngress_sizeRecommendation").html(e.getStateFromAjaxResponse(d, "slps-fit-pdp-ingress-state").sizeRecommendationMessage)
        })
    });
    g.when("A", "jQuery", "a-secondary-view").register("softlinesPDPIngress-url-update", function(c, a, e) {
        c.state.bind("softlines-pdp-ingress-modal-properties", function(d, b) {
            if (b.urlParameters && (b = e.get("PDPWidget"))) {
                var c = "",
                    q = d.baseUrl;
                d.urlParameters && (c = q.match(/\?/) ? "\x26" : "?", c += a.param(d.urlParameters));
                d.modalProperties.url = q + c;
                b.update(d.modalProperties)
            }
        })
    });
    "use strict";
    g.when("A", "jQuery", "pdp-aui-utils").execute(function(c, a, e) {
        function d(b) {
            l.each(function() {
                f = a(this);
                f.stop();
                f.hasClass("FT") &&
                    f.animate({
                        scrollTop: 2.5 * n
                    }, b);
                f.hasClass("IN") && f.animate({
                    scrollTop: 4.5 * n
                }, b);
                f.hasClass("CM") && f.animate({
                    scrollTop: 70.5 * n
                }, b)
            });
            p.each(function() {
                f = a(this);
                f.stop();
                var c = f.find("." + q),
                    d = c.filter("." + A);
                f.animate({
                    scrollTop: c.index(d) * n
                }, b)
            })
        }
        var b, h, q, g, w, A, B, z, n, p, l, f, x, C;
        c.on(e.profileCardLoadEvent, function() {
            b = e.getSelectors("height-selectors");
            h = b.scrollerCss;
            q = b.valueCss;
            g = b.containerCss;
            w = b.activeState;
            A = b.selectedState;
            B = b.errorState;
            z = a("." + h);
            p = a("." + g + "." + w + " ." + h);
            l = a("." + g + ":not(." +
                w + ") ." + h);
            n = a("." + q, z).first().outerHeight();
            p.hasClass("CM") && (n = a("." + q + ".CM", z).first().outerHeight());
            if (p.hasClass("FT") || p.hasClass("IN")) n = a("." + q + ".FT", z).first().outerHeight();
            d(1E3);
            z.bind("touchstart", function(b) {
                f = a(this);
                x = b.originalEvent.touches[0].clientY;
                C = f.scrollTop();
                f.closest("." + g).addClass(w);
                f.removeClass(B);
                b.preventDefault()
            }).bind("touchmove", function(b) {
                f = a(this);
                f.stop();
                f.scrollTop(C + x - b.originalEvent.touches[0].clientY)
            }).bind("touchend", function(b) {
                f = a(this);
                b = Math.round(f.scrollTop() /
                    n);
                f.animate({
                    scrollTop: b * n
                }, 50);
                var d = f.find("." + q);
                d.filter("." + A).removeClass(A);
                d.eq(b).addClass(A);
                c.trigger("pdp-card-input-updated")
            })
        });
        c.on("pdp-profile-height-units-changed", function() {
            d(0)
        })
    });
    "use strict";
    g.when("A", "jQuery", "pdp-aui-utils").execute(function(c, a, e) {
        var d, b, h;
        c.on(e.profileCardLoadEvent, function() {
            function g(e) {
                function q(a) {
                    m.filter("." + x).removeClass(x);
                    u = m.eq(a);
                    u.addClass(x);
                    la.text(u.data("weight-interval-text"));
                    r.addClass(f)
                }

                function w(a, b) {
                    D.animate({
                        scrollLeft: a *
                            d
                    }, b)
                }
                var n = e.containerCss,
                    p = e.incrementCss,
                    l = e.weightValueContainerCss,
                    f = e.activeState,
                    x = e.selectedState,
                    C = e.weightMinimumValue,
                    y = e.weightIntervalIncrement,
                    t = e.defaultWeight,
                    la = a("." + e.activeWeightValueCss),
                    D = a("." + n),
                    m = a("." + p, D),
                    u = m.filter("." + x),
                    r = a("." + l);
                d = m.first().outerWidth() - 3;
                u.length ? (q(m.index(u)), w(m.index(u), 1E3)) : 0 < d && w((t - C - y) / y, 1E3);
                D.bind("touchstart", function(c) {
                    d = m.first().outerWidth() - 3;
                    h = c.originalEvent.touches[0].clientX;
                    b = a(this).scrollLeft();
                    c.preventDefault()
                }).bind("touchmove",
                    function(c) {
                        a(this).scrollLeft(b + h - c.originalEvent.touches[0].clientX);
                        a(this).stop();
                        c = Math.round(a(this).scrollLeft() / d);
                        q(c)
                    }).bind("touchend", function() {
                    var b = Math.round(a(this).scrollLeft() / d);
                    q(b, 50);
                    c.trigger("pdp-card-input-updated")
                });
                c.on("pdp-profile-weight-units-changed", function() {
                    d = m.first().outerWidth() - 3;
                    u.length ? q(m.index(u)) : D.scrollLeft(d * (t - C - y) / y)
                })
            }
            var l = e.getSelectors("weight-selectors-imperial"),
                w = e.getSelectors("weight-selectors-metric");
            g(l);
            g(w)
        })
    });
    "use strict";
    g.when("A",
        "jQuery").register("pdp-aui-utils", function(c, a) {
        function e(b) {
            var d = a("script[type\x3d'a-state']").filter(function() {
                return a(this).data("a-state").key === b
            });
            return c.parseJSON(d.html())
        }

        function d(b, d) {
            b = a("\x3cdiv\x3e\x3c/div\x3e").html(b).find("script[type\x3d'a-state']").filter(function() {
                return a(this).data("a-state").key === d
            });
            return c.parseJSON(b.html())
        }
        return {
            getState: function(a) {
                return e(a)
            },
            getSelectors: function(b) {
                return a("#" + b).data()
            },
            getStateFromAjaxResponse: function(a, c) {
                return d(a,
                    c)
            },
            profileCardLoadEvent: "pdp-card-transition-profile-card-loaded",
            sizeRecCardLoadEvent: "pdp-card-transition-recommendation-card-loaded",
            hiddenClass: "aok-hidden"
        }
    });
    "use strict";
    g.when("A", "jQuery", "a-button", "slps-ajax", "pdp-aui-utils", "pdp-metric-utils", "pdp-recommendation-card").register("pdp-common-widget", function(c, a, e, d, b, h, g) {
        function l() {
            a("#" + T).bind("touchend", function() {
                h.updateCounters({
                    refTag: "slps_pdp_privacy_information_button_click"
                });
                a("#" + E).addClass("aok-hidden");
                p(U)
            });
            a("#" +
                V).bind("touchend", function() {
                h.updateCounters({
                    refTag: "slps_pdp_privacy_information_done_click"
                });
                a("#" + E).removeClass("aok-hidden");
                p(I)
            });
            a("#" + W).bind("touchend", function() {
                h.updateCounters({
                    refTag: "slps_pdp_privacy_notice_url_click"
                })
            });
            a("#" + X).bind("touchend", function() {
                h.updateCounters({
                    refTag: "slps_pdp_contact_us_url_click"
                })
            })
        }

        function w() {
            if (e("#" + J).isEnabled()) {
                var a = v[k].saveFormUrl;
                h.updateCounters({
                    refTag: F[k].refTagNextClick
                });
                a ? D(a) : z()
            }
        }

        function A() {
            if (e("#" + K).isEnabled()) {
                var a =
                    v[k].backDiv;
                h.updateCounters({
                    refTag: F[k].refTagBackClick
                });
                p(a);
                c.trigger("pdp-card-trasition-complete", k)
            }
        }

        function B() {
            a("." + Y).addClass("aok-hidden")
        }

        function z() {
            var a = v[k].nextDiv,
                b = v[k].nextURL;
            a ? p(a) : b && (B(), t(b))
        }

        function n() {
            a("#" + E).addClass("aok-hidden");
            B();
            a("#pdpGenericErrorCard").removeClass("aok-hidden");
            h.updateCounters({
                counter: "genericErrorCardShown"
            });
            f("#slps-pdp-retry-btn")
        }

        function p(b) {
            B();
            a("#" + b).removeClass("aok-hidden");
            k = b;
            null !== F[k] && h.updateCounters({
                counter: F[k].csmCardDisplayedCounter
            })
        }

        function t(e) {
            var Z = L;
            "undefined" !== typeof M && (Z = Object.assign({}, L, M));
            c.state.parse();
            a("#" + E).addClass("aok-hidden");
            d(e, {
                params: Z,
                method: "get",
                success: function(d) {
                    a("#sizeRecCard").html(d);
                    a("#sizeRecCard").removeClass("aok-hidden");
                    k = "sizeRecCard";
                    f("#slps-pdp-retry-btn");
                    f("#edit-input-link");
                    g.bindSubmitAction();
                    x();
                    h.updateCounters({
                        counter: "recsCardLoadedSuccess"
                    });
                    c.trigger(b.sizeRecCardLoadEvent, d);
                    c.trigger("pdp-card-trasition-complete", k)
                },
                error: function() {
                    h.updateCounters({
                        counter: "recsCardLoadingFailure"
                    });
                    n()
                }
            })
        }

        function f(b) {
            a(b).live("touchend", function(b) {
                B();
                a("#" + E).removeClass("aok-hidden");
                p(Object.keys(v)[0]);
                b.preventDefault();
                m()
            })
        }

        function x() {
            S = b.getState("fit-recs-screen-buttons");
            aa = S.editButtonId;
            a("#" + aa).bind("touchend", function(a) {
                h.updateCounters({
                    refTag: "slps_pdp_recs_card_edit_details_click"
                })
            })
        }

        function C() {
            var b = {};
            Object.keys(N).forEach(function(c) {
                c = N[c];
                b[c] = a("input[name\x3d" + c + "]:checked").val()
            });
            b.csrfToken = a("input[name\x3dubaSubmit]").val();
            return b
        }

        function y(b) {
            return a(a("." +
                G.valueCss + "." + b + "." + G.selectedState)[0]).data("heightValue")
        }

        function R(b) {
            var c = a(a("." + b + "." + G.selectedState)[0]).data("weightIntervalText").split("-");
            if (2 === c.length)
                if (b = parseFloat(c[0]), c = parseFloat(c[1]), isNaN(b) || isNaN(c)) h.updateCounters({
                    counter: "weightValueParsingFailure"
                }), console.log("Weight range values returned are not numbers " + b + " " + c);
                else return (b + c) / 2;
            else h.updateCounters({
                counter: "weightFormatParsingFailure"
            }), console.log("Weight range does not contain min and max values " +
                b)
        }

        function ka() {
            if (k === I) {
                var b = {};
                a("#" + ba).hasClass("a-button-selected") ? (b.unitSystem = "metric", b.heightUnitSystem = "metric", b.heightCm = y("CM")) : a("#" + ca).hasClass("a-button-selected") && (b.unitSystem = "imperial", b.heightUnitSystem = "imperial", b.heightFT = y("FT"), b.heightIN = y("IN"));
                a("#" + da).hasClass("a-button-selected") ? (b.weightUnitSystem = "metric", b.weightKg = R(O)) : a("#" + ea).hasClass("a-button-selected") && (b.weightUnitSystem = "imperial", b.weightLb = R(P));
                b.csrfToken = a("input[name\x3dprofileSubmit]").val();
                return b
            }
            if (k === Q) return C()
        }

        function D() {
            var a = v[k].saveFormUrl,
                b = Object.assign({}, L, ka());
            d(a, {
                params: JSON.stringify(b),
                paramsFormat: "json",
                method: "post",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json"
                },
                success: function(a) {
                    h.updateCounters({
                        counter: F[k].csmPostSuccessCounter
                    });
                    z();
                    c.trigger("pdp-card-trasition-complete", k)
                },
                error: function(a) {
                    console.error("Unable to post data " + a.http.response);
                    h.updateCounters({
                        counter: F[k].csmPostFailureCounter
                    });
                    n()
                }
            })
        }

        function m() {
            var b =
                e("#" + J),
                c = e("#" + K);
            c.disable();
            b.disable();
            v[k] && (v[k].backDiv || v[k].backURL) && c.enable();
            if (v[k] && (v[k].nextDiv || v[k].nextURL)) {
                if (c = k === I) {
                    var c = G.valueCss,
                        d = G.selectedState,
                        f = !1,
                        h = !1;
                    a("#" + fa).hasClass("aok-hidden") && a("." + c + ".FT." + d).length && a("." + c + ".IN." + d).length && (h = !0);
                    a("#" + ga).hasClass("aok-hidden") && a("." + c + ".CM." + d).length && (h = !0);
                    a("#" + ha).hasClass("aok-hidden") && a("." + P + "." + d).length && (f = !0);
                    a("#" + ia).hasClass("aok-hidden") && a("." + O + "." + d).length && (f = !0);
                    c = h && f
                }(c || k === Q) && b.enable()
            }
        }
        var u, r, H, S, ja, N, Q, I, L, U, J, K, V, T, W, X, aa, E, k, Y, G, ca, ba, ea, da, P, O, ga, ia, fa, ha, M, v = {
                pdpProfileCard: {
                    nextDiv: "pdpUniqueBodyAttributesCard",
                    saveFormUrl: "/slps/cx/pdp/s/profile"
                },
                pdpUniqueBodyAttributesCard: {
                    backDiv: "pdpProfileCard",
                    saveFormUrl: "/slps/cx/pdp/s/uba",
                    nextURL: "/slps/cx/pdp/recs"
                },
                sizeRecCard: {}
            },
            F = {
                pdpProfileCard: {
                    csmPostFailureCounter: "profileCardPostFailure",
                    csmPostSuccessCounter: "profileCardPostSuccess",
                    refTagBackClick: "slps_pdp_profile_back_button_click",
                    refTagNextClick: "slps_pdp_profile_next_button_click",
                    csmCardDisplayedCounter: "profileCardDisplayedCount"
                },
                pdpUniqueBodyAttributesCard: {
                    csmPostFailureCounter: "ubaCardPostFailure",
                    csmPostSuccessCounter: "ubaCardPostSuccess",
                    refTagBackClick: "slps_pdp_uba_back_button_click",
                    refTagNextClick: "slps_pdp_uba_next_button_click",
                    csmCardDisplayedCounter: "ubaCardDisplayedCount"
                },
                sizeRecCard: {
                    refTagDoneClick: "slps_pdp_done_click"
                },
                pdpPrivacyInfoCard: {
                    csmCardDisplayedCounter: "privacyCardDisplayedCount"
                },
                deleteProfileConfirmationCard: {
                    csmCardDisplayedCounter: "DeleteProfileConfirmationCardDisplayedCount"
                },
                pdpSpinnerCard: {}
            };
        c.on("a:popover:ajaxContentLoaded:PDPWidget", g.initialize);
        c.on(b.profileCardLoadEvent, function() {
            u = b.getState("fit-pdp-footer");
            r = b.getState("fit-pdp-profile");
            L = b.getState("fit-pdp-profile-product-info");
            ja = b.getState("fit-pdp-uba");
            H = b.getState("fit-pdp-privacy");
            G = b.getSelectors("height-selectors");
            N = b.getState("fit-pdp-uba-attributes");
            P = b.getSelectors("weight-selectors-imperial").incrementCss;
            O = b.getSelectors("weight-selectors-metric").incrementCss;
            M = c.state("softlines-pdp-ingress-flojo-attributes");
            Q = ja.ubaCardId;
            U = H.privacyCardId;
            V = H.doneButtonId;
            W = H.privacyUrlLinkId;
            X = H.contactUsUrlLinkId;
            I = r.profileCardId;
            Y = r.pdpCardsClass;
            ca = r.heightImperialButton;
            ba = r.heightMetricButton;
            ea = r.weightImperialButton;
            da = r.weightMetricButton;
            ga = r.heightImperialDiv;
            ia = r.weightImperialDiv;
            fa = r.heightMetricDiv;
            ha = r.weightMetricDiv;
            J = u.nextButtonId;
            K = u.backButtonId;
            T = r.privacyInfoTextId;
            E = u.footerId;
            k = Object.keys(v)[0];
            p(k);
            m();
            a("#" + J).bind("touchend", w);
            a("#" + K).bind("touchend", A);
            l()
        });
        c.on("pdp-card-trasition-complete",
            m);
        c.on("pdp-card-input-updated", m);
        c.on("pdp-profile-height-units-changed", m);
        c.on("pdp-profile-weight-units-changed", m);
        return {
            showGenericErrorCard: n,
            showCard: p
        }
    });
    "use strict";
    g.when("A", "jQuery", "pdp-aui-utils").execute(function(c, a, e) {
        c.on(e.profileCardLoadEvent, function() {
            var d = e.getState("fit-pdp-profile");
            a("#" + d.heightMetricButton).click(function() {
                a("#" + d.heightImperialDiv).addClass("aok-hidden");
                a("#" + d.heightMetricDiv).removeClass("aok-hidden");
                c.trigger("pdp-profile-height-units-changed",
                    "metric")
            });
            a("#" + d.heightImperialButton).click(function() {
                a("#" + d.heightMetricDiv).addClass("aok-hidden");
                a("#" + d.heightImperialDiv).removeClass("aok-hidden");
                c.trigger("pdp-profile-height-units-changed", "imperial")
            });
            a("#" + d.weightMetricButton).click(function() {
                a("#" + d.weightImperialDiv).addClass("aok-hidden");
                a("#" + d.weightMetricDiv).removeClass("aok-hidden");
                c.trigger("pdp-profile-weight-units-changed", "metric")
            });
            a("#" + d.weightImperialButton).click(function() {
                a("#" + d.weightMetricDiv).addClass("aok-hidden");
                a("#" + d.weightImperialDiv).removeClass("aok-hidden");
                c.trigger("pdp-profile-weight-units-changed", "imperial")
            })
        })
    });
    "use strict";
    g.when("A", "slps-ajax").register("pdp-metric-utils", function(c, a) {
        var e = t.ue,
            d = "object" === typeof e && e.count;
        return {
            updateCounters: function(b) {
                if ("object" !== typeof b) throw "Options is not an object";
                if (b.counter !== l) {
                    var c = b.counter;
                    c && d && e.count("SlpsPDP:Mobile:" + c, 1)
                }
                b.refTag !== l && (b = b.refTag) && a("/slps/cx/reftag", {
                    params: {
                        ref_: b
                    }
                })
            }
        }
    });
    "use strict";
    g.when("A", "jQuery",
        "pdp-aui-utils", "pdp-common-widget").register("pdp-common-utils", function(c, a, e, d) {
        return {
            showProfileCard: function() {
                var a = e.getState("fit-pdp-profile");
                d.showCard(a.profileCardId)
            },
            showFooter: function() {
                var b = e.getState("fit-pdp-footer").footerId;
                a("#" + b).removeClass("aok-hidden")
            },
            showSpinner: function() {
                var a = e.getState("fit-spinner-meta-data");
                d.showCard(a.pdpSpinnerCardId)
            },
            getProfileIdAndAsin: function() {
                var a = e.getState("fit-pdp-profile-product-info");
                return {
                    profileId: a.profileId,
                    asin: a.asin
                }
            }
        }
    });
    "use strict";
    g.when("A", "jQuery", "pdp-aui-utils", "pdp-metric-utils", "a-secondary-view", "slps-ajax").register("pdp-recommendation-card", function(c, a, e, d, b, h) {
        function g() {
            if (e.getState("fit-recs-screen-buttons") !== l && null !== e.getState("fit-recs-screen-buttons")) {
                var d = "#" + e.getState("fit-recs-screen-buttons").confirmButtonId;
                a(d).live("touchend", function(a) {
                    b.get("PDPWidget").hide();
                    a.preventDefault()
                })
            } else c.trigger(e.profileCardLoadEvent)
        }

        function t(b) {
            a(b).live("touchend", function(g) {
                var l = e.getState("softlines-pdp-ingress-modal-properties");
                h(l.baseUrl, {
                    params: l.urlParameters,
                    method: "get",
                    success: function(g) {
                        a(b).die("touchend");
                        a(".pdpCards").addClass(e.hiddenClass);
                        a("#size-rec-section").remove();
                        a("#pdpProfileContainerFromSizeRec").html(g);
                        a("#pdpProfileContainerFromSizeRec").removeClass(e.hiddenClass);
                        d.updateCounters({
                            counter: "profileCardLoadedSuccess"
                        });
                        c.trigger(e.profileCardLoadEvent)
                    },
                    error: function() {
                        d.updateCounters({
                            counter: "profileCardLoadingFailure"
                        })
                    }
                });
                g.preventDefault()
            })
        }
        return {
            initialize: function() {
                t("#slps-pdp-retry-btn");
                t("#edit-input-link");
                g()
            },
            bindSubmitAction: g
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("AmazonFamilyLandingPageOptimizationAssets@sifterAssets", "AmazonFamilyLandingPageOptimization") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(c) {
    var a = window.AmazonUIPageJS || window.P,
        d = a._namespace || a.attributeErrors,
        b = d ? d("DetailPageTextLinkIngressAssets", "") : a;
    b.guardFatal ? b.guardFatal(c)(b, window) : b.execute(function() {
        c(b, window)
    })
})(function(c, a, d) {
    "use strict";
    c.when("A").execute(function(b) {
        b.$("#smile-code-launcher").bind("click", function() {
            a.ue && a.ue.count && ue.count("smileCodeDesktop_ingress_T1_clicked", (ue.count("smileCodeDesktop_ingress_T1_clicked") || 0) + 1)
        });
        a.ue && a.ue.count && ue.count("smileCodeDesktop_ingress_shown",
            (ue.count("smileCodeDesktop_ingress_shown") || 0) + 1)
    })
});
/* ******** */
(function(e) {
    var m = window.AmazonUIPageJS || window.P,
        C = m._namespace || m.attributeErrors,
        c = C ? C("TurboCheckoutBaseAssets", "") : m;
    c.guardFatal ? c.guardFatal(e)(c, window) : c.execute(function() {
        e(c, window)
    })
})(function(e, m, C) {
    "use strict";
    e.register("turbo-function-adapter", function() {
        return {
            adapt: function(c) {
                return function() {
                    if ("function" !== typeof c) throw "Parameter 'property' is invalid. Expected a function but got " + typeof c;
                    return c.apply(c, arguments)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-function-adapter").execute("turbo-signin-adapter-factory",
        function(c, d) {
            e.when(c.get(c.KEYS.SHOW_SIGN_IN_INTERFACE)).register("turbo-signin-adapter", function(a) {
                return {
                    show: d.adapt(a.show)
                }
            })
        });
    "use strict";
    e.when("turbo-configuration", "turbo-function-adapter").execute("turbo-view-adapter-factory", function(c, d) {
        e.when(c.get(c.KEYS.VIEW_ADAPTER)).register("turbo-view-adapter", function(a) {
            return {
                registerCallbacks: d.adapt(a.registerCallbacks),
                close: d.adapt(a.close),
                show: d.adapt(a.show),
                removeContent: d.adapt(a.removeContent),
                setContent: d.adapt(a.setContent),
                closeImmediatelyThenExecute: d.adapt(a.closeImmediatelyThenExecute),
                closeAndNavigate: d.adapt(a.closeAndNavigate),
                closeToFullscreen: d.adapt(a.closeToFullscreen),
                updateBounds: d.adapt(a.updateBounds)
            }
        })
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-eligibility-override", !1)
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-interstitial-suppression", !1)
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-address-id",
        function(c, d, a) {
            function b(a) {
                for (var b = 0; b < a.length; b++) {
                    var c = g(a[b]);
                    if (0 < c.length) return d.logCount("turboCheckoutAddressSelectorIndex" + b), c
                }
                d.logCount("turboCheckoutAddressSelectorMissing");
                return g()
            }
            var g = c.$;
            return {
                getAddressId: function() {
                    return b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val() || ""
                },
                set: function(d) {
                    b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val() !== d && b(a.get(a.KEYS.ADDRESS_INPUT_SELECTORS)).val(d).trigger("change", [d])
                }
            }
        });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-callback-list",
        "turbo-configuration", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkbox-exclusion-listener", function(c, d, a, b, g) {
        function f(a) {
            var d = r;
            r = !1;
            for (var b = 0; b < k.length; b++) {
                var c = p(k[b]).find("input[type\x3dcheckbox]");
                a(c)
            }
            d !== r && (w("Exclusion checkbox state changed"), n.callAll("exclusionCheckbox"))
        }

        function h(a) {
            var d;
            if (!(d = r)) {
                d = !1;
                for (var b = 0; b < a.length && !d; b++) {
                    var c = p(a[b]);
                    (d = c.prop("checked")) && w("Exclusion checkbox is checked", c)
                }
            }
            r = d
        }

        function w(a, b) {
            d.logDebug("turbo-checkbox-exclusion-listener",
                a, b)
        }

        function l() {
            f(h)
        }
        var k = b.get(b.KEYS.CHECKBOX_EXCLUSION_ROOT_NODES),
            p = c.$,
            n = a.create(),
            r = !1;
        g.bind(function() {
            f(function(a) {
                w("Listening for change events on:", a);
                a.unbind("change", l).bind("change", l);
                h(a)
            })
        });
        return {
            onStateChange: function(a) {
                n.push(a)
            },
            isAnyCheckboxChecked: function() {
                return r
            }
        }
    });
    "use strict";
    e.when("A", "turbo-callback-list", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-custom-price-input", function(c, d, a) {
        function b() {
            var a = g();
            w !== a && (w =
                a, h.callAll())
        }

        function g() {
            return f("#gcPriceOverride").val() || ""
        }
        var f = c.$,
            h = d.create(),
            w;
        a.bind(function() {
            w = g();
            f("#gcPriceOverride").unbind("change", b).bind("change", b)
        });
        return {
            getCustomPrice: g,
            onChange: function(a) {
                h.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-callback-list", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-quantity-input", function(c, d, a, b, g, f) {
        function h(d) {
            var b;
            b = d ? d.value ? parseInt(d.value,
                10) : d.target && d.target.value ? parseInt(d.target.value, 10) : void 0 : void 0;
            r === b ? a.logDebug("turbo-checkout-quantity-input", "Quantity change event does NOT have new quantity. Suppressing callbacks", void 0) : (r = b, a.logDebug("turbo-checkout-quantity-input", "Quantity change event", d), k.callAll())
        }

        function w(a) {
            a = a.val();
            (a = parseInt(a, 10)) || d.logCount("turboCheckoutNoQuantityFromPage");
            return a || 1
        }
        var l = c.$,
            k = g.create(),
            p = b.get(b.KEYS.QUANTITY_SELECT_SELECTOR),
            n = "Multiple quantity nodes present on the page. This may lead to an incorrect quantity being used in Turbo! Selector \x3d " +
            p,
            r;
        f.bind(function() {
            var b = l(p);
            r = w(b);
            b.unbind("change", h).bind("change", h);
            1 < b.length && (a.logError(n, "turbo-checkout-quantity-input"), a.logDebug("turbo-checkout-quantity-input", n, b));
            d.logCount("turboCheckoutQuantityNodes", b.length)
        });
        return {
            getQuantity: function() {
                return w(l(p))
            },
            setQuantity: function(a) {
                var d = l(p),
                    b = w(d);
                a = parseInt(a, 10);
                b !== a && d.val(a).change()
            },
            onChange: function(a) {
                k.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-callback-list", "turbo-configuration",
        "turbo-checkout-quantity-input", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-warranty-input", function(c, d, a, b, g, f, h) {
        var w = c.$,
            l = b.create(),
            k = g.get(g.KEYS.WARRANTY_CHECKBOX_INPUT_SELECTOR),
            p = g.get(g.KEYS.WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR),
            n = g.get(g.KEYS.WARRANTY_ASIN_INPUT_NAME),
            r = g.get(g.KEYS.WARRANTY_OFFER_INPUT_SELECTOR);
        h.bind(function() {
            w(k).unbind("click", l.callAll).bind("click", l.callAll)
        });
        return {
            select: function(a) {
                a && w(p + " input[name^\x3d" + n +
                    "][value\x3d" + a + "]").parents(p).find(k).click()
            },
            onChange: function(a) {
                l.push(a)
            },
            getLineItem: function(b) {
                if (w(k + ":checked").length) {
                    var c = w(k + ":checked").first().parents(p).find("input[name^\x3d" + n + "]").val() || "",
                        g = w(r).val() || "";
                    b = parseInt(b, 10) || f.getQuantity() || 1;
                    if (c && g) return {
                        asin: c,
                        offerListingId: g,
                        quantity: b
                    };
                    d.logCount("turboCheckoutIncompleteWarrantyInputs");
                    a.logError("Incomplete input data for the selected warranty checkbox - asin:" + c + ", offerId:" + g + ", quantity:" + b)
                } else a.logDebug("turbo-checkout-warranty-input",
                    "No warranty checkbox is selected", void 0)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-callback-list", "turbo-configuration", "turbo-checkout-load-events", "turbo-checkout-page-ready").register("turbo-checkout-vas-input", function(c, d, a, b, g) {
        function f() {
            return k(w).prop("checked") || !1
        }

        function h() {
            var a = n;
            n = f();
            a !== n && p.callAll(n)
        }
        var w = b.get(b.KEYS.VAS_CHECKBOX_SELCTOR),
            l = b.get(b.KEYS.VAS_CHANGE_EVENTS),
            k = c.$,
            p = a.create(),
            n;
        g.bind(function() {
            n = f();
            l.forEach(function(a) {
                c.off(a, h);
                c.on(a,
                    h)
            })
        });
        return {
            isSelected: f,
            onChange: function(a) {
                p.push(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-page-state", "turbo-checkout-product-state", "turbo-checkout-page-ready").register("turbo-checkout-joined-state", function(c, d, a, b, g) {
        function f(a, b) {
            function g() {
                var b = a.turboWeblab;
                b || d.logCount("turboCheckoutWeblabNameNotDefinedInState");
                return b
            }

            function f() {
                return a.turboWeblabTreatment
            }
            this.pageState = a;
            this.productStates = b;
            this.getLineItems = function() {
                return n.lineItemInputs
            };
            this.getActiveId = function() {
                return n.id
            };
            this.getHeaderText = function() {
                return n ? n.turboHeaderText || a.turboHeaderText : a.turboHeaderText
            };
            this.getLoadingText = function() {
                return a.turboLoadingText
            };
            this.getAddressId = function() {
                return a.addressId
            };
            this.getRequestId = function() {
                return a.requestId
            };
            this.getSessionId = function() {
                return a.sessionId
            };
            this.getInitiateSelector = function() {
                return a.initiateSelector
            };
            this.getWeblab = g;
            this.getWeblabTreatment = f;
            this.isTurboLaunched = function() {
                return !g() && "C" !== f()
            };
            this.isProductStateEligible = function() {
                return b.isTurboEligible
            };
            this.resolve = function(a) {
                if (a) {
                    n = b.states[a];
                    if (!n) throw a = "Resolved turbo checkout product state is undefined. Id \x3d " + a, h(a, b), a;
                    h("Resolved new product state", n);
                    c.trigger("turbo:checkout:state:product:resolved")
                }
            };
            var n = 1 !== b.states.length ? C : b.states[0]
        }

        function h(d, b) {
            a.logDebug("turbo-checkout-joined-state", d, b)
        }
        return {
            createTurboState: function(a, c, h, p, n) {
                if (p && h) throw "Custom item price is NOT supported with warranty";
                var r =
                    b.get();
                c && (r.addressId = c);
                c = g.get();
                if (a || p || h) a = parseInt(a, 10) || 1, c.states.forEach(function(b) {
                    b.lineItemInputs.forEach(function(b) {
                        b.quantity = a;
                        p ? (b.customItemPrice = p, d.logCount("turboCheckoutItemPriceOverrided")) : b.customItemPrice && d.logCount("turboCheckoutItemPriceSelectorFallBackToTurboState")
                    });
                    h && (h.quantity = a, b.lineItemInputs.push(h))
                });
                r = new f(r, c);
                r.resolve(n);
                return r
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-checkout-aui-page-state-parser",
        "turbo-checkout-page-ready").register("turbo-checkout-page-state", function(c, d, a, b, g) {
        function f(a, d, b, c, g, f, h, l, k) {
            this.version = a;
            this.turboWeblab = d;
            this.turboWeblabTreatment = b;
            this.initiateSelector = c;
            this.turboLoadingText = g;
            this.turboHeaderText = f;
            this.addressId = h;
            this.requestId = l;
            this.sessionId = k
        }

        function h(d, b) {
            a.logDebug("turbo-checkout-page-state", d, b)
        }
        var w = b.get(b.KEYS.TURBO_PAGE_STATE_KEY),
            l = b.get(b.KEYS.PAGE_STATE_PARSING_ROOT_NODE_SELECTOR),
            k = new f("0", "", "C", "#buy-now-button", "", "", "",
                "", "");
        return {
            get: function(b, c) {
                b = b || w;
                c = c || l;
                c = g.parse(b, c);
                d.logCount("turboCheckoutPageStates", c.length);
                1 < c.length ? (a.logError("Multiple turbo checkout page states found! Turbo will NOT show", "turbo-checkout-page-state", void 0), h("PageStates", c), b = void 0) : (0 === c.length && h("Turbo checkout page state [" + b + "] is NOT present"), b = c[0]);
                if (b)
                    if (b.version) b = new f(b.version, b.turboWeblab || "", b.turboWeblabTreatment || "C", b.initiateSelector || ".buy-now-button", b.turboLoadingText || "", b.turboHeaderText || "",
                        b.addressId || "", b.requestId || "", b.sessionId || "");
                    else {
                        c = b.inputs || {};
                        var e = b.strings || {};
                        b = new f("1", b.turboWeblab || "", b.turboWeblabTreatment || "C", (b.configurations || {}).initiateSelector || "#buy-now-button", e.TURBO_LOADING_TEXT || "", e.TURBO_CHECKOUT_HEADER || "", c.addressId || "", c.requestId || "", c.sessionId || "")
                    }
                else d.logCount("turboCheckoutStateNotDefined"), b = k;
                h("Turbo Checkout PageState", b);
                return b
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-configuration", "turbo-checkout-aui-page-state-parser",
        "turbo-checkout-page-ready").register("turbo-checkout-product-state", function(c, d, a, b, g) {
        function f(a, b) {
            this.isTurboEligible = a;
            this.states = b
        }

        function h(a, b, d, c) {
            this.id = a;
            this.isTurboEligible = b;
            this.lineItemInputs = d;
            this.turboHeaderText = c || ""
        }

        function w(a, b, d, c, g, f) {
            this.asin = b || "";
            this.offerListingId = d || "";
            this.quantity = parseInt(c, 10) || 1;
            this.isTurboEligible = !!this.asin && !!this.offerListingId && a;
            this.productTitle = g || "";
            this.customItemPrice = f || ""
        }

        function l(b, d) {
            a.logDebug("turbo-checkout-product-state",
                b, d)
        }

        function k(a) {
            if (!a.lineItemInputs || !a.lineItemInputs.length || !a.id) return l('Versioned product state is invalid. Expected non empty "id" and "lineItemInputs". Turbo may NOT show', a), e;
            var b = !0,
                d = c.map(a.lineItemInputs, function(a) {
                    a = new w(a.isTurboEligible, a.asin, a.offerListingId, a.quantity, a.productTitle, a.customItemPrice);
                    b = b && a.isTurboEligible;
                    return a
                });
            return new h(a.id, b, d, a.turboHeaderText)
        }
        var p = b.get(b.KEYS.TURBO_PRODUCT_STATE_KEY),
            n = b.get(b.KEYS.PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR),
            e = new h("buy-now-button", !1, [], ""),
            q = new f(!1, [e]);
        return {
            get: function(b, c) {
                b = b || p;
                c = c || n;
                c = g.parse(b, c);
                d.logCount("turboCheckoutProductStates", c.length);
                1 < c.length && "turbo-checkout-page-state" === b ? (a.logError("turbo-checkout-page-state only supports the single item use case! Turbo will NOT show", "turbo-checkout-product-state", void 0), b = []) : b = c;
                if ((c = b) && c.length) {
                    var t = !1;
                    b = [];
                    for (var z = 0; z < c.length; z++) {
                        var u;
                        var v = c[z];
                        v ? v.version ? u = k(v) : v.inputs && v.eligibility ? (u = v.strings || {}, v = new w(v.eligibility.isEligible,
                            v.inputs.a, v.inputs.oid, v.inputs.quantity, u.TURBO_CHECKOUT_HEADER, v.inputs.customItemPrice), u = new h("buy-now-button", v.isTurboEligible, [v], u.TURBO_CHECKOUT_HEADER)) : (l('Legacy product state is missing "inputs" or "eligibility". Turbo will NOT show', v), u = e) : (l("Product state parsed DOM object is invalid. Turbo may NOT show", v), u = e);
                        t = t || u.isTurboEligible || !1;
                        v = u.id;
                        if (b[v]) throw c = "Duplicate product state found. id \x3d " + v, l(c, b), c;
                        b.push(u);
                        b[u.id] = u
                    }
                    b = new f(t, b)
                } else l("Parsed states are invalid. Turbo will NOT show",
                    c), b = q;
                l("Turbo Checkout Product State(s)", b);
                return b
            }
        }
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-auto-open", "turbo-checkout-address-id", "turbo-checkout-quantity-input", "turbo-checkout-warranty-input", "turbo-checkout-custom-price-input", "turbo-callback-list", "turbo-checkout-is-physical-gift-card-support-enabled", "turbo-checkout-joined-state", "turbo-checkout-page-ready").register("turbo-checkout-state-handler", function(c, d, a, b, g, f,
        h, w, l, k, p, n) {
        function e(a, b, d, c, g) {
            a = a || h.getQuantity();
            b = b || f.getAddressId();
            d = d || w.getLineItem(a);
            c = c || l.getCustomPrice();
            return n.createTurboState(a, b, d, c, g)
        }

        function q(a, d) {
            b.logDebug("turbo-checkout-state-handler", a, d)
        }

        function m() {
            var b = 0 !== u("#giftcardcustomtwister_feature_div").length;
            b && (q("Physical Gift Card use case"), a.logCount("turboCheckoutGiftCardUseCase"));
            return b
        }

        function x(a, b, d, c) {
            y = e(a, b, d, C, c)
        }

        function t() {
            c.trigger("turbo:checkout:product:onChange");
            D.callAll()
        }

        function z() {
            var a =
                e();
            b.isDeepEquals(y, a) || (y = a, q("New Turbo State", y), t())
        }
        var u = c.$,
            v = d.get(d.KEYS.TURBO_STATE_CHANGE_AUI_EVENTS),
            D = k.create(),
            y, E = !1;
        y = e();
        return {
            isProductTurboEligible: function() {
                return !E && y.isProductStateEligible() && (!m() || p) || d.get(d.KEYS.OVERRIDE_ELIGIBILITY)
            },
            getLineItems: function() {
                return y.getLineItems()
            },
            getAddressId: function() {
                return y.getAddressId()
            },
            getWeblabAllocation: function() {
                return y.getWeblabTreatment()
            },
            registerCallback: function(a) {
                D.push(a)
            },
            startMonitoringPage: function() {
                g.updateInputsAndThen(x);
                h.onChange(z);
                w.onChange(z);
                l.onChange(z);
                v.forEach(function(a) {
                    c.off(a, z);
                    c.on(a, z)
                });
                t()
            },
            getRequestId: function() {
                return y.getRequestId()
            },
            getSessionId: function() {
                return y.getSessionId()
            },
            getExperimentName: function() {
                return y.getWeblab()
            },
            getStrings: function() {
                return {
                    TURBO_LOADING_TEXT: y.getLoadingText(),
                    TURBO_CHECKOUT_HEADER: y.getHeaderText()
                }
            },
            getInitiateSelector: function() {
                return y.getInitiateSelector()
            },
            isTurboLaunched: function() {
                return y.isTurboLaunched()
            },
            isPhysicalGiftCardExperimentEligible: m,
            setTurboStateNotEligible: function() {
                E = !0
            },
            resolveProductState: function(a) {
                y.resolve(a)
            },
            getActiveId: function() {
                return y.getActiveId()
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-aui-page-state-parser", function(c, d) {
        var a = c.$;
        return {
            parse: function(b, c) {
                b = "script[data-a-state*\x3d'" + b + "']";
                c = c ? a(c).find(b) : a(b);
                b = [];
                for (var f = 0; f < c.length; f++) {
                    var h;
                    a: {
                        try {
                            var e = a(c[f]).text();
                            h = JSON.parse(e);
                            break a
                        } catch (l) {
                            d.logError("JSON::parse exception. Exception \x3d " +
                                l, "turbo-checkout-aui-page-state-parser", void 0)
                        }
                        h = void 0
                    }
                    h && b.push(h)
                }
                return b
            }
        }
    });
    "use strict";
    e.when("jQuery", "turbo-checkout-auto-open", "turbo-checkout-page-ready").register("turbo-checkout-page-load-spinner", function(c, d) {
        function a() {
            0 !== c("#turbo-checkout-auto-load-spinner-container").length && (c("#turbo-checkout-auto-load-spinner-container").remove(), g.unbind("touchmove touchstart touchend touchcancel click scroll", b))
        }

        function b(a) {
            a.preventDefault();
            a.stopPropagation()
        }
        var g = c("body");
        d.isAutoOpenEligible() &&
            (g.bind("touchmove touchstart touchend touchcancel click scroll", b), g.append("\x3cdiv id\x3d'turbo-checkout-auto-load-spinner-container' class\x3d'turbo-checkout-auto-load-spinner-container'\x3e\x3cdiv id\x3d'turbo-checkout-auto-load-circle-container' class\x3d'turbo-checkout-auto-load-circle-container'\x3e\x3cdiv id\x3d'turbo-checkout-auto-load-spinner' class\x3d'a-spinner a-spinner-medium turbo-checkout-auto-load-spinner'\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e"), setTimeout(a, 5E3));
        return {
            removePageLoadSpinner: a
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-checkout-ref-tagger", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-urls", function(c, d, a) {
        function b(a, b) {
            var d = c.get(c.KEYS.DEVICE_OVERRIDE);
            return "\x26pipelineType\x3dturbo\x26clientId\x3dretailwebsite" + (d ? "\x26devicestring-override\x3d" + d : "") + e(a, b)
        }

        function g() {
            var a = c.get(c.KEYS.HOST_PAGE_TYPE_IDENTIFIER);
            return d.generateRefTag(a, d.ACTIONS.BUY_NOW) + "\x26referrer\x3d" + a
        }

        function f(b) {
            return a.isNonEmptyString(b) ? "\x26weblab\x3d" +
                b : ""
        }

        function h() {
            return c.get(c.KEYS.IS_ADD_TO_CART_ENABLED) ? "\x26temporaryAddToCart\x3d1" : ""
        }

        function e(b, d) {
            var c = "";
            a.isNonEmptyString(b) && (c += "\x26pageRequestId\x3d" + b);
            a.isNonEmptyString(d) && (c += "\x26pageSessionId\x3d" + d);
            return c
        }
        return {
            buildInitiatePathWith: function(a, d, c, e) {
                a = "/checkout/turbo-initiate?" + g() + b(c, e) + f(a);
                return a + (d ? "\x26checkEligibilityOnly\x3dtrue" : "") + h()
            },
            buildConfirmPathWith: function(a, d, c) {
                return "/checkout/turbo-initiate/confirm?" + g() + b(d, c) + f(a) + h()
            },
            buildLogPageHitPathWith: function(a,
                c) {
                return "/checkout/log-page-hit?" + d.generateRefTag(a, d.ACTIONS.CLOSE, c) + b()
            },
            buildTriggerWeblabPathWith: function(a, b, d, c) {
                return "/checkout/triggerWeblab?" + g() + f(a) + "\x26weblabAllocation\x3d" + b + e(d, c)
            },
            buildTriggerWeblabPathWithoutWeblab: function(a, b) {
                return "/checkout/triggerWeblab?" + g() + e(a, b)
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-callback-list", function() {
        function c() {
            var d = [];
            this.callAll = function() {
                for (var a = 0; a < d.length; a++) {
                    var b = d[a];
                    b.apply(b, arguments)
                }
            };
            this.push =
                function(a) {
                    if ("function" !== typeof a) throw "Invalid callback. Expected typeof 'callback' to be 'function'. typeof \x3d " + typeof a; - 1 === d.indexOf(a) && d.push(a)
                };
            this.remove = function(a) {
                a = d.indexOf(a); - 1 !== a && d.splice(a, 1)
            }
        }
        return {
            create: function() {
                return new c
            }
        }
    });
    "use strict";
    e.when("turbo-callback-list", "turbo-checkout-page-ready").register("turbo-filtered-callback-list", function(c) {
        function d(a) {
            var b = c.create();
            this.callAll = b.callAll;
            this.remove = b.remove;
            this.push = function(d) {
                (d = d[a]) && "function" ===
                typeof d && b.push(d)
            }
        }
        return {
            create: function(a) {
                if (!a || "string" !== typeof a) throw "Invalid filter parameter. Expected 'filter' to be a non empty string. typeof \x3d " + typeof a + " value \x3d " + a;
                return new d(a)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-ajax-wrapper", function(c, d) {
        return {
            load: function(a, b) {
                b.hasOwnProperty("timeout") || (b.timeout = 2E4);
                return c.ajax(a, b)
            },
            loadWithJQXHR: function(a, b) {
                b.hasOwnProperty("timeout") || (b.timeout = 2E4);
                return c.$.ajax(a, b)
            },
            createXHRRequest: function() {
                var a = new XMLHttpRequest;
                a.timeout = 2E4;
                return a
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-session-storage", "turbo-checkout-quantity-input", "turbo-checkout-address-id", "turbo-checkout-warranty-input", "turbo-checkout-page-ready").register("turbo-checkout-auto-open", function(c, d, a, b, g, f, h) {
        function e(b, d) {
            a.logDebug("turbo-checkout-auto-open", b, d)
        }

        function l() {
            return k() && 0 !== q
        }

        function k() {
            var c;
            if (c = "1" ===
                x.trb_open || "1" === a.getUrlQueryParam("trb_open"))(c = b.isPresent("hasTurboAutoOpened")) && d.logCount("turboCheckoutAutoOpenLoopPrevented"), c = !c;
            return c
        }

        function p() {
            return 1 === q && k()
        }

        function n() {
            p() && (l() && (q = 2, b.set("hasTurboAutoOpened", "1")), t(x.trb_bid))
        }
        var r = c.$,
            q = 0,
            A = "trb_open trb_addr trb_qty trb_warrAsin trb_auth trb_sid trb_bid".split(" "),
            x = {},
            t = function() {};
        return {
            setup: function(b, d) {
                if (k()) {
                    q = 1;
                    var g = m.location.href;
                    r.each(A, function(b, d) {
                        b = a.getUrlQueryParam(d);
                        x[d] = b;
                        g = a.removeQueryParam(d,
                            b, g)
                    });
                    e("Parameters:", x);
                    a.replaceHistory(g);
                    "function" === typeof b ? t = b : a.logError("Initiate action must be supplied, and it must be a function.");
                    c.on("turbo:checkout:prefetcher:state:dataStale", n);
                    d()
                } else q = 0, e("Disabled")
            },
            reset: function() {
                b.remove("hasTurboAutoOpened")
            },
            isAutoOpenEligible: k,
            isAutoOpenEnabled: l,
            isAutoOpenReadyToBeOpened: p,
            updateInputsAndThen: function(a) {
                var b = x.trb_qty,
                    d = x.trb_addr,
                    c = x.trb_warrAsin,
                    l = x.trb_bid;
                if (b || d || c || l) {
                    b && g.setQuantity(b);
                    d && f.set(d);
                    var e;
                    c && (h.select(c),
                        e = h.getLineItem(b));
                    a(b, d, e, l)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-checkout-utils", function() {
        function c() {
            return navigator.userAgent
        }

        function d(a, b) {
            if (a === b || "function" === typeof a && "function" === typeof b) return !0;
            if (typeof a !== typeof b) return !1;
            if ("object" !== typeof a || null === a || null === b) return a === b || a !== a && b !== b;
            var c = Object.getOwnPropertyNames(a);
            if (c.length !== Object.getOwnPropertyNames(b).length) return !1;
            for (var f = 0; f < c.length; f++) {
                var h = c[f];
                if (!a.hasOwnProperty(h) ||
                    !b.hasOwnProperty(h) || !d(a[h], b[h])) return !1
            }
            return !0
        }
        return {
            logError: function(a, b) {
                e.log(a, "ERROR", b || "turbo-checkout-utils")
            },
            logWarning: function(a, b) {
                e.log(a, "WARN", b || "turbo-checkout-utils")
            },
            logDebug: function() {},
            getUserAgent: c,
            isAndroid: function() {
                return !!c().match(/[a|A]ndroid/)
            },
            isIPhone: function() {
                return !!c().match(/iPhone/)
            },
            isIPad: function() {
                return !!c().match(/iPad/)
            },
            isInternetExplorer: function() {
                return !!c().match(/MSIE/)
            },
            createFQDN: function(a) {
                /^http/.test(a) || (a = m.location.origin ? m.location.origin +
                    a : m.location.protocol + "//" + m.location.hostname + ":" + m.location.port + a);
                return a
            },
            getUrlQueryParam: function(a, b) {
                b || (b = m.location.href);
                a = a.replace(/[\[\]]/g, "\\$\x26");
                return (a = (new RegExp("[?\x26]" + a + "(\x3d([^\x26#]*)|\x26|#|$)")).exec(b)) ? a[2] ? decodeURIComponent(a[2].replace(/\+/g, " ")) : "" : C
            },
            removeQueryParam: function(a, b, d) {
                var c = d;
                a && b && d && (a = a + "\x3d" + b, c = d.replace(new RegExp("\\?" + a + "[\x26]?", "g"), "?"), c = c.replace(new RegExp("[\x26]?" + a, "g"), ""));
                return c
            },
            replaceHistory: function(a) {
                m.history.pushState &&
                    m.history.replaceState(null, m.title, a)
            },
            isNonEmptyString: function(a) {
                return "string" === typeof a && 0 < a.length
            },
            isDeepEquals: d
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-csm", function(c) {
        function d(a, d, c, g) {
            return "function" === typeof m.uet ? m.uet.apply(m.uet, arguments) : g || b()
        }

        function a(a, b, d) {
            return "function" === typeof m.ues ? m.ues.apply(m.ues, arguments) : d
        }

        function b() {
            return +new Date
        }

        function g(c) {
            function g() {
                q && h && e && f && !w && "function" === typeof x &&
                    (x(q, h, e, f), w = !0)
            }
            var h, f, e, q, w = !1,
                x;
            this.getId = function() {
                return c
            };
            this.markClick = function() {
                q = d("tc", c)
            };
            this.markFirstByte = function() {
                h = a("t0", c, b())
            };
            this.markAboveTheFold = function() {
                e = d("af", c);
                g()
            };
            this.markCriticalFeature = function() {
                f = d("cf", c);
                g()
            };
            this.whenDataSet = function(a) {
                x = a;
                g()
            }
        }

        function f(a) {
            "undefined" !== typeof m.ue_t0 && m.ue.count(a, Date.now() - m.ue_t0)
        }
        var h = 0,
            e = [];
        return {
            createScope: function() {
                return new g("chk_turbo_" + ++h)
            },
            logCount: function(a, b) {
                b = b || 1;
                c.logDebug("Logging counter " +
                    a + " with value " + b);
                if (m.ue && m.ue.count) {
                    var d = a + "_time";
                    m.ue.count(a, b);
                    f(d);
                    for (var g = 0; g < e.length; ++g) m.ue.count(a + "." + e[g], b), f(d + "." + e[g])
                }
            },
            addCounterExtraSuffix: function(a) {
                e.push(a)
            },
            timestamp: b
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-counter", function(c, d) {
        var a = 0,
            b = 0,
            g = 0,
            f = 0,
            h = 0,
            e = 0,
            l = "u";
        c.on("turbo:checkout:sheet:beforeOpen", function() {
            d.logCount("turboCheckoutSheetOpen", a);
            "u" !== l ? (++h, d.logCount("turboCheckoutPrefetchUsed",
                h), "p" === l ? d.logCount("turboCheckoutPrefetchUsedInProgress", h) : d.logCount("turboCheckoutPrefetchUsedFull", h)) : (++e, d.logCount("turboCheckoutPrefetchMissing", e))
        });
        c.on("turbo:checkout:sheet:beforeClose", function() {
            ++b;
            d.logCount("turboCheckoutSheetClose", b)
        });
        c.on("turbo:checkout:prefetcher:state:dataPrefetching", function() {
            d.logCount("turboCheckoutPrefetchRequested", g);
            l = "p"
        });
        c.on("turbo:checkout:prefetcher:state:dataFresh", function() {
            ++f;
            d.logCount("turboCheckoutPrefetchAvailable", f);
            l = "a"
        });
        c.on("turbo:checkout:prefetcher:state:dataStale",
            function() {
                l = "u"
            });
        return {
            incrementSheetOpenedCounter: function() {
                a++
            },
            incrementPrefetchCounter: function() {
                g++
            },
            getSheetOpenCount: function() {
                return a
            },
            getPrefetchCount: function() {
                return g
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-checkout-cacher", function() {
        return {
            createCache: function(c) {
                var d = !1,
                    a;
                return function() {
                    d || (a = c(), d = !0);
                    return a
                }
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-counter", "turbo-checkout-page-ready").register("turbo-checkout-ref-tagger", function(c, d) {
        function a(a,
            c, f) {
            a = "chk_" + a + "_" + c + "_" + d.getPrefetchCount() + "*" + d.getSheetOpenCount();
            return f ? a + "_" + f : a
        }
        return {
            generateRefTag: function(b, d, c) {
                return "ref_\x3d" + a(b, d, c)
            },
            generateValue: a,
            ACTIONS: {
                BUY_NOW: "buyNow",
                CLOSE: "close"
            },
            TAGS: {
                TOUCH: "touch",
                TOUCH_X: "touchX",
                BACK: "back",
                ROTATION: "rotation"
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-checkout-prefetch-timer", function(c) {
        function d() {
            f || (f = !0, c.trigger("turbo:checkout:timer:onTimeout"))
        }

        function a() {
            if (f) return !0;
            var a = (new Date).getTime();
            return g ? 6E5 <= a - g : !1
        }
        var b, g, f = !1;
        return {
            startTimer: function() {
                b || (b = m.setTimeout(d, 6E5));
                g || (g = (new Date).getTime())
            },
            isTimeout: a,
            resetTimer: function() {
                m.clearTimeout(b);
                f = !1;
                g = b = null
            },
            checkTimeout: function() {
                a() && d()
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-buy-now-button", function(c, d, a, b, g, f) {
        function h(a, d) {
            b.logDebug("turbo-checkout-buy-now-button",
                a, d)
        }

        function e(a) {
            a = a || k();
            a.unbind("click.turboCheckout").bind("click.turboCheckout", p).each(l)
        }

        function l(b, c) {
            b = (b = d._data(c, "events").click) ? b.length : 0;
            1 < b && (a.logCount("turboCheckoutBuyNowButtonMultipleClickEventsBound"), a.logCount("turboCheckoutBuyNowButtonMultipleClickEventsBoundQuantity:" + b))
        }

        function k(a) {
            return a ? d("#" + a) : d(g.getInitiateSelector())
        }

        function p(b) {
            h("Buy now button clicked");
            a.logCount("turboCheckoutBuyNowClicked");
            b && b.target && b.target.id || (h("Click event target is INVALID. Expected event target with an id. Turbo will NOT show",
                b), u = !0);
            if (u) u = !1, h("Buy now button callbacks supressed");
            else {
                g.resolveProductState(b.target.id);
                var c;
                h("Calling buy now button callbacks...");
                c = !1;
                for (var f = 0; f < z.length; f++) c = c || z[f]();
                c ? (h("Supressing default buy now button action"), b.preventDefault(), b.stopPropagation(), b.stopImmediatePropagation(), c = !0) : c = void 0;
                if (c) return !1
            }
            d(b.target).closest("form").attr("data-action", n());
            a.logCount("turboCheckoutBuyNowDefault");
            return !0
        }

        function n() {
            return k().attr("name") || "submit.buy-now"
        }

        function r(a) {
            for (var b =
                    z.length - 1; 0 <= b; --b) z[b] === a && z.splice(b, 1)
        }

        function q(a) {
            if (!a && 1 < k().length) throw "Button id parameter is NOT present. Cannot execute action without a button id on a page with multiple buy now buttons!";
        }

        function m(a) {
            a = k(a);
            x(a);
            e(a);
            a.click()
        }

        function x(a) {
            for (var b = 0; b < t.length; b++) {
                var c = t[b];
                h("Unbound configured event '" + c + "' from buy now button");
                a.unbind(c);
                d(document.body).undelegate(a.selector, c)
            }
        }
        var t = f.get(f.KEYS.CONFLICTING_INITIATE_LISTENERS),
            z = [],
            u = !1;
        c.on("turbo:checkout:clickInitiate",
            m);
        a.logCount("turboCheckoutBuyNowButtonBound");
        return {
            registerOnClickCallback: function(a) {
                r(a);
                z.push(a)
            },
            deregisterOnClickCallback: r,
            executeOriginalBuyNowAction: function(a) {
                q(a);
                u = !0;
                c.trigger("turbo:checkout:buyNowDisabled");
                c.trigger("turbo:checkout:clickInitiate", a)
            },
            executeTurboBuyNowAction: function(a) {
                q(a);
                u = !1;
                m(a)
            },
            getSubmitAction: n,
            bindTurboClickEvent: e,
            removeConflictingListeners: x
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-utils", "turbo-checkout-buy-now-button", "turbo-checkout-page-ready").register("turbo-checkout-buy-now-integration",
        function(c, d, a) {
            function b(a, b) {
                d.logDebug(a, "turbo-checkout-buy-now-integration", b)
            }
            var g = c.$,
                f = [];
            c.on("turbo:checkout:page:reappear", function() {
                b("Removing additional form inputs from form", f);
                for (var a;
                    (a = f.shift()) !== C;) a.remove()
            });
            return {
                isBuyNow: function(b) {
                    return b instanceof g && b.attr("data-action") === a.getSubmitAction()
                },
                checkoutWith: function(a, c) {
                    if (Array.isArray(a) && c instanceof g) {
                        var e;
                        e = c;
                        for (var k = 1; 0 < e.find('input[name\x3d"asin.' + k + '"]').length || 0 < e.find('input[name\x3d"offeringID.' +
                                k + '"]').length;) k++;
                        e = k;
                        for (var k = [], p = 0; p < a.length; p++) {
                            var n = a[p];
                            if (n !== C && n.asin && n.offerListingId) {
                                var m = e,
                                    n = [g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "asin." + m,
                                        value: n.asin
                                    }), g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "offeringID." + m,
                                        value: n.offerListingId
                                    }), g("\x3cinput /\x3e", {
                                        type: "hidden",
                                        name: "quantity." + m,
                                        value: n.quantity || 1
                                    })];
                                Array.prototype.push.apply(k, n);
                                e++
                            } else b('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!', n),
                                d.logError('Line item inputs are invalid. Expected "asin" and "offerListingId" keys in object. Customer purchase inputs ignored!')
                        }
                        p = c.find('input[name\x3d"itemCount"]');
                        1 === p.length ? p.val(e) : c.append(g("\x3cinput /\x3e", {
                            type: "hidden",
                            name: "itemCount",
                            value: e
                        }));
                        b("Appended additional buy now inputs.", k);
                        c.append.apply(c, k);
                        f = k
                    } else e = "Inputs are invalid. Expected array and jQuery object. lineItems \x3d " + a + " $form \x3d " + c, b(e, arguments), d.logError(e)
                }
            }
        });
    "use strict";
    e.when("turbo-checkout-page-ready").register("turbo-configuration-keys",
        function(c) {
            var d = {
                HOST_PAGE_TYPE_IDENTIFIER: "HOST_PAGE_TYPE_IDENTIFIER",
                BUY_NOW_BUTTON_SELECTOR: "BUY_NOW_BUTTON_SELECTOR",
                QUANTITY_SELECT_SELECTOR: "QUANTITY_SELECT_SELECTOR",
                ADDRESS_INPUT_SELECTORS: "ADDRESS_INPUT_SELECTORS",
                WARRANTY_CHECKBOX_INPUT_SELECTOR: "WARRANTY_CHECKBOX_INPUT_SELECTOR",
                WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR: "WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR",
                WARRANTY_ASIN_INPUT_NAME: "WARRANTY_ASIN_INPUT_NAME",
                WARRANTY_OFFER_INPUT_SELECTOR: "WARRANTY_OFFER_INPUT_SELECTOR",
                TURBO_STATE_CHANGE_AUI_EVENTS: "TURBO_STATE_CHANGE_AUI_EVENTS",
                TWISTER_PAGE_UPDATE_AUI_EVENT: "TWISTER_PAGE_UPDATE_AUI_EVENT",
                PREFETCH_TREATMENT: "PREFETCH_TREATMENT",
                NO_PREFETCH_TREATMENT: "NO_PREFETCH_TREATMENT",
                BUY_NOW_ONLY_TREATMENT: "BUY_NOW_ONLY_TREATMENT",
                IS_DEVICE_FILTER_REQUIRED: "IS_DEVICE_FILTER_REQUIRED",
                IS_SIGN_IN_SUPPORTED: "IS_SIGN_IN_SUPPORTED",
                USES_MASH_WILL_REAPPEAR: "USES_MASH_WILL_REAPPEAR",
                SHOW_SIGN_IN_INTERFACE: "SHOW_SIGN_IN_INTERFACE",
                IFRAME_ID: "IFRAME_ID",
                EXTEND_ELIGIBLE_STATE: "EXTEND_ELIGIBLE_STATE",
                VIEW_ADAPTER: "VIEW_ADAPTER",
                PAGE_STATE_PARSING_ROOT_NODE_SELECTOR: "PAGE_STATE_PARSING_ROOT_NODE_SELECTOR",
                PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR: "PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR",
                TURBO_PAGE_STATE_KEY: "TURBO_PAGE_STATE_KEY",
                TURBO_PRODUCT_STATE_KEY: "TURBO_PRODUCT_STATE_KEY",
                DEVICE_OVERRIDE: "DEVICE_OVERRIDE",
                CONFLICTING_INITIATE_LISTENERS: "CONFLICTING_INITIATE_LISTENERS",
                VAS_CHANGE_EVENTS: "VAS_CHANGE_EVENTS",
                VAS_CHECKBOX_SELCTOR: "VAS_CHECKBOX_SELCTOR",
                CHECKBOX_EXCLUSION_ROOT_NODES: "CHECKBOX_EXCLUSION_ROOT_NODES",
                MASH_ADAPTER: "MASH_ADAPTER",
                IS_ADD_TO_CART_ENABLED: "IS_ADD_TO_CART_ENABLED",
                IS_BUYNOW_ENABLED_FOR_SCREENREADER: "IS_BUYNOW_ENABLED_FOR_SCREENREADER",
                BACKGROUND_SCROLL_TARGET_SELECTOR: "BACKGROUND_SCROLL_TARGET_SELECTOR",
                OVERRIDE_ELIGIBILITY: "OVERRIDE_ELIGIBILITY",
                validate: function(a) {
                    if ("string" !== typeof a || !d[a]) throw "The key '" + a + "' is not defined within 'turbo-configuration-keys'.";
                }
            };
            return d
        });
    "use strict";
    e.when("A", "turbo-configuration-keys", "turbo-device-configuration", "turbo-client-configuration", "turbo-eligibility-override", "turbo-checkout-page-ready").register("turbo-configuration", function(c, d, a, b, g) {
        function f(a, b) {
            var c = h(a);
            k[a] =
                c === C ? b : c
        }

        function h(c) {
            var d = b[c];
            c = a[c];
            if (e(d)) return d;
            if (e(c)) return c
        }

        function e(a) {
            return "boolean" === typeof a || a
        }

        function l(c) {
            if (!e(b[c]) && !e(a[c])) throw "Required configuration override for key '" + c + "' is missing";
            k[c] = h(c)
        }
        var k;
        return {
            get: function(a) {
                d.validate(a);
                var b;
                k || (k = {}, l(d.HOST_PAGE_TYPE_IDENTIFIER), l(d.SHOW_SIGN_IN_INTERFACE), l(d.EXTEND_ELIGIBLE_STATE), l(d.VIEW_ADAPTER), f(d.BUY_NOW_BUTTON_SELECTOR, "#buy-now-button"), f(d.QUANTITY_SELECT_SELECTOR, 'select[name\x3d"quantity"]'), f(d.ADDRESS_INPUT_SELECTORS, ["#unifiedLocation1ClickAddress", "#unifiedLocationAddress"]), f(d.WARRANTY_CHECKBOX_INPUT_SELECTOR, ".mbb-checkbox input[name\x3dmbba]"), f(d.WARRANTY_CHECKBOX_RELATIVE_PARENT_SELECTOR, ".mbb-checkbox-column"), f(d.WARRANTY_ASIN_INPUT_NAME, "mbba"), f(d.WARRANTY_OFFER_INPUT_SELECTOR, "#mbb-offering-id"), f(d.TURBO_STATE_CHANGE_AUI_EVENTS, ["a:pageUpdate", "LocationUX_OnAddressChange"]), f(d.TWISTER_PAGE_UPDATE_AUI_EVENT, "a:pageUpdate"), f(d.PREFETCH_TREATMENT, "PREFETCH_DISABLED"), f(d.NO_PREFETCH_TREATMENT, "T1"),
                    f(d.BUY_NOW_ONLY_TREATMENT, "BUY_NOW_LAUNCHED"), f(d.IS_DEVICE_FILTER_REQUIRED, !1), f(d.IS_SIGN_IN_SUPPORTED, !0), f(d.USES_MASH_WILL_REAPPEAR, !1), f(d.IFRAME_ID, "turbo-checkout-iframe"), f(d.PAGE_STATE_PARSING_ROOT_NODE_SELECTOR, "#turboState"), f(d.PRODUCT_STATE_PARSING_ROOT_NODE_SELECTOR, "#turboState"), f(d.TURBO_PAGE_STATE_KEY, "turbo-checkout-page-state"), f(d.TURBO_PRODUCT_STATE_KEY, "turbo-checkout-page-state"), f(d.DEVICE_OVERRIDE, ""), f(d.CONFLICTING_INITIATE_LISTENERS, []), f(d.CHECKBOX_EXCLUSION_ROOT_NODES,
                        ".simpleBundleCheckBoxArea #simpleBundle_feature_div #monthlyPayments_feature_div #bbg_feature_div #addons_feature_div #mobile-accessory-upsell #detailPageGifting_feature_div".split(" ")), f(d.MASH_ADAPTER, ""), f(d.IS_ADD_TO_CART_ENABLED, !0), f(d.IS_BUYNOW_ENABLED_FOR_SCREENREADER, !0), f(d.BACKGROUND_SCROLL_TARGET_SELECTOR, "#productTitleGroupAnchor"), f(d.VAS_CHANGE_EVENTS, ["turbo:checkout:sheet:doClose"]), f(d.VAS_CHECKBOX_SELCTOR, "#vas-checkbox-input"), f(d.VAS_CHANGE_EVENTS, ["turbo:checkout:sheet:doClose"]),
                    f(d.VAS_CHECKBOX_SELCTOR, "#vas-checkbox-input"), f(d.OVERRIDE_ELIGIBILITY, g));
                b = k;
                return b[a]
            },
            KEYS: c.copy(d)
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-weblab-allocation", "turbo-checkout-state-handler", "turbo-checkbox-exclusion-listener", "turbo-checkout-content-loader", "turbo-checkout-device-filter", "turbo-callback-list", "turbo-checkout-auto-open", "turbo-checkout-vas-input", "turbo-checkout-page-ready").register("turbo-base-eligible-state", function(c, d, a, b, g, f, h, e, l) {
        function k() {
            t = !0
        }

        function m() {
            t = !1
        }

        function n() {
            var c = new r;
            f.isDeviceTurboEligible() || c.invalidate("Device is NOT eligible");
            g.isError() && !d.isNoPrefetch() && c.invalidate("Prefetch failed");
            a.isProductTurboEligible() || c.invalidate("Product is NOT eligible");
            e.isAutoOpenEnabled() || t || c.invalidate("Cheetah eligibility response is false");
            d.isControl() && c.invalidate("Weblab is in CONTROL");
            d.isBuyNowOnly() && c.invalidate("Weblab is in buy now only treatment");
            l.isSelected() && c.invalidate("Value added service is selected and NOT supported");
            b.isAnyCheckboxChecked() && c.invalidate("Exclusion case checkbox is checked");
            A.callAll(c);
            c.logInvalidState();
            return c.canShow()
        }

        function r() {
            var a = !0,
                b = [];
            this.invalidate = function(c) {
                a = !1;
                b.push(c)
            };
            this.logInvalidState = function() {
                a || c.logDebug("turbo-base-eligible-state", "Cannot show turbo because: " + b)
            };
            this.canShow = function() {
                return a
            }
        }

        function q(a) {
            x.callAll(n(), a)
        }
        var A = h.create(),
            x = h.create(),
            t = !1;
        return {
            addStateCheck: function(a) {
                A.push(a)
            },
            canShow: n,
            registerStateChangeCallback: function(a) {
                x.push(a)
            },
            onStateChange: q,
            setup: function() {
                g.registerCallback({
                    onTurboEligible: k,
                    onFinish: k,
                    onTurboIneligible: m
                });
                a.registerCallback(q);
                b.onStateChange(q);
                l.onChange(q)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-base-view", function(c, d) {
        function a(a) {
            if ("string" !== typeof a) throw "Parameter 'iFrameContainerSelector' is not a string.";
            this.onBoundsAdjustedCallbacks = d.create();
            this.IFRAME_CONTAINER_SELECTOR = a
        }
        var b = c.$;
        a.prototype.updateBounds = function(a) {
            if ("number" !==
                typeof a) throw 'Parameter "iFrameContentHeight" is not a number. Cannot validate bounds.';
            var b = this.$getIFrameContainer().height(),
                c = a - b;
            a = b + c;
            0 !== c && (this.$getIFrameContainer().height(a), c = parseInt(this.$getIFrameContainer().css("min-height"), 10), a = a > c ? a : c, b !== a && this.onBoundsAdjustedCallbacks.callAll(a))
        };
        a.prototype.$getIFrameContainer = function() {
            return b(this.IFRAME_CONTAINER_SELECTOR)
        };
        a.prototype.pushBoundsAdjustedCallback = function(a) {
            this.onBoundsAdjustedCallbacks.push(a)
        };
        return {
            extend: function() {
                function b() {
                    a.apply(this,
                        arguments)
                }
                b.prototype = Object.create(a.prototype);
                return b.prototype.constructor = b
            }
        }
    });
    "use strict";
    e.when("turbo-configuration", "turbo-checkout-page-ready").execute("turbo-eligible-state-check", function(c) {
        c.get(c.KEYS.EXTEND_ELIGIBLE_STATE) || e.when("turbo-base-eligible-state").register("turbo-checkout-eligible-state", function(c) {
            return {
                canShow: c.canShow,
                registerStateChangeCallback: c.registerStateChangeCallback,
                setup: c.setup
            }
        })
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-configuration",
        "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-weblab-allocation", function(c, d, a) {
        function b() {
            return d.getWeblabAllocation()
        }
        return {
            getAllocation: b,
            getExperimentName: function() {
                return d.getExperimentName()
            },
            isControl: function() {
                return "C" === b()
            },
            isBuyNowOnly: function() {
                return b() === a.get(a.KEYS.BUY_NOW_ONLY_TREATMENT)
            },
            isPrefetch: function() {
                return b() === a.get(a.KEYS.PREFETCH_TREATMENT)
            },
            isNoPrefetch: function() {
                var c = a.get(a.KEYS.NO_PREFETCH_TREATMENT);
                return !!b().match(c)
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-ajax-wrapper", "turbo-checkout-utils", "turbo-checkout-urls", "turbo-checkout-csm", "turbo-checkout-weblab-allocation", "turbo-checkout-buy-now-button", "turbo-configuration", "turbo-checkout-state-handler", "turbo-checkout-eligibility-response-weblabs", "turbo-checkout-page-ready").register("turbo-checkout-weblab-trigger", function(c, d, a, b, g, f, e, m, l, k, p) {
        function n() {
            c.on("turbo:checkout:prefetch:onTurboEligible", function() {
                E = !0;
                A()
            })
        }

        function r() {
            c.on("turbo:checkout:prefetch:onTurboIneligible",
                function() {
                    E = !1;
                    A()
                })
        }

        function q() {
            c.on("a:pageUpdate", function() {
                A()
            })
        }

        function A() {
            0 === x().length ? f.logCount("turboCheckoutBuyNowButtonMissing") : 0 === t().length && f.logCount("turboCheckoutBuyNowFormMissing");
            0 < t().length && (E ? (b.logDebug("turbo-checkout-weblab-trigger", "Adding trigger to form: " + e.getAllocation()), u.val(e.getAllocation()), v.val(e.getExperimentName()), D.val(k.getRequestId()), y.val(k.getSessionId()), t().append(u, v, D, y)) : (b.logDebug("turbo-checkout-weblab-trigger", "Removing trigger from form: " +
                e.getAllocation()), u.remove(), v.remove(), D.remove(), y.remove()))
        }

        function x() {
            var a = l.get(l.KEYS.BUY_NOW_BUTTON_SELECTOR);
            return d(a)
        }

        function t() {
            return x().closest("form")
        }

        function z() {
            function c(b, d, e) {
                b = !E || k.isTurboLaunched() ? g.buildTriggerWeblabPathWithoutWeblab(k.getRequestId(), k.getSessionId()) : g.buildTriggerWeblabPathWith(b, d, k.getRequestId(), k.getSessionId());
                a.load(b, {
                    method: "POST",
                    params: {
                        additionalWeblabsToTrigger: JSON.stringify(e)
                    },
                    error: function(a, b, c) {
                        a && 204 === a.http.status || f.logCount("turboCheckoutTriggerRecordingFailed")
                    },
                    abort: function(a) {
                        f.logCount("turboCheckoutTriggerRecordingFailed")
                    }
                })
            }
            if (p.get() && 0 < p.get().length || E && !k.isTurboLaunched()) b.logDebug("turbo-checkout-weblab-trigger", "Calling cheetah to trigger: " + e.getAllocation()), 0 < t().find(u).length || f.logCount("turboCheckoutTriggerMissing"), c(e.getExperimentName(), e.getAllocation(), p.get())
        }
        var u, v, D, y, E = !1;
        return {
            setup: function() {
                u = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "triggerTurboWeblab",
                    value: ""
                });
                v = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "triggerTurboWeblabName",
                    value: ""
                });
                D = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "turboPageRequestId",
                    value: ""
                });
                y = d("\x3cinput/\x3e", {
                    type: "hidden",
                    name: "turboPageSessionId",
                    value: ""
                });
                q();
                n();
                r();
                m.registerOnClickCallback(z)
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-checkout-page-ready").register("turbo-checkout-page-filter", function(c, d) {
        return {
            isCurrentViewTurboEligible: function() {
                var a = c.$(d.getInitiateSelector());
                return 0 < a.length && a.closest("form").length === a.length
            }
        }
    });
    "use strict";
    e.when("turbo-configuration",
        "turbo-checkout-page-ready").execute("turbo-device-filter-check", function(c) {
        c.get(c.KEYS.IS_DEVICE_FILTER_REQUIRED) || e.when("turbo-checkout-cacher", "turbo-checkout-page-ready").register("turbo-checkout-device-filter", function(c) {
            var a = function() {
                return !0
            };
            return {
                isDeviceTurboEligible: c.createCache(a),
                isSignInSupported: c.createCache(a)
            }
        })
    });
    "use strict";
    e.when("A", "turbo-checkout-state-handler", "turbo-checkout-device-filter", "turbo-checkout-page-filter", "turbo-checkout-weblab-allocation", "turbo-checkout-page-ready").register("turbo-checkout-eligibility-aggregator",
        function(c, d, a, b, g) {
            return {
                isTurboEligible: function() {
                    return b.isCurrentViewTurboEligible() && d.isProductTurboEligible() && !g.isBuyNowOnly()
                },
                isSignInSupported: function() {
                    return a.isSignInSupported() && !g.isBuyNowOnly()
                },
                shouldAttemptPrefetch: function() {
                    return a.isDeviceTurboEligible() && !g.isBuyNowOnly()
                }
            }
        });
    "use strict";
    e.when("A", "turbo-filtered-callback-list", "turbo-checkout-state-handler", "turbo-checkout-ajax-wrapper", "turbo-checkout-utils", "turbo-checkout-urls", "turbo-checkout-csm", "turbo-checkout-eligibility-aggregator",
        "turbo-checkout-eligibility-response-weblabs", "turbo-checkout-page-ready").register("turbo-checkout-content-loader", function(c, d, a, b, g, f, e, w, l) {
        function k(d) {
            e.logCount("turboCheckoutInitiate");
            D();
            L = !1;
            K = Date.now();
            q("Notifying loading callbacks");
            B = "started";
            M.callAll();
            c.trigger("turbo:checkout:prefetch:onStart");
            e.logCount("turboCheckoutPrefetchStart");
            var g = f.buildInitiatePathWith(a.getExperimentName(), d, a.getRequestId(), a.getSessionId());
            I = b.loadWithJQXHR(g, {
                type: "POST",
                data: p(d),
                headers: n(),
                xhr: r,
                success: t,
                error: z
            })
        }

        function p(b) {
            var c = {
                isAsync: 1
            };
            a.getAddressId() && (c.addressID = a.getAddressId());
            a.isPhysicalGiftCardExperimentEligible() && (c.isPhysicalGiftCard = a.isPhysicalGiftCardExperimentEligible());
            b || a.getLineItems().forEach(function(a, b) {
                b += 1;
                c["asin." + b] = a.asin;
                c["offerListing." + b] = a.offerListingId;
                c["quantity." + b] = a.quantity;
                a.customItemPrice && (c["customItemPrice." + b] = a.customItemPrice, c.customItemPrice = a.customItemPrice)
            });
            return c
        }

        function n() {
            var a = {
                "x-amz-support-custom-signin": 1
            };
            a["x-amz-turbo-checkout-dp-url"] = m.location.href;
            a["x-amz-checkout-entry-referer-url"] = m.location.href;
            return a
        }

        function r() {
            var a = b.createXHRRequest();
            a.addEventListener("readystatechange", function() {
                if (L || !a.readyState || 2 > a.readyState) q("Ignoring ready state changed event because headers already received or missing xhr");
                else if (L = !0, e.logCount("turboCheckoutPrefetchHeadersReceived"), e.logCount("turboCheckoutPrefetchHeadersReceivedDuration", Date.now() - K), u(a)) {
                    q("Headers received: Turbo eligible");
                    e.logCount("turboCheckoutTurboEligibleAfterCheetahChecks");
                    var b = A(a),
                        d = w.isSignInSupported();
                    b && (q("Headers received: Signin required"), e.logCount("turboCheckoutSigninRequired"), d || (q("Sign-in required but it is disabled or not supported."), e.logCount("turboCheckoutSigninNotSupported")));
                    if (d || !b) q("Notifying turbo eligible callbacks"), Q.callAll(), c.trigger("turbo:checkout:prefetch:onTurboEligible");
                    x(a) && G.callAll(a.getResponseHeader("x-amzn-checkout-login-provider"))
                } else q("Headers received: Not turbo eligible"),
                    O.callAll(), c.trigger("turbo:checkout:prefetch:onTurboIneligible")
            });
            return a
        }

        function q(a, b) {
            g.logDebug("turbo-checkout-content-loader", a, b)
        }

        function A(a) {
            return a && a.getResponseHeader("x-amzn-checkout-login-required")
        }

        function x(a) {
            return w.isSignInSupported() && A(a)
        }

        function t(a, b, d) {
            e.logCount("turboCheckoutPrefetchEnd", Date.now() - K);
            I = null;
            b = u(d);
            var f, k = a && a.match(y);
            if (k && 0 < k.length) try {
                var m = E(k[0]);
                f = E.parseJSON(m.text())
            } catch (n) {
                g.logError("Could not extract page state from cheetah page: " +
                    n)
            } else q("Could not extract page state from response data");
            var m = f && "turbo" === f.pipelineType,
                k = f && f.currentPurchaseId && 0 < String(f.currentPurchaseId).trim().length,
                t = d.getResponseHeader("x-amzn-experiment-weblabs-to-trigger");
            if (t !== C) {
                var p = [];
                try {
                    p = JSON.parse(t)
                } catch (n) {
                    console.error("Error parsing additional weblabs from xhr response header: ", n)
                }
                l.set(p)
            }
            m && !k && g.logError("No purchaseid provided, cannot show turbo");
            b && m && k ? ("started" !== B && g.logError("turbo-checkout-content-loader", "Error processing turbo available callbacks. Expected state to be started but was " +
                B), q("Notifying turbo available callbacks"), B = "success", N.callAll(a, f), c.trigger("turbo:checkout:prefetch:onSuccess"), e.logCount("turboCheckoutTurboPrefetchSuccess")) : b && x(d) ? q("Body received: Eligible and sign-in is supported and required.") : (q("Body received: No turbo page or not eligible: isTurboEligible: " + b + " isTurboPage: " + m + " hasPurchaseId: " + k), v(), e.logCount("turboCheckoutTurboPrefetchFail"))
        }

        function z(a, b, c) {
            e.logCount("turboCheckoutPrefetchEnd");
            I = null;
            q("Error while initiate", c);
            e.logCount("turboCheckoutTurboPrefetchError");
            "timeout" === b && e.logCount("turboCheckoutInitiateTimeOut");
            v()
        }

        function u(a) {
            return a && a.getResponseHeader("x-amz-turbo-checkout-eligible")
        }

        function v() {
            "started" !== B && g.logError("turbo-checkout-content-loader", "Error processing turbo not available callbacks. Expected state to be started but was " + B);
            q("Notifying error callbacks");
            B = "error";
            P.callAll();
            c.trigger("turbo:checkout:prefetch:onError")
        }

        function D() {
            I && I.abort && (q("Aborting running request..."), I.abort())
        }
        var y = /<script.*data-a-state.*checkout:conductor:page.*>.*<\/script>/,
            E = c.$,
            I, B = "stopped",
            K, L = !1,
            M = d.create("onStart"),
            N = d.create("onFinish"),
            P = d.create("onError"),
            Q = d.create("onTurboEligible"),
            O = d.create("onTurboIneligible"),
            G = d.create("onSigninRequired");
        c.on("turbo:checkout:signInController:onDoSignIn", v);
        return {
            registerCallback: function(a) {
                M.push(a);
                N.push(a);
                P.push(a);
                Q.push(a);
                G.push(a);
                O.push(a)
            },
            callInitiate: function() {
                q("Calling turbo initiate");
                k()
            },
            checkEligibility: function() {
                q("Calling turbo eligibility check only");
                k(!0)
            },
            abortCall: D,
            isSuccess: function() {
                return "success" ===
                    B
            },
            isError: function() {
                return "error" === B
            },
            isStarted: function() {
                return "started" === B
            }
        }
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-ref-tagger", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-history-manager", function(c, d, a, b) {
        function g() {
            if (m.history.state && m.history.state.turboAction) return m.history.state.turboAction
        }
        d(m).bind("popstate.turbo", function(d) {
            g();
            g() ? (b.logDebug("turbo-checkout-history-manager", "Trigger sheet open"), c.trigger("turbo:checkout:sheet:doOpen")) :
                (b.logDebug("turbo-checkout-history-manager", "Trigger sheet close"), c.trigger("turbo:checkout:sheet:doClose", {
                    immediate: !1,
                    reason: a.TAGS.BACK
                }))
        });
        return {
            sheetOpened: function() {
                g();
                g() || (b.logDebug("turbo-checkout-history-manager", "Adding turbo history state"), m.history.pushState({
                    turboAction: "popover"
                }, document.title + " Turbo open"))
            },
            sheetClosed: function() {
                g();
                g() && (b.logDebug("turbo-checkout-history-manager", "Removing turbo history state"), m.history.back())
            }
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-base-visibility-manager",
        function(c) {
            function d() {
                c.trigger("turbo:checkout:page:gone")
            }
            return {
                setup: function() {
                    c.on("turbo:checkout:sheet:onNavigateAway", d)
                }
            }
        });
    e.when("turbo-configuration", "turbo-checkout-page-ready").execute("turbo-mash-will-reappear-check", function(c) {
        c.get(c.KEYS.USES_MASH_WILL_REAPPEAR) || e.when("turbo-base-visibility-manager").register("turbo-checkout-page-visibility-manager", function(c) {
            return c
        })
    });
    "use strict";
    e.when("A", "jQuery", "turbo-checkout-view-state", "turbo-checkout-weblab-allocation", "turbo-checkout-state-handler",
        "turbo-checkout-content-loader", "turbo-checkout-prefetch-timer", "turbo-checkout-page-visibility-manager", "turbo-checkout-counter", "turbo-checkout-utils", "turbo-checkout-eligibility-aggregator", "turbo-checkout-auto-open", "turbo-checkout-page-ready").register("turbo-checkout-prefetcher", function(c, d, a, b, g, e, h, m, l, k, p, n) {
        function r(a) {
            var b = A;
            A = a;
            k.logDebug("turbo-checkout-prefetcher", "Transitioning from " + b.name + " to " + a.name);
            if (b.onExit) b.onExit(a.name);
            if (a.onEnter) a.onEnter(b.name);
            c.trigger("turbo:checkout:prefetcher:state:" +
                a.name);
            c.trigger("turbo:checkout:prefetcher:state", a.name)
        }
        var q, A, x = function() {
                var a = e.isError(),
                    b = !p.isTurboEligible(),
                    c = h.isTimeout(),
                    d = 0 === q;
                k.logDebug("turbo-checkout-prefetcher", "Test is data stale: isStaleWhenCheetahReturnsError: " + a + " isStaleWhenProductNotEligiblie: " + b + " isStaleWhenTimeoutOccurs: " + c + " isStaleWhenNoMorePrefetchesAvailable: " + d);
                return a || b || c || d
            },
            t = function() {
                var a = p.isTurboEligible() && !h.isTimeout() && 0 < q;
                k.logDebug("turbo-checkout-prefetcher", "Test should prefetch: eligibilityAggregator.isTurboEligible(): " +
                    p.isTurboEligible() + " !timer.isTimeout(): " + !h.isTimeout() + " _prefetchesAvailable: " + q);
                return a
            },
            z = {
                name: "start",
                onEvent: function(a) {
                    p.shouldAttemptPrefetch() ? "controller:onPageLoaded" === a && r(u) : r(y)
                },
                onExit: function() {
                    g.startMonitoringPage()
                }
            },
            u = {
                name: "dataStale",
                onEvent: function(a) {
                    "page:gone" !== a && "prefetch:onError" !== a && "sheet:afterClose" !== a && t() && r(v)
                }
            },
            v = {
                name: "dataPrefetching",
                onEnter: function() {
                    l.incrementPrefetchCounter();
                    b.isPrefetch() || a.isOpeningOrOpen() || n.isAutoOpenReadyToBeOpened() ?
                        e.callInitiate() : e.checkEligibility();
                    --q
                },
                onEvent: function(a) {
                    if ("page:gone" === a) r(u);
                    else {
                        var c = e.isSuccess() && b.isPrefetch(),
                            d = e.isSuccess() && b.isNoPrefetch();
                        k.logDebug("turbo-checkout-prefetcher", "Test is data fresh: isFreshWhenPrefetchResultOKInT1: " + c + " isFreshWhenPrefetchResultOKInT4: " + d);
                        c || d ? r(D) : x() ? r(u) : "product:onChange" === a && t() && r(v)
                    }
                },
                onExit: function(a) {
                    "dataFresh" !== a && e.abortCall()
                }
            },
            D = {
                name: "dataFresh",
                onEnter: function() {
                    h.startTimer()
                },
                onEvent: function(b) {
                    "page:gone" === b ? r(u) :
                        x() ? r(u) : (a.isClosed() || "product:onChange" === b) && t() && r(v)
                },
                onExit: function() {
                    h.resetTimer()
                }
            },
            y = {
                name: "end"
            },
            E = "controller:onPageLoaded sheet:beforeOpen sheet:afterClose product:onChange prefetch:onSuccess prefetch:onError timer:onTimeout page:gone page:reappear".split(" "),
            C = {
                "sheet:beforeOpen": function() {
                    q = 10
                }
            };
        return {
            setup: function() {
                q = 10;
                A = z;
                d.each(E, function(a, b) {
                    var d = C[b];
                    c.on("turbo:checkout:" + b, function(a) {
                        k.logDebug("turbo-checkout-prefetcher", "Processing " + b);
                        d && d();
                        if (A.onEvent) A.onEvent(b)
                    })
                })
            },
            getState: function() {
                return A.name
            }
        }
    });
    "use strict";
    e.when("A", "turbo-signin-adapter", "turbo-checkout-content-loader", "turbo-checkout-buy-now-button", "turbo-checkout-csm", "turbo-checkout-weblab-allocation", "turbo-checkout-utils", "turbo-callback-list", "turbo-checkout-state-handler", "turbo-checkout-eligible-state", "turbo-checkout-page-ready").register("turbo-checkout-signin-controller", function(c, d, a, b, e, f, h, m, l, k) {
        function p() {
            t = !1
        }

        function n(a) {
            t = !0;
            z = a;
            e.logCount("turboCheckoutSigninRequired")
        }

        function r() {
            var a =
                t && k.canShow();
            a && (h.logDebug("turbo-checkout-signin-controller", "Showing sign in dialog"), e.logCount("turboCheckoutSigninPopup"), d.show(z, q, A), c.trigger("turbo:checkout:signInController:onDoSignIn"));
            return a
        }

        function q() {
            h.logDebug("turbo-checkout-signin-controller", "Signin success");
            e.logCount("turboCheckoutSigninSuccess");
            x.callAll()
        }

        function A() {
            h.logDebug("turbo-checkout-signin-controller", "Signin failed");
            e.logCount("turboCheckoutSigninFailed")
        }
        var x = m.create(),
            t = !1,
            z;
        return {
            setup: function() {
                a.registerCallback({
                    onStart: p,
                    onSigninRequired: n
                });
                b.registerOnClickCallback(r)
            },
            registerCallback: x.push
        }
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-callback-list", "turbo-filtered-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-iframe", function(c, d, a, b) {
        function e() {
            return c.$("#" + k)
        }

        function f() {
            if (!(0 < e().length)) throw "Attempted to read / write the iFrame without it being in the DOM. This would result in an undefined iFrame document.";
            var a = e()[0];
            return a.contentDocument || a.contentWindow.document
        }

        function h() {
            if (0 < e().length) throw "Attempted to insert multiple Turbo Checkout iFrames";
        }

        function m() {
            return c.$("\x3ciframe/\x3e", {
                id: k,
                src: "about:blank",
                scrolling: "no",
                "class": "turbo-checkout-blank"
            })
        }

        function l(a) {
            r.push(a)
        }
        var k = d.get(d.KEYS.IFRAME_ID),
            p = b.create("beforeFramePopulated"),
            n = b.create("afterFramePopulated"),
            r = a.create();
        l(function(a) {
            a.addClass("turbo-checkout-shown")
        });
        c.on("turbo:checkout:iframe:document:loaded", function() {
            r.callAll(e())
        });
        return {
            write: function(a) {
                p.callAll();
                a +=
                    '\x3cscript\x3e"use strict";window.parent.P.now("turbo-checkout-controller").execute("callbackPageController", function callbackPageController(controller) {controller.frameHtmlRendered();});P.when("load").execute("onTurboDocumentLoaded", function onTurboDocumentLoaded() {window.parent.P.when("A").execute("triggerTurboDocumentLoaded", function triggerTurboDocumentLoaded(A) {A.trigger("turbo:checkout:iframe:document:loaded");});});\x3c/script\x3e';
                if ("string" !== typeof a) throw "Attempted to write non-string value to iFrame. typeof \x3d " +
                    typeof a;
                var b = f();
                b.open();
                b.write(a);
                b.close();
                n.callAll(e()[0])
            },
            remove: function() {
                e().remove()
            },
            appendTo: function(a) {
                h();
                a.append(m())
            },
            insertInto: function(a) {
                h();
                a.html(m())
            },
            hasContent: function() {
                var a = 0 < e().length && f();
                return a && (a.body.hasChildNodes() || a.head.hasChildNodes())
            },
            registerCallbacks: function(a) {
                p.push(a);
                n.push(a)
            },
            onContentLoaded: l
        }
    });
    "use strict";
    e.when("A", "turbo-checkout-page-ready").register("turbo-checkout-view-state", function(c) {
        function d(a, b) {
            return function() {
                return e ===
                    a || e === b
            }
        }

        function a(a) {
            return function() {
                e = a;
                b.apply(b, arguments)
            }
        }

        function b(a, b) {
            a && "string" === typeof a && c.trigger(a, b)
        }
        var e = 0;
        return {
            isClosed: d(0),
            isClosing: d(1),
            isOpen: d(2),
            isOpening: d(3),
            isClosingOrClosed: d(1, 0),
            isOpeningOrOpen: d(3, 2),
            setToOpen: a(2),
            setToOpening: a(3),
            setToClosed: a(0),
            setToClosing: a(1)
        }
    });
    "use strict";
    e.when("A", "turbo-view-adapter", "turbo-checkout-view-state", "turbo-checkout-eligible-state", "turbo-checkout-content-loader", "turbo-checkout-utils", "turbo-checkout-weblab-allocation",
        "turbo-checkout-weblab-trigger", "turbo-checkout-csm", "turbo-checkout-state-handler", "turbo-checkout-device-filter", "turbo-checkout-ajax-wrapper", "turbo-checkout-page-visibility-manager", "turbo-checkout-counter", "turbo-checkout-prefetcher", "turbo-checkout-prefetch-timer", "turbo-checkout-buy-now-button", "turbo-checkout-signin-controller", "turbo-checkout-auto-open", "turbo-checkout-urls", "turbo-checkout-ref-tagger", "turbo-configuration", "turbo-interstitial-suppression", "turbo-checkout-page-ready").register("turbo-checkout-controller",
        function(c, d, a, b, e, f, h, m, l, k, p, n, r, q, A, x, t, z, u, v, D, y, E) {
            function C() {
                T && E && t.removeConflictingListeners();
                t.bindTurboClickEvent()
            }

            function B(a, b) {
                f.logDebug("turbo-checkout-controller", a, b)
            }

            function K(a, b) {
                G();
                a || d.close({
                    reason: b
                })
            }

            function L() {
                B("Handling signin success");
                N()
            }

            function M() {
                B("Handling buy now button click");
                N();
                return !0
            }

            function N() {
                W = setTimeout(P, 2E4);
                H = l.createScope();
                H.markClick();
                J = "loading";
                S = !1;
                x.checkTimeout();
                q.incrementSheetOpenedCounter();
                d.show()
            }

            function P() {
                l.logCount("turboCheckoutContenLoadTimeout")
            }

            function Q() {
                G();
                d.removeContent()
            }

            function O() {
                G()
            }

            function G() {
                b.canShow() ? (B("Registering with buy now button"), c.trigger("turbo:checkout:buyNowEnabled"), T = !0, t.registerOnClickCallback(M)) : (B("Unregistering from buy now button"), c.trigger("turbo:checkout:buyNowDisabled"), T = !1, t.deregisterOnClickCallback(M))
            }

            function Y(a, b) {
                l.logCount("turboCheckoutPrefetchSuccess");
                a && (h.isControl() || h.isBuyNowOnly()) && (B("Received content in control: " + a.substring(0, 255)), l.logCount("turboCheckoutControlContentReceived"));
                U = b;
                d.setContent(a);
                G()
            }

            function Z() {
                G();
                a.isOpeningOrOpen() && (l.logCount("turboCheckoutYieldNewPurchase"), d.closeImmediatelyThenExecute(V))
            }

            function aa() {
                clearTimeout(W);
                J = "unknown";
                !F || F.isResolved() || F.isRejected() || (B("Initiate confirm called for " + U.currentPurchaseId + " with existing confirm still executing. Aborting"), l.logCount("turboCheckoutConfirmPending"), F._supersedByNewPurchase = !0, F.abort());
                ba()
            }

            function ba() {
                l.logCount("turboCheckoutConfirm");
                var a = U.currentPurchaseId,
                    b = v.buildConfirmPathWith(h.getExperimentName(),
                        k.getRequestId(), k.getSessionId());
                F = n.loadWithJQXHR(b, {
                    type: "POST",
                    data: {
                        pid: a,
                        isInitiateLoggingFixEnabled: 1
                    },
                    success: function(a, b, c) {
                        l.logCount("turboCheckoutConfirmSuccess")
                    },
                    error: function(b, c, e) {
                        "abort" === c ? l.logCount("turboCheckoutConfirmAborted") : ("timeout" === c && l.logCount("turboCheckoutConfirmTimeOut"), l.logCount("turboCheckoutConfirmFailed"));
                        b._supersedByNewPurchase || (f.logError("Issue confirming turbo initiate prefetch for pid " + a + ": " + e + ", " + c), l.logCount("turboCheckoutYieldNewPurchase"),
                            d.closeImmediatelyThenExecute(V))
                    }
                })
            }

            function ca() {
                H.markFirstByte()
            }

            function R() {
                return y.get(y.KEYS.HOST_PAGE_TYPE_IDENTIFIER)
            }

            function V() {
                t.executeOriginalBuyNowAction(k.getActiveId())
            }

            function ea(a) {
                c.trigger("turbo:checkout:embedded:page:showSpinner");
                F.done(a)
            }

            function da(a, b, c) {
                J = c;
                S = !1
            }

            function fa() {
                S = !0
            }

            function ga(a) {
                a && a.doNotLog || (a && !a.doNotLog ? X(J, a.reason) : X(J, !1));
                J = "closed"
            }

            function X(a, b) {
                var c = v.buildLogPageHitPathWith(S ? a + "2" : a, b);
                B("Logging page hit from " + a + " to " + R() + " reason " +
                    b);
                n.load(c, {
                    method: "POST",
                    params: {
                        pageType: R(),
                        referrer: a
                    },
                    timeout: 4E3
                })
            }

            function ha() {
                a.isOpeningOrOpen() && l.logCount("turboCheckoutProductChangedWhileOpening")
            }
            var H, J, U, S, W, F, T = !1;
            c.on("a:pageUpdate", C);
            C();
            return {
                pageLoaded: function() {
                    var a = h.getExperimentName();
                    if (a) {
                        var f = h.getAllocation();
                        l.addCounterExtraSuffix("wl:" + f);
                        l.addCounterExtraSuffix(a + ":" + f)
                    }
                    p.isDeviceTurboEligible() && (b.setup(), b.registerStateChangeCallback(K), r.setup(), e.registerCallback({
                        onStart: Q,
                        onTurboEligible: O,
                        onFinish: Y,
                        onError: Z
                    }), m.setup(), z.setup(), z.registerCallback(L), H = l.createScope(), d.registerCallbacks({
                        beforeFramePopulated: aa,
                        afterFramePopulated: ca
                    }), k.registerCallback(ha), c.on("turbo:checkout:sheet:beforeClose", ga), c.on("turbo:checkout:embedded:page:beforeReload", da), c.on("turbo:checkout:embedded:page:animation:start", fa), u.setup(t.executeTurboBuyNowAction, O), A.setup(), c.trigger("turbo:checkout:controller:onPageLoaded"))
                },
                loadFullscreen: function(a, b) {
                    function c() {
                        a = f.createFQDN(a);
                        "thankyou" === b ? (l.logCount("turboCheckoutYieldTYP"),
                            d.closeAndNavigate(a)) : (l.logCount("turboCheckoutYield"), d.closeToFullscreen(a))
                    }!F || F.isResolved() || F.isRejected() ? c() : (l.logCount("turboCheckoutWaitYield"), ea(c))
                },
                frameContentReady: function(a, b, d) {
                    c.trigger("turbo:checkout:embedded:page:ready", a, b);
                    (function() {
                        var a = function() {
                            H.markCriticalFeature();
                            d.confirmHit(R(), D.generateValue(R(), D.ACTIONS.BUY_NOW));
                            H.whenDataSet(d.recordClientSideMetrics);
                            b.off("checkout:afterReload", a)
                        };
                        b.on("checkout:afterReload", a)
                    })();
                    (function() {
                        b.on("checkout:beforeReload",
                            function(d) {
                                c.trigger("turbo:checkout:embedded:page:beforeReload", a, b, d)
                            });
                        b.on("checkout:reload", function(d) {
                            c.trigger("turbo:checkout:embedded:page:reload", a, b, d)
                        });
                        b.on("checkout:afterReload", function(d) {
                            c.trigger("turbo:checkout:embedded:page:afterReload", a, b, d)
                        });
                        b.on("turbo:checkout:animation:start", function() {
                            c.trigger("turbo:checkout:embedded:page:animation:start")
                        });
                        c.on("turbo:checkout:embedded:page:showSpinner", function() {
                            d.showSpinner()
                        })
                    })()
                },
                frameHtmlRendered: function() {
                    H.markAboveTheFold()
                },
                updateBounds: function(a) {
                    d.updateBounds(a)
                }
            }
        });
    "use strict";
    e.when("turbo-checkout-page-load-spinner", "turbo-checkout-controller", "turbo-checkout-csm", "turbo-checkout-page-ready").register("turbo-checkout-startup", function(c, d, a) {
        c.removePageLoadSpinner();
        a.logCount("turboCheckoutControllerPageLoaded");
        d.pageLoaded()
    });
    "use strict";
    e.when("turbo-checkout-assets-load-trigger").register("turbo-checkout-page-ready", function() {
        m.ue && m.ue.count && "undefined" !== typeof m.ue_t0 && m.ue.count("turboCheckoutPageReady",
            Date.now() - m.ue_t0)
    });
    "use strict";
    e.when("A", "turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-checkout-quantity-input", "turbo-checkout-warranty-input", "turbo-checkout-page-ready").register("turbo-checkout-authportal-return-query", function(c, d, a, b, e, f) {
        function h(b) {
            a.logDebug("turbo-checkout-authportal-return-query", b)
        }

        function w(a) {
            a = a.match(q);
            a = c.reduce(a, function(a, b) {
                var c = b.split("\x3d");
                b = c[0];
                c = c[1] || "";
                a.hasOwnProperty(b) && l("Duplicate query key detected @ key \x3d  " +
                    b + " -- Redirect URL will contain only last value read!");
                a[b] = c;
                return a
            }, {});
            return "?" + c.$.param(a)
        }

        function l(b) {
            a.logWarning(b, "turbo-checkout-authportal-return-query")
        }

        function k(a) {
            return !!a.match("trb_auth\x3d1")
        }

        function p(c) {
            if (k(c)) {
                c = ((c || "").match(A) || [])[1] || "";
                var e = b.getSessionId();
                a.isNonEmptyString(c) || d.logCount("turboCheckoutPostAuthEmptySessionParameter");
                a.isNonEmptyString(e) || d.logCount("turboCheckoutPostAuthEmptySessionPageState");
                a.isNonEmptyString(c) && a.isNonEmptyString(e) &&
                    c !== e && (l("Turbo Session Flip Detected. Post authentication sessionId \x3d " + e + ", Expected \x3d " + c), d.logCount("turboCheckoutPostAuthSessionFlip"))
            }
        }
        var n = /&?(openid|aToken|serial)[^&]*/g,
            r = /&?trb_(open|auth|qty|warrAsin|sid)=[^&]*/g,
            q = /[^(=\?&)]+[^&]*/g,
            A = /&?trb_sid=([^&]*)/;
        p(m.location.search);
        return {
            buildFrom: function(a) {
                h("Initial Query \x3d " + a);
                a = (a || "?").replace(n, "");
                a = a.replace(r, "");
                a = w(a);
                a += "\x26trb_auth\x3d1\x26trb_open\x3d1";
                var c = e.getQuantity();
                a += 1 < c ? "\x26trb_qty\x3d" + c : "";
                c = f.getLineItem();
                a += c && c.asin ? "\x26trb_warrAsin\x3d" + c.asin : "";
                c = b.getSessionId();
                a += 0 < c.length ? "\x26trb_sid\x3d" + c : "";
                c = b.getActiveId();
                a = (a + (c ? "\x26trb_bid\x3d" + c : "")).replace(/\?+&*/, "?").replace(/\?*&+\?*&*/g, "\x26");
                h("Final Query \x3d " + a);
                return a
            },
            isReturningFromAuthPortal: k,
            validateSession: p
        }
    });
    "use strict";
    e.when("turbo-checkout-csm", "turbo-checkout-auto-open", "turbo-checkout-authportal-return-query", "turbo-checkout-page-ready").register("turbo-checkout-browser-signin", function(c, d, a) {
        function b() {
            var a =
                m.location.search.match(e) ? "turboCheckoutSigninSuccess" : "turboCheckoutSigninFailed";
            c.logCount(a)
        }
        var e = /openid\.mode=id_res/,
            f = /(\/ref=[^/]*\/?$|\/?$)/;
        a.isReturningFromAuthPortal(m.location.search) && (c.logCount("turboCheckoutAuthPortalReturn"), b());
        return {
            show: function(b) {
                b = b + (-1 === b.indexOf("?") ? "?" : "\x26") + "openid.return_to\x3d";
                var e;
                e = a.buildFrom(m.location.search);
                e = encodeURIComponent("https://" + m.location.hostname + m.location.pathname.replace(f, "/ref\x3dtrb_chk_auth") + e);
                b += e;
                c.logCount("turboCheckoutSignInUrlSize",
                    b.length);
                d.reset();
                m.location.href = b
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-utils", "turbo-checkout-state-handler", "turbo-checkout-page-ready").register("turbo-checkout-strings", function(c, d) {
        function a(a) {
            return function() {
                var e = d.getStrings()[a];
                if (e) return e;
                c.logDebug("turbo-checkout-strings", 'String for key "' + a + '" is undefined! Returning empty string.');
                return ""
            }
        }
        return {
            getHeaderText: a("TURBO_CHECKOUT_HEADER"),
            getLoadingText: a("TURBO_LOADING_TEXT")
        }
    });
    "use strict";
    e.when("jQuery", "turbo-checkout-page-ready").register("turbo-checkout-loading-spinner",
        function(c) {
            function d() {
                return c("#turbo-loading-container")
            }

            function a(a) {
                var d = c("\x3cdiv\x3e", {
                    id: "turbo-loading-content"
                }).append(c("\x3cdiv\x3e", {
                    id: "turbo-loading-spinner",
                    "class": "a-spinner a-spinner-medium"
                }));
                "string" === typeof a && a && d.append(c("\x3cdiv\x3e", {
                    id: "turbo-loading-text",
                    text: a
                }));
                return d
            }
            return {
                create: function(b) {
                    return c("\x3cdiv\x3e", {
                        id: "turbo-loading-container"
                    }).append(a(b))
                },
                get: d,
                show: function() {
                    d().addClass("turbo-checkout-shown")
                }
            }
        });
    "use strict";
    e.when("A", "turbo-checkout-utils",
        "turbo-checkout-page-ready").register("turbo-checkout-eligibility-response-weblabs", function(c, d) {
        var a = [];
        return {
            set: function(b) {
                c.$.isArray(b) && (a = b)
            },
            get: function() {
                return a
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-csm", "turbo-checkout-utils", "turbo-checkout-page-ready").register("turbo-checkout-session-storage", function(c, d) {
        function a(a, c) {
            d.logDebug("turbo-checkout-session-storage", a, c)
        }
        return {
            isPresent: function(b) {
                var d;
                a: {
                    try {
                        d = m.sessionStorage.getItem(b);
                        break a
                    } catch (e) {
                        c.logCount("turboCheckoutSessionStorageExceptionGet"),
                            a("get() exception", e)
                    }
                    d = null
                }
                return null !== d && d !== C
            },
            set: function(b, d) {
                try {
                    m.sessionStorage.setItem(b, d)
                } catch (e) {
                    c.logCount("turboCheckoutSessionStorageExceptionSet"), a("set() exception", e)
                }
            },
            remove: function(b) {
                try {
                    return m.sessionStorage.removeItem(b)
                } catch (d) {
                    c.logCount("turboCheckoutSessionStorageExceptionRemove"), a("remove() exception", d)
                }
            }
        }
    });
    "use strict";
    e.when("turbo-checkout-page-ready").execute(function() {
        e.declare("turbo-checkout-is-physical-gift-card-support-enabled", !0)
    });
    "use strict";
    e.when("A", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-load-events", function(c, d) {
        var a = d.get(d.KEYS.TWISTER_PAGE_UPDATE_AUI_EVENT);
        return {
            bind: function(b) {
                c.off(a, b);
                c.off("turbo:checkout:controller:onPageLoaded", b);
                c.on(a, b);
                c.on("turbo:checkout:controller:onPageLoaded", b)
            }
        }
    })
});
/* ******** */
(function(d) {
    var k = window.AmazonUIPageJS || window.P,
        l = k._namespace || k.attributeErrors,
        b = l ? l("TurboCheckoutSharedMobileAssets", "") : k;
    b.guardFatal ? b.guardFatal(d)(b, window) : b.execute(function() {
        d(b, window)
    })
})(function(d, k, l) {
    d.when("A", "turbo-checkout-page-ready").register("turbo-checkout-scroll-stopper", function(b) {
        function c(b) {
            b.preventDefault()
        }

        function a(b, a) {
            b = a.$;
            1 === b("#turbo-checkout-select-form").length ? f(b) : b("#checkout-page-container").bind("touchmove", c)
        }

        function f(b) {
            var a = b("#turbo-checkout-select-form");
            a.bind("touchstart", function(b) {
                b = a[0].scrollHeight;
                var c = a.height(),
                    f = b - c;
                b > c && (0 >= a.scrollTop() && a.scrollTop(1), a.scrollTop() >= f && a.scrollTop(a.scrollTop() - 1))
            });
            b("#checkout-page-container").bind("touchmove", function(a) {
                var c = b("#turbo-checkout-select-form"),
                    f = c[0].scrollHeight,
                    r = c.height(),
                    d = f - r,
                    d = 0 < c.scrollTop() && c.scrollTop() < d,
                    f = f > r && d;
                0 !== c.has(a.target).length && f || a.preventDefault()
            })
        }
        var r;
        b.on("turbo:checkout:embedded:page:ready", a);
        b.on("turbo:checkout:embedded:page:beforeReload", a);
        return {
            disablePageScrolling: function(a) {
                a =
                    b.$;
                r = a(document.body).css("overflow");
                a(document.body).css("overflow", "hidden")
            },
            restoreScrolling: function(a) {
                a = b.$;
                a(document.body).css("overflow", r)
            }
        }
    });
    "use strict";
    d.when("A", "turbo-callback-list", "turbo-checkout-page-ready").register("turbo-checkout-orientation-listener", function(b, c) {
        function a() {
            b.on("orientationchange", function() {
                f()
            })
        }

        function f() {
            var a = d();
            b.trigger("turbo:checkout:orientation:onChange", {
                orientation: a
            });
            l.callAll(a)
        }

        function d() {
            return k("html").hasClass("a-ws") ? "landscape" :
                "portrait"
        }
        var k = b.$,
            l = c.create();
        return {
            startListening: function() {
                a();
                f()
            },
            registerCallback: l.push,
            getOrientation: d
        }
    });
    "use strict";
    d.when("A", "turbo-checkout-iframe", "turbo-checkout-view-state", "turbo-checkout-base-view", "turbo-checkout-scroll-stopper", "turbo-checkout-history-manager", "turbo-checkout-utils", "turbo-checkout-mash-integration-adapter", "turbo-checkout-ref-tagger", "turbo-checkout-device-filter", "turbo-checkout-strings", "turbo-checkout-loading-spinner", "turbo-configuration", "turbo-checkout-page-ready").register("turbo-checkout-bottom-sheet",
        function(b, c, a, f, d, z, A, t, B, C, L, p, D) {
            function E() {
                a.setToOpening("turbo:checkout:sheet:beforeOpen");
                t.dispatchEvent({
                    type: "appOverlays.Hide"
                });
                u();
                F();
                M()
            }

            function u() {
                e || N();
                c.remove();
                e.html(p.create(L.getLoadingText()))
            }

            function N() {
                e = g("\x3cdiv/\x3e", {
                    id: "turbo-checkout-bottom-sheet"
                });
                h = g("\x3cdiv/\x3e", {
                    id: "turbo-checkout-bottom-sheet-dimmer"
                });
                n = g("\x3cspan/\x3e", {
                    id: "turbo-checkout-bottom-sheet-dimmer-close"
                });
                h.append(n);
                g(document.body).append(e);
                g(document.body).append(h);
                h.bind("touchmove",
                    function() {
                        return !1
                    })
            }

            function F() {
                v && (u(), p.show(), c.appendTo(e), d.disablePageScrolling(h), c.write(v))
            }

            function M() {
                var a = O();
                x = document.body.scrollTop;
                y = g(document.body).css("top");
                document.body.scrollTop !== a && g(document.body).animate({
                    scrollTop: a
                }, 400, function() {
                    var b = -1 * a;
                    g(document.body).css({
                        top: b
                    })
                });
                w(e, P);
                e.addClass("turbo-checkout-bottom-sheet-visible").css({
                    bottom: 0
                });
                h.css({
                    width: "100%"
                }).addClass("turbo-checkout-bottom-sheet-dimmer-visible");
                z.sheetOpened()
            }

            function P() {
                a.setToOpen();
                h.bind("click", G);
                n.bind("click", H);
                g(document.body).addClass("turbo-checkout-fix-body");
                p.show();
                "function" === typeof C.isAtleast_iOS_10_3 && C.isAtleast_iOS_10_3() && g(e).hide().show(0)
            }

            function O() {
                var a = g(Q),
                    b;
                1 === a.length && (b = a.offset().top);
                if (!b || 1 > b) b = 1;
                return b
            }

            function m(q) {
                function c() {
                    a.setToClosed(p);
                    g(document.body).removeClass("turbo-checkout-fix-body");
                    u()
                }
                var f = q && q.immediate,
                    k = q === l || q.notify === l || q.notify,
                    m = k && "turbo:checkout:sheet:beforeClose",
                    p = k && "turbo:checkout:sheet:afterClose";
                a.isOpeningOrOpen() && (n.css("margin-bottom", ""), e.css("height", ""), n.css("bottom", ""), a.setToClosing(m, q), t.dispatchEvent({
                        type: "appOverlays.Show"
                    }), document.body.scrollTop !== x && g(document.body).animate({
                        scrollTop: x
                    }, f ? 0 : 400, function() {
                        if (y !== l) {
                            var b = y;
                            g(document.body).css({
                                top: b
                            })
                        }
                    }), f && (e.addClass("turbo-checkout-no-animation"), h.addClass("turbo-checkout-no-animation"), b.defer(function() {
                        e.removeClass("turbo-checkout-no-animation");
                        h.removeClass("turbo-checkout-no-animation")
                    })), e.removeClass("turbo-checkout-bottom-sheet-visible"),
                    h.removeClass("turbo-checkout-bottom-sheet-dimmer-visible"), h.unbind("click", G), n.unbind("click", H), d.restoreScrolling(h), z.sheetClosed(), w(e, c))
            }

            function I(a) {
                var c = A.isAndroid();
                c && e.addClass("turbo-checkout-bottom-sheet-fullscreen");
                w(e, function(f) {
                    m({
                        notify: !1,
                        immediate: !0,
                        doNotLog: !0
                    });
                    c && e.removeClass("turbo-checkout-bottom-sheet-fullscreen");
                    b.trigger("turbo:checkout:sheet:onNavigateAway");
                    a()
                })
            }

            function R(a) {
                m({
                    notify: !1,
                    doNotLog: !0
                });
                w(e, function(c) {
                    b.trigger("turbo:checkout:sheet:onNavigateAway");
                    a()
                })
            }

            function w(a, b) {
                a = J(a.css("transition-duration")) + J(a.css("transition-delay"));
                setTimeout(b, a)
            }

            function J(a) {
                var b = 0;
                a && (b = /ms$/.test(a) ? parseFloat(a) : 1E3 * parseFloat(a));
                return b
            }

            function G() {
                m({
                    reason: B.TAGS.TOUCH
                })
            }

            function H() {
                m({
                    reason: B.TAGS.TOUCH_X
                })
            }
            var Q = D.get(D.KEYS.BACKGROUND_SCROLL_TARGET_SELECTOR),
                g = b.$,
                v, e, h, n, x, y, K = new(f.extend())("#turbo-checkout-bottom-sheet");
            (function() {
                A.isIPhone() && k.addEventListener("message", function(a) {
                    if (/.*\.amazon\.com/.test(a.origin)) {
                        if ("turbo:checkout:virtualkeyboard:opened" ===
                            a.data) {
                            var b = e[0].getBoundingClientRect().bottom;
                            e.css({
                                bottom: -1 * (k.innerHeight - b)
                            })
                        }
                        "turbo:checkout:virtualkeyboard:closed" === a.data && e.css({
                            bottom: 0
                        })
                    }
                })
            })();
            K.pushBoundsAdjustedCallback(function(a) {
                n.css("bottom", a)
            });
            c.onContentLoaded(function(a) {
                p.get().remove()
            });
            b.on("turbo:checkout:sheet:doOpen", E);
            b.on("turbo:checkout:sheet:doClose", m);
            return {
                show: E,
                setContent: function(b) {
                    v = b;
                    a.isOpeningOrOpen() && !c.hasContent() && F()
                },
                removeContent: function() {
                    v = null;
                    u()
                },
                close: m,
                closeToFullscreen: function(a) {
                    I(function() {
                        t.modalOpen(a)
                    })
                },
                closeImmediatelyThenExecute: I,
                closeAndNavigate: function(a) {
                    R(function() {
                        t.navigate(a)
                    })
                },
                registerCallbacks: function(a) {
                    c.registerCallbacks(a)
                },
                updateBounds: function(a) {
                    K.updateBounds(a)
                }
            }
        });
    "use strict";
    d.when("turbo-base-eligible-state", "turbo-checkout-ref-tagger", "turbo-checkout-orientation-listener").register("turbo-checkout-eligible-state", function(b, c, a) {
        function f(b) {
            "portrait" !== a.getOrientation() && b.invalidate("Landscape orientation")
        }

        function d() {
            b.onStateChange(c.TAGS.ROTATION)
        }
        return {
            canShow: b.canShow,
            registerStateChangeCallback: b.registerStateChangeCallback,
            setup: function() {
                b.setup();
                b.addStateCheck(f);
                a.registerCallback(d);
                a.startListening()
            }
        }
    });
    "use strict";
    d.when("turbo-configuration-keys", "turbo-device-configuration", "turbo-function-adapter", "turbo-checkout-page-ready").execute("turbo-mash-integration-adapter-factory", function(b, c, a) {
        d.when(c[b.MASH_ADAPTER]).register("turbo-checkout-mash-integration-adapter", function(b) {
            return {
                dispatchEvent: a.adapt(b.dispatchEvent),
                modalOpen: a.adapt(b.modalOpen),
                navigate: a.adapt(b.navigate),
                showLoginDialog: a.adapt(b.showLoginDialog),
                show: a.adapt(b.show)
            }
        })
    })
});
/* ******** */
(function(b) {
    var d = window.AmazonUIPageJS || window.P,
        e = d._namespace || d.attributeErrors,
        a = e ? e("TurboCheckoutMobileWebAssets", "") : d;
    a.guardFatal ? a.guardFatal(b)(a, window) : a.execute(function() {
        b(a, window)
    })
})(function(b, d, e) {
    b.when("turbo-checkout-page-ready").execute(function() {
        b.declare("turbo-device-override", "Browser-SmartPhone")
    });
    "use strict";
    b.when("turbo-configuration-keys", "turbo-device-override", "turbo-interstitial-suppression", "turbo-checkout-page-ready").register("turbo-device-configuration",
        function(a, b, d) {
            var c;
            c || (c = {}, c[a.IS_DEVICE_FILTER_REQUIRED] = !1, c[a.USES_MASH_WILL_REAPPEAR] = !1, c[a.SHOW_SIGN_IN_INTERFACE] = "turbo-checkout-browser-signin", c[a.IFRAME_ID] = "turbo-checkout-bottom-sheet-frame", c[a.EXTEND_ELIGIBLE_STATE] = !0, c[a.VIEW_ADAPTER] = "turbo-checkout-bottom-sheet", c[a.DEVICE_OVERRIDE] = b, c[a.MASH_ADAPTER] = "turbo-checkout-mash-facade", d && (c[a.CONFLICTING_INITIATE_LISTENERS] = ["click"]));
            return c
        });
    "use strict";
    b.when("turbo-checkout-page-ready").register("turbo-checkout-mash-facade",
        function() {
            function a(a) {
                d.location.href = a
            }

            function b() {
                throw "Unsupported method. Interface exists to preserve legacy interface.";
            }
            return {
                navigate: a,
                modalOpen: a,
                dispatchEvent: function() {},
                showLoginDialog: b,
                show: b
            }
        })
});
/* ******** */
(function(c) {
    var d = window.AmazonUIPageJS || window.P,
        e = d._namespace || d.attributeErrors,
        a = e ? e("DetailPageTurboCheckoutMobileWebAssets", "") : d;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, d, e) {
    c.when("turbo-configuration-keys", "turbo-checkout-page-ready").register("turbo-client-configuration", function(a) {
        var b;
        b || (b = {}, b[a.HOST_PAGE_TYPE_IDENTIFIER] = "detail", b[a.PREFETCH_TREATMENT] = "T1", b[a.NO_PREFETCH_TREATMENT] = "T2", b[a.BUY_NOW_ONLY_TREATMENT] = "T3", b[a.QUANTITY_SELECT_SELECTOR] =
            "#mobileQuantityDropDown");
        return b
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("DetailPageVoltageComplianceAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */
(function(a) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        c = d ? d("DetailPageAToZGuaranteeAssets", "") : b;
    c.guardFatal ? c.guardFatal(a)(c, window) : c.execute(function() {
        a(c, window)
    })
})(function(a, b, d) {
    a.when("A").register("atoz-csm-counters", function(c) {
        var a = function(a) {
                return ue.count(a) || 0
            },
            b = function(a, b) {
                ue.count(a, b)
            };
        return {
            getCounter: a,
            setCounter: b,
            incrementCounter: function(c, d) {
                d = d || 1;
                b(c, a(c) + d)
            }
        }
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        f = b._namespace || b.attributeErrors,
        a = f ? f("DetailPageSellerProfileMobileAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, f) {
    c.when().register("seller-profile-treatment", function() {
        return "C"
    });
    "use strict";
    c.when("jQuery", "a-sheet", "seller-profile-treatment", "A", "a-spinner", "ready").register("seller-register-bottomsheet", function(a, c, d, f, k) {
        return function() {
            function l(a) {
                a.preventDefault();
                b.ue &&
                    ue.trigger && ue.trigger("NPX_196501", d);
                "C" === d && b.location.assign(g)
            }
            var e = a("#sellerProfileTriggerId"),
                g = e.attr("href");
            if (e.length && (e.click(l), "T1" === d)) {
                var h = function(a) {
                        b.ue && b.ue.trigger && b.ue.count && (ue.trigger("NPX_196501", d), b.ue.count(a, 1));
                        b.location.assign(g)
                    },
                    m = c.create({
                        preloadDomId: "seller-profile-bottom-sheet",
                        height: 150,
                        closeType: "icon"
                    });
                e.click(function() {
                    var b = k("#seller-profile-spinner"),
                        c = a("#seller-profile-bottom-sheet");
                    if (c.data("asin") && c.data("merchant-id")) {
                        var d;
                        d = "/gp/product/du/mbc-seller-information.html?isUDP\x3d1\x26sp\x3d1\x26c\x3dall\x26a\x3d" +
                            c.data("asin");
                        d += "\x26me\x3d" + c.data("merchant-id");
                        var e = a("#seller-profile-bottom-sheet-body");
                        e.empty();
                        b.show();
                        m.show();
                        f.ajax(d, {
                            method: "get",
                            success: function(a) {
                                e.html(a);
                                b.hide()
                            },
                            error: function() {
                                h("NPX:SellerProfile:Mobile:AjaxError")
                            }
                        })
                    } else h("NPX:SellerProfile:Mobile:UrlParamError")
                })
            }
        }
    })
});
/* ******** */
(function(f) {
    var g = window.AmazonUIPageJS || window.P,
        h = g._namespace || g.attributeErrors,
        b = h ? h("DetailPageFluxComponents", "") : g;
    b.guardFatal ? b.guardFatal(f)(b, window) : b.execute(function() {
        f(b, window)
    })
})(function(f, g, h) {
    f.when("dp-flux-utils").register("dp-flux-action", function(b) {
        function e(d, a, c) {
            if (b.isNonEmptyString(d) && b.isNonEmptyString(a)) this._name = d, this._source = a, this._metadata = c;
            else throw Error("Action(...): Action must be created with valid name and source");
        }
        e.prototype = {
            getName: function() {
                return this._name
            },
            getSource: function() {
                return this._source
            },
            getMetaData: function() {
                return this._metadata
            }
        };
        return e.prototype.constructor = e
    });
    f.when("dp-flux-utils").register("dp-flux-attribution", function(b) {
        function e(d, a, c, k) {
            if (b.isNonEmptyString(d) && b.isNonEmptyString(a) && b.isNonEmptyString(c) && b.isNonEmptyString(k)) this._name = d, this._category = a, this._type = c, this._item = k;
            else throw Error("All parameters (name, categoty, type, item) must be a non-empty string");
        }
        e.prototype = {
            getName: function() {
                return this._name
            },
            getAttribution: function() {
                return "name: " + this._name + "; CTI\x3d " + this._category + "/" + this._type + "/" + this._item
            }
        };
        return e.prototype.constructor = e
    });
    f.when("A", "dp-flux-action", "dp-flux-attribution").register("dp-flux-dispatcher", function(b, e, d) {
        function a() {
            this._callbacks = {};
            this._isDispatching = !1;
            this._pendingAction = null;
            this._lastID = 1
        }
        var c = b.$;
        a.prototype = {
            register: function(a, b) {
                if (!(a instanceof d)) throw Error("Dispatch.register(...): attribution must be instance of Attribution");
                if (!c.isFunction(b)) throw Error("Dispatch.register(...): callback must be a function");
                var e = "ID_" + this._lastID++;
                this._callbacks[e] = {
                    attribution: a,
                    callback: b,
                    _isCallbackExecutionStarted: !1,
                    _isCallbackExecutionCompleted: !1
                };
                return e
            },
            unregister: function(a) {
                if (this._callbacks[a]) delete this._callbacks[a];
                else throw Error("Dispatcher.unregister(...): " + a + " does not map to a registered callback");
            },
            dispatch: function(a) {
                if (this._isDispatching) throw Error("Dispatch.dispatch(...): Cannot dispatch in the middle of a dispatch");
                if (!(a instanceof e)) throw Error("Dispatch.dispatch(...): action param must be of type Action");
                this._startDispatching(a);
                for (var c in this._callbacks) this._callbacks[c]._isCallbackExecutionStarted || this._invokeCallback(c);
                this._stopDispatching()
            },
            waitFor: function(a) {
                if (!this._isDispatching) throw Error("Dispatcher.waitFor(...): Must be invoked while dispatching");
                if (!c.isArray(a)) throw Error("Dispatcher.waitFor(...): dispatchTokenList must be an array");
                for (var b = 0; b < a.length; b++) {
                    var d = a[b];
                    if (!this._callbacks[d]) throw Error("Dispatcher.waitFor(...): " + d + " does not map to a registered callback. ");
                    if (this._callbacks[d]._isCallbackExecutionStarted)
                        if (this._callbacks[d]._isCallbackExecutionCompleted) continue;
                        else throw Error("Dispatcher.waitFor(...): Circular dependency detected while waiting for " + d);
                    this._invokeCallback(d)
                }
            },
            _invokeCallback: function(a) {
                this._callbacks[a]._isCallbackExecutionStarted = !0;
                try {
                    this._callbacks[a].callback(this._pendingAction)
                } catch (c) {
                    f.log("Dispatcher._invokeCallback(...): Error while calling dispatcher callback: error message \x3d " + c.message, "FATAL", this._callbacks[a].attribution.getAttribution())
                }
                this._callbacks[a]._isCallbackExecutionCompleted = !0
            },
            _startDispatching: function(a) {
                for (var c in this._callbacks) this._callbacks[c]._isCallbackExecutionStarted = !1, this._callbacks[c]._isCallbackExecutionCompleted = !1;
                this._pendingAction = a;
                this._isDispatching = !0
            },
            _stopDispatching: function() {
                this._pendingAction = null;
                this._isDispatching = !1
            }
        };
        return a.prototype.constructor = a
    });
    f.when("A", "dp-flux-utils").register("dp-flux-emitter", function(b, e) {
        function d() {
            this._subscriptions = {}
        }
        var a = b.$;
        d.prototype = {
            emit: function(a) {
                if (e.isNonEmptyString(a)) b.each(this._subscriptions[a] || [], function(a) {
                    a()
                });
                else throw Error("Emitter.emit()...: eventType must be a non empty string");
            },
            addListener: function(c, b) {
                if (e.isNonEmptyString(c) && a.isFunction(b)) this._subscriptions[c] = this._subscriptions[c] || [], this._subscriptions[c].push(b);
                else throw Error("Emitter.addListener()...: Invalid arguments - eventType must be a non empty string \x26 callback must be a function ");
            },
            removeListener: function(c, b) {
                if (e.isNonEmptyString(c) && a.isFunction(b)) {
                    if (c = this._subscriptions[c]) b = a.inArray(b,
                        c), -1 !== b && c.splice(b, 1)
                } else throw Error("Emitter.removeListener()...: Invalid arguments - eventType must be a non empty string \x26 callback must be a function");
            }
        };
        return d
    });
    f.when("A", "dp-flux-emitter", "dp-flux-attribution", "dp-flux-dispatcher", "dp-flux-utils").register("dp-flux-store", function(b, e, d, a, c) {
        function f(b, k, g, h) {
            if (!(b instanceof d)) throw Error("storeAttribution should be instance of Attribution");
            if (!(g instanceof a)) throw Error("dispatcher must be an instance of Dispatcher");
            if (!l.isFunction(k)) throw Error("Store must provide a reduce callback method");
            this.reduce = k;
            this.dispatcher = g;
            this._storeAttribution = b;
            this._state = h || {};
            c.deepFreeze(this._state);
            this._dispatchToken = this.dispatcher.register(this._storeAttribution, this._invokeOnDispatch.bind(this));
            this._changed = !1;
            this._changeEvent = this._storeAttribution.getName() + ":change";
            this._emitter = new e
        }
        var l = b.$;
        f.prototype = {
            addListener: function(a) {
                return this._emitter.addListener(this._changeEvent, a)
            },
            removeListener: function(a) {
                this._emitter.removeListener(this._changeEvent, a)
            },
            getDispatcher: function() {
                return this.dispatcher
            },
            getDispatchToken: function() {
                return this._dispatchToken
            },
            getState: function() {
                return this._state
            },
            getStoreAttribution: function() {
                return this._storeAttribution
            },
            _invokeOnDispatch: function(a) {
                this._changed = !1;
                var b = this._state;
                (a = this.reduce(this._state, a) || b) && a !== b && (this._state = a, c.deepFreeze(this._state), this._changed = !0, this._emitter.emit(this._changeEvent))
            }
        };
        return f.prototype.constructor = f
    });
    f.when("A", "dp-flux-attribution").register("dp-flux-store-group", function(b) {
        function e(b, a, c) {
            this._stores =
                a;
            this._callBack = c;
            this._attribution = b;
            this._registerStoreGroup()
        }
        e.prototype = {
            _registerStoreGroup: function() {
                var b = this._getUniformDispatcher();
                this._dispatchToken = b.register(this._attribution, function() {
                    b.waitFor(this._getStoreTokens());
                    this._callBack()
                }.bind(this))
            },
            unregisterStoreGroup: function() {
                this._getUniformDispatcher().unregister(this._dispatchToken)
            },
            _getUniformDispatcher: function() {
                var d = this._stores[0].getDispatcher();
                b.each(this._stores, function(a) {
                    if (d !== a.getDispatcher()) throw Error("All stores must have common dispatcher");
                });
                return d
            },
            _getStoreTokens: function() {
                return b.map(this._stores, function(b) {
                    return b.getDispatchToken()
                })
            }
        };
        return e.prototype.constructor = e
    });
    f.when("A", "dp-flux-store-group").register("dp-flux-store-subscription", function(b, e) {
        function d(a, b, d) {
            this._stores = b;
            this._changed = !1;
            this._updatedStores = [];
            this._viewUpdateCallBack = d;
            this._viewAttribution = a;
            this._allListeners = [];
            this._addListenerToAllStores();
            this._storeGroup = new e(a, b, this._viewCallBack.bind(this))
        }
        d.prototype = {
            _storeListener: function(a) {
                this._changed = !0;
                this._updatedStores.push(a)
            },
            _addListenerToAllStores: function() {
                var a;
                b.each(this._stores, function(b) {
                    a = this._storeListener.bind(this, b);
                    this._allListeners.push({
                        listener: a,
                        store: b
                    });
                    b.addListener(a)
                }, this)
            },
            _removeListenerFromAllStores: function() {
                b.each(this._allListeners, function(a) {
                    a.store.removeListener(a.listener)
                })
            },
            _viewCallBack: function() {
                if (this._changed) {
                    try {
                        this._viewUpdateCallBack(this._updatedStores)
                    } catch (a) {
                        f.log("StoreSubscription._viewCallBack(...): view callback failed", "FATAL",
                            this._viewAttribution.getAttribution())
                    }
                    this._changed = !1;
                    this._updatedStores = []
                }
            },
            reset: function() {
                this._removeListenerFromAllStores();
                this._storeGroup.unregisterStoreGroup()
            }
        };
        return d.prototype.constructor = d
    });
    f.when("A").register("dp-flux-utils", function(b) {
        function e(a) {
            return "string" === typeof a || "[object String]" === Object.prototype.toString.call(a)
        }

        function d(a) {
            if (!Object.isFrozen(a)) {
                var c = Object.getOwnPropertyNames(a);
                b.each(c, function(b) {
                    var c = a[b];
                    a[b] = c && "object" === typeof c ? d(c) : c
                });
                Object.freeze(a)
            }
            return a
        }
        return {
            isString: e,
            isNonEmptyString: function(a) {
                return !(!e(a) || !b.trim(a).length)
            },
            deepFreeze: function(a) {
                return Object.freeze && Object.getOwnPropertyNames && Object.isFrozen ? (d(a), !0) : !1
            }
        }
    });
    f.when("A", "dp-flux-attribution", "dp-flux-store", "dp-flux-store-subscription").register("dp-flux-view", function(b, e, d, a) {
        function c(c, g, h) {
            if (!(c instanceof e)) throw Error("View(...): viewAttribution should be an instance of Attribution");
            if (f.isArray(g) && 1 <= g.length) b.each(g, function(a) {
                if (!(a instanceof d)) throw Error("View(...): storeList contains an object which is not of type Store");
            });
            else throw Error("View(...): View must listen on at least one store");
            if (!f.isFunction(h)) throw Error("View(...): View must provide update callback method");
            this._viewAttribution = c;
            this._storeSubscription = new a(c, g, h)
        }
        var f = b.$;
        c.prototype.getViewAttribution = function() {
            return this._viewAttribution
        };
        c.prototype.unregisterStores = function() {
            this._storeSubscription.reset()
        };
        return c
    })
});
/* ******** */
(function(e) {
    var n = window.AmazonUIPageJS || window.P,
        B = n._namespace || n.attributeErrors,
        C = B ? B("DetailPageUSSAssets", "") : n;
    C.guardFatal ? C.guardFatal(e)(C, window) : C.execute(function() {
        e(C, window)
    })
})(function(e, n, B) {
    e.when("A").register("uss-constants-common", function(e) {
        return {
            classList: {
                SHOW_ELEMENT: "aok-block",
                HIDE_ELEMENT: "aok-hidden",
                STOP_SCROLLING: "uss-u-no-scroll",
                LIGHT_BOX_JS_HOOK: "js-light-box",
                LIGHT_BOX_IDENTIFIER: "uss-o-light-box",
                RIGHT_SIDE_SHEET: "uss-o-right-side-sheet",
                RIGHT_SIDE_SHEET_LAYOUT: "uss-l-right-side-sheet",
                SHEET_OPEN: "is-open",
                SHEET_CLOSE: "is-close",
                USS_SHEET_VIEW_IDENTIFIER: "uss-sheet-view",
                CLOSE_ICON: "uss-o-close-icon",
                CLOSE_ICON_MEDIUM: "uss-o-close-icon-medium",
                USS_SHEET_VIEW_CLOSE_ICON: "uss-sheet-view-close-icon",
                PROMISING_UI_ELEMENT: "uss-o-promising-ui-element",
                PROMISING_UI_ELEMENT_ANIMATION: "uss-o-promising-ui-element-animation",
                IS_LOADING: "is-loading",
                IS_RESOLVED: "is-resolved",
                UI_PROMISE: "ui-promise",
                UI_VALUE: "ui-value",
                TEMPLATE_STORE: "uss-template-store",
                TEMPLATE: "uss-template",
                TEMPLATE_NAME: "template-name",
                ATC_ACKNOWLEDGEMENT_MESSAGE: "atc-acknowledgement-message",
                ATC_GENERIC_ERROR: "atc-generic-error",
                ATC_STATUS_MESSAGE_COMPONENT: "uss-c-atc-status-msg",
                ATC_SUCCESS: "atc-success",
                ATC_ERROR: "atc-error",
                ITEM_IN_CART: "item-in-cart",
                CART_STATUS_MESSAGE_COMPONENT: "uss-c-cart-status-msg",
                CART_SUB_TOTAL: "cart-sub-total",
                CART_COUNT: "cart-count",
                SHIPPING_DETAILS: "uss-c-shipping-details",
                SHIPPING_MESSAGE_PLACEHOLDER: "shipping-message-placeholder",
                MAIN_IMAGE: "main-image",
                SUB_NAV: "uss-c-sub-nav",
                CHECKOUT_BUTTON: "checkout-btn",
                CART_BUTTON: "cart-btn",
                CHECKOUT_FORM: "checkout-form",
                FACEOUT_IMAGE: "p13n-sc-dynamic-image",
                FACEOUT_TITLE: "uss-asin-title",
                FACEOUT_REVIEW_STARS: "uss-review-stars",
                FACEOUT_BEST_SELLER: "p13n-best-seller",
                FACEOUT_PRICE: "uss-price",
                CONTINUE_SHOPPING_LINK: "continue-shopping",
                SUCCESS_ELEMENT: ".p13n-sc-atc-success",
                ERROR_ELEMENT: ".p13n-sc-atc-error",
                BUTTON_ELEMENT: ".a-button-primary",
                DISABLE_BUTTON: "a-button-disabled"
            },
            fatalMessagesList: {
                INVALID_SHEET_ID: "sheetID must be valid string",
                INVALID_CONSTRUCTOR_USAGE: "Constructor needs to be called with 'new' keyword",
                INCORRECT_PARAMETER_PASSED: "Incorrect parameter passed."
            },
            widgetType: {
                WIDGET: "uss-widget",
                RECOMMENDATION_WIDGET: "uss-recommendation-widget",
                NO_RECOMMENDATION_WIDGET: "uss-no-recommendation-widget",
                LIST_RECOMMENDATION: "uss-list-recommendation-widget",
                CAROUSEL_RECOMMENDATION: "uss-carousel-recommendation-widget",
                PRIMARY_ACTION_STATUS_WIDGET: "uss-primary-action-status-widget",
                ATCStatusWidget: "uss-c-atc-status-widget",
                ATC_STATUS_IMB_WIDGET: "atc-status-imb-widget",
                MAPLE_WIDGET: "maple-recommendation-widget"
            },
            layout: {
                defaultLayout: {
                    DEFAULT_LAYOUT: "uss-l-default-layout",
                    HEAD: "uss-c-head",
                    BODY: "uss-c-body",
                    HEAD_DIVIDER: "uss-c-head-divider",
                    BOTTOM_MARGIN_BETWEEN_WIDGETS: "a-spacing-medium",
                    TOP_MARGIN_BETWEEN_WIDGETS: "a-spacing-top-medium",
                    SKELETON_LOADER: "uss-loading-skeleton",
                    RECOMMENDATION_LOADING_MESSAGE: "loading-message",
                    RECOMMENDATION_LOADED_MESSAGE: "uss-recommendations-loaded-message"
                }
            },
            actionSources: {
                DP_ATC_CLICK: "dp-atc-click",
                USS_INGRESS_CLICK: "uss-ingress-click",
                USS_INLINE_ATC_CLICK: "uss-inline-atc-click",
                SHEET_CLOSE_BUTTON_CLICK: "sheet-close",
                CONTINUE_SHOPPING_CLICK: "continue-shopping-click"
            },
            stores: {
                ATC_STATUS_STORE: "uss-atc-status-store",
                RECOMMENDATION_DATA_STORE: "uss-recommendation-data-store",
                USS_SHEET_STORE: "uss-sheet-store"
            },
            actions: {
                USS_OPEN: "uss-open",
                USS_CLOSE: "uss-close",
                RECOMMENDATION_DATA_RECEIVE: "recommendation-data-receive",
                ATC_RECEIVE: "atc-receive"
            },
            metrics: {
                ATC_PROMISE_RESOLVED_TIMER: "atcPromiseResolve",
                PERCOLATE_DATA_PROMISE_RESOLVED_TIMER: "percolateDataPromiseResolve",
                ATC_PROMISE_REJECTED_COUNTER: "atcPromiseRejected",
                PERCOLATE_DATA_PROMISE_REJECTED_COUNTER: "percolateDataPromiseRejected",
                SECONDARY_ADD_TO_CART_CLICK_COUNTER: "secondaryAtcClick",
                COMPATIBLE_BROWSER_COUNTER: "compatibleBrowser",
                NON_COMPATIBLE_BROWSER_COUNTER: "nonCompatibleBrowser",
                FACEOUT_IMAGE_CLICK_COUNTER: "faceout:imageClick",
                FACEOUT_REVIEW_STARS_CLICK_COUNTER: "faceout:reviewStarClick",
                FACEOUT_TITLE_CLICK_COUNTER: "faceout:titleClick",
                FACEOUT_PRICE_CLICK_COUNTER: "faceout:priceClick",
                FACEOUT_BEST_SELLER_CLICK_COUNTER: "faceout:bestSellerClick",
                SEE_MORE_EXISTENCE_COUNTER: "ussListWidget:seeMore",
                SEE_MORE_CLICK_COUNTER: "ussListWidget:seeMoreClick",
                SEE_LESS_CLICK_COUNTER: "ussListWidget:seeLessClick",
                CHECKOUT_FORM_CLICK_COUNTER: "checkoutFormClick",
                CART_BUTTON_CLICK_COUNTER: "cartButtonClick",
                CONTINUE_SHOPPING_CLICK: "continueShoppingClick",
                PAGE_LANDING_PRECONDITIONS_PASSED: "pageLandingPreconditionsPassed",
                POST_ATC_PRECONDITIONS_FAILED: "postATCPreconditionsFailed"
            },
            transitionTimingFunction: {
                EVEN_EASE: "cubic-bezier(0.4, 0, 0.6, 1)",
                ENTER_EASE: "cubic-bezier(0, 0, 0.2, 1)",
                EXIT_EASE: "cubic-bezier(0.4, 0, 1, 1)",
                EASE_IN: "ease-in",
                EASE_OUT: "ease-out"
            },
            animationType: {
                FADE_IN: "fadeIn",
                NO_ANIMATION: "noAnimation"
            }
        }
    });
    e.when("A", "dp-flux-attribution", "uss-constants-common").register("uss-constants", function(e, n, m) {
        m.ussCTI = {
            CATEGORY: "Website",
            TYPE: "Personalization",
            ITEM: "Shared Components"
        };
        e = "true" === e.$("#uss-mobileApp").val();
        m.metrics.PREFIX = e ? "uss:mobileApp:" : "uss:mobile:";
        m.ajaxParams = {
            BASE_URL: "/gp/aw/cart/",
            REFTAG: "mw_dp_buy_crt",
            ASIN: "a",
            AJAX_TIMEOUT: 1E4
        };
        m.deviceOrientation = {
            ORIENTATION_LANDSCAPE: "landscape",
            ORIENTATION_PORTRAIT: "portrait"
        };
        m.actionSources.SHEET_CLOSE_BUTTON_CLICK = "sheet-close";
        m.actionSources.MASH_REAPPEAR = "mash-reappear";
        m.metrics.MASH_REAPPEAR = "mash-reappear";
        m.classList.FACEOUT_PRICE = "p13n-sc-price";
        m.classList.USS_C_HEAD_STICKY = "uss-c-head-sticky";
        m.ussCommonAttribution = new n("uss-common", m.ussCTI.CATEGORY, m.ussCTI.TYPE, m.ussCTI.ITEM);
        m.defaultAtcAnimationType = m.animationType.NO_ANIMATION;
        return m
    });
    e.when("dp-flux-utils", "uss-constants").register("uss-logger-service", function(e,
        n) {
        function m(a, d) {
            if (e.isNonEmptyString(a)) a = n.metrics.PREFIX + a, ue && ue.count && (void 0 === d && (d = (ue.count(a) || 0) + 1), ue.count(a, d));
            else throw Error("counterKey must be non empty string");
        }

        function A(a) {
            if (e.isNonEmptyString(a)) this._timerName = a, this._startTime = 0;
            else throw Error("timerName must be non empty string");
        }
        A.prototype = {
            start: function() {
                this._startTime = Date.now()
            },
            stop: function() {
                this._startTime && m(this._timerName, Date.now() - this._startTime)
            }
        };
        return {
            logCounter: m,
            Timer: A
        }
    });
    e.when("A", "uss-utils",
        "uss-logger-service", "uss-constants").register("uss-preconditions", function(e, n, m, A) {
        function a(a) {
            a = e.$("#" + a + "_feature_div").html();
            null !== a && (a = a.trim());
            return null !== a && 0 < a.length
        }

        function d() {
            return e.capabilities.transform && e.capabilities.transition && n.isFlexBoxSupported()
        }

        function f() {
            return d() && !a("scheduledDelivery") && !a("simpleBundle") && !a("partialStateBuyBox")
        }

        function b() {
            return e.$("#uss-weblabTreatment").val()
        }
        var k = /^T[0-9]+$/;
        d() ? m.logCounter(A.metrics.COMPATIBLE_BROWSER_COUNTER) :
            m.logCounter(A.metrics.NON_COMPATIBLE_BROWSER_COUNTER);
        return {
            isUssConditionsPassed: function() {
                return "true" === e.$("#uss-serverPreconditionsPassed").val() && f()
            },
            isUssConditionsPassedUssVsDss: function() {
                return "true" === e.$("#ussDss-enabled").val() && "true" === e.$("#ussDss-serverPreconditionsPassed").val() && f()
            },
            isUssWeblabInTreatment: function() {
                return k.test(b())
            },
            triggerUSSWeblabValue: function() {
                return k.test(e.$("#uss-miniFrameworkWeblabTreatment").val()) ? e.$("#uss-weblabValue").val() : 1
            },
            ussWeblabTreatmentValue: b,
            isBrowserUssCompatible: d
        }
    });
    e.when("A", "3p-promise", "uss-constants", "uss-logger-service").register("uss-utils", function(e, B, m, A) {
        var a = e.$,
            d = m.classList,
            f = a("body"),
            b = {},
            k = ["isPreview", "forceWidgets", "previewCampaigns", "auditEnabled"];
        (function() {
            var a = n.location.search,
                a = a.substr(1);
            a.split("\x26").forEach(function(c) {
                c = c.split("\x3d");
                2 === c.length && (b[c[0]] = c[1])
            })
        })();
        return {
            loadImage: function(b, c) {
                return new B(function(h, l) {
                    c = c || "";
                    var w = a("\x3cimg src\x3d'" + b + "' alt\x3d'" + c + "'\x3e");
                    w.load(function() {
                        h(w)
                    });
                    w.error(function(c) {
                        l(c)
                    });
                    w[0].complete && h(w)
                })
            },
            isFlexBoxSupported: function() {
                var a = e.$("\x3cdiv\x3e\x3c/div\x3e")[0];
                return "" === a.style.flex || "" === a.style.webkitFlex || "" === a.style.msFlex || "" === a.style.MozBoxFlex || "" === a.style.webkitBoxFlex ? !0 : !1
            },
            disablePageScroll: function() {
                f.addClass(d.STOP_SCROLLING)
            },
            enablePageScroll: function() {
                f.removeClass(d.STOP_SCROLLING)
            },
            isMobileApp: function() {
                return "true" === e.$("#uss-mobileApp").val()
            },
            getDebugParams: function() {
                var a = {};
                k.forEach(function(c) {
                    var h;
                    h =
                        null;
                    b.hasOwnProperty(c) && (h = b[c]);
                    h && (a[c] = h)
                });
                return a
            },
            shouldFireAndForgetWeblabTrigger: function() {
                var b = !1;
                0 != a("#uss-shouldFireAndForgetWeblabTrigger").length && (b = "true" === a("#uss-shouldFireAndForgetWeblabTrigger").val());
                return b
            },
            fireAndForgetWeblabTrigger: function(a, c) {
                var h = "/gp/uss/weblab-trigger.html?",
                    h = /^T[0-9]+$/.test(e.$("#uss-miniFrameworkWeblabTreatment").val()) ? h + ("weblabValue\x3d" + a + "\x26treatment\x3d" + c) : h + ("triggerWeblab\x3d" + a + "\x26treatment\x3d" + c);
                n.navigator && navigator.sendBeacon ?
                    navigator.sendBeacon(h) || e.$.ajax({
                        url: h
                    }) : e.$.ajax({
                        url: h
                    })
            }
        }
    });
    e.when("A", "atf", "uss-utils").register("uss-init-helper", function(n, B, m, A) {
        return {
            loadUssCommonAssets: function() {
                e.when("dp-flux-dispatcher").register("uss-dispatcher", function(a) {
                    return new a
                });
                e.when("A", "uss-constants").register("promising-ui-element", function(a, d) {
                    var f = d.classList;
                    return a.createClass({
                        _element: null,
                        _uiPromiseElement: null,
                        _uiValueElement: null,
                        _isResolved: !1,
                        init: function(a) {
                            var d = a.find("." + f.UI_PROMISE),
                                g = a.find("." +
                                    f.UI_VALUE);
                            if ((a.hasClass(f.PROMISING_UI_ELEMENT) || a.hasClass(f.PROMISING_UI_ELEMENT_ANIMATION)) && d.length && g.length) this._uiPromiseElement = d, this._uiValueElement = g, this._element = a, this.showUIPromise();
                            else throw Error("PromisingUIElement.init()...: HTML structure is not compatible with PromisingUIElement");
                        },
                        showUIPromise: function() {
                            this._element.addClass(f.IS_LOADING);
                            this._element.removeClass(f.IS_RESOLVED);
                            this._isResolved = !1
                        },
                        showUIValue: function() {
                            this._element.addClass(f.IS_RESOLVED);
                            this._element.removeClass(f.IS_LOADING);
                            this._isResolved = !0
                        },
                        getValueElement: function() {
                            return this._uiValueElement
                        },
                        getElement: function() {
                            return this._element
                        },
                        isResolved: function() {
                            return this._isResolved
                        }
                    })
                });
                e.when("A", "uss-sheet-component", "uss-constants", "uss-store-repository", "dp-flux-attribution", "uss-layout", "dp-flux-view", "widget-creation-helper", "dp-flux-action", "uss-dispatcher").register("uss-sheet-view", function(a, d, f, b, k, g, c, h, l, w) {
                    function v() {
                        y = !0;
                        var a = f.classList,
                            v = f.ussCTI,
                            p = b.getStore(f.stores.USS_SHEET_STORE),
                            q = b.getStore(f.stores.RECOMMENDATION_DATA_STORE),
                            t = [p, q],
                            v = new k("uss-sheet-view", v.CATEGORY, v.TYPE, v.ITEM),
                            r = new d(a.USS_SHEET_VIEW_IDENTIFIER, {
                                beforeClose: function() {
                                    w.dispatch(new l(f.actions.USS_CLOSE, f.actionSources.SHEET_CLOSE_BUTTON_CLICK))
                                }
                            }),
                            a = r.getSheetElement(),
                            z = new g(a);
                        new c(v, t, function(c) {
                            var a;
                            if (-1 !== e.inArray(p, c))
                                if (a = p.getState(), a.isSheetOpen()) {
                                    if (a.getActionSource() === f.actionSources.DP_ATC_CLICK) {
                                        z.reset();
                                        var l = h.createAtcStatusWidget();
                                        a = h.createIMBWidget(a.getActionSource());
                                        z.renderWidgets([l, a])
                                    }
                                    r.open()
                                } else a.getActionSource() !==
                                    f.actionSources.SHEET_CLOSE_BUTTON_CLICK && r.close(); - 1 !== e.inArray(q, c) && z.renderWidgets(h.createRecommendationWidget(q))
                        })
                    }
                    var e = a.$,
                        y = !1;
                    return {
                        initializeUSSSheetView: function() {
                            y || v()
                        }
                    }
                });
                e.when("A", "uss-constants", "uss-template-store", "uss-widget-factory").register("widget-creation-helper", function(a, d, f, b) {
                    return {
                        createAtcStatusWidget: function() {
                            var a = {
                                content: f.getTemplate(d.widgetType.ATCStatusWidget),
                                widgetType: d.widgetType.ATCStatusWidget
                            };
                            return b.getWidget(a)
                        },
                        createRecommendationWidget: function(d) {
                            var f,
                                c = [];
                            d = d.getState().getNewRecommendations();
                            a.each(d, function(a) {
                                (f = b.getWidget(a)) && c.push(f)
                            });
                            return c
                        },
                        createIMBWidget: function() {
                            return b.getWidget({
                                content: "\x3cdiv\x3e\x3c/div\x3e",
                                widgetType: d.widgetType.ATC_STATUS_IMB_WIDGET
                            })
                        }
                    }
                });
                e.when("A", "dp-flux-store", "uss-dispatcher").register("uss-store-repository", function(a, d, f) {
                    var b = {};
                    return {
                        registerStore: function(a, g, c) {
                            g = new d(a, g, f, c);
                            return b[a.getName()] = g
                        },
                        getStore: function(a) {
                            return b[a]
                        },
                        getDispatcher: function() {
                            return f
                        }
                    }
                });
                e.when("A",
                    "uss-store-repository", "dp-flux-attribution", "uss-sheet-store", "uss-constants").register("uss-recommendation-data-store", function(a, d, f, b, k) {
                    function g(c, a, h) {
                        this._unprocessedChunkIndex = h || 0;
                        this._recommendationBaseIdentifier = c;
                        this._dataChunks = a || []
                    }
                    var c = a.$,
                        h = k.ussCTI;
                    f = new f(k.stores.RECOMMENDATION_DATA_STORE, h.CATEGORY, h.TYPE, h.ITEM);
                    b = d.getStore(k.stores.USS_SHEET_STORE);
                    g.prototype = {
                        _getRecommendations: function(c) {
                            var h = [];
                            c < this._dataChunks.length && a.each(this._dataChunks, function(b, d) {
                                d >=
                                    c && a.each(b, function(c) {
                                        h.push(c)
                                    })
                            });
                            return h
                        },
                        getAllRecommendations: function() {
                            return this._getRecommendations(0)
                        },
                        getNewRecommendations: function() {
                            return this._getRecommendations(this._unprocessedChunkIndex)
                        },
                        getRecommendationBaseIdentifier: function() {
                            return this._recommendationBaseIdentifier
                        },
                        addRecommendationChunk: function(h) {
                            var b = [];
                            a.each(h, function(c) {
                                c.widgetType = c.widgetType || k.widgetType.RECOMMENDATION_WIDGET
                            });
                            b = c.merge(b, this._dataChunks);
                            b = c.merge(b, [h]);
                            return new g(this._recommendationBaseIdentifier,
                                b, this._dataChunks.length)
                        }
                    };
                    h = new g;
                    return d.registerStore(f, function(c, a) {
                        var h = c,
                            f = k.actions;
                        switch (a.getName()) {
                            case f.USS_OPEN:
                                d.getDispatcher().waitFor([b.getDispatchToken()]);
                                b.getState().getActionSource() === k.actionSources.DP_ATC_CLICK && (h = new g(b.getState().getRecommendationBaseIdentifier()));
                                break;
                            case f.RECOMMENDATION_DATA_RECEIVE:
                                f = b.getState().getRecommendationBaseIdentifier(), a = a._metadata, a.recommendationBaseIdentifier === f && (h = c.addRecommendationChunk(a.widgets))
                        }
                        return h
                    }, h)
                });
                e.when("uss-store-repository",
                    "dp-flux-attribution", "uss-constants").register("uss-sheet-store", function(a, d, f) {
                    function b(c, a, l) {
                        this._isSheetOpen = c || !1;
                        this._actionSource = a;
                        this._recommendationBaseIdentifier = l
                    }
                    var k = f.actions,
                        g = f.ussCTI;
                    d = new d(f.stores.USS_SHEET_STORE, g.CATEGORY, g.TYPE, g.ITEM);
                    b.prototype = {
                        isSheetOpen: function() {
                            return this._isSheetOpen
                        },
                        getActionSource: function() {
                            return this._actionSource
                        },
                        getRecommendationBaseIdentifier: function() {
                            return this._recommendationBaseIdentifier
                        }
                    };
                    g = new b(!1);
                    return a.registerStore(d,
                        function(c, a) {
                            var l = c;
                            switch (a.getName()) {
                                case k.USS_OPEN:
                                    c.isSheetOpen() || (a.getSource() === f.actionSources.DP_ATC_CLICK ? l = new b(!0, a.getSource(), a.getMetaData().recommendationBaseIdentifier) : a.getSource() === f.actionSources.USS_INGRESS_CLICK && c.getRecommendationBaseIdentifier() && (l = new b(!0, a.getSource(), c.getRecommendationBaseIdentifier())));
                                    break;
                                case k.USS_CLOSE:
                                    c.isSheetOpen() && (l = new b(!1, a.getSource(), c.getRecommendationBaseIdentifier()))
                            }
                            return l
                        }, g)
                });
                e.when("A", "uss-store-repository", "dp-flux-attribution",
                    "uss-constants", "dp-flux-utils").register("uss-atc-status-store", function(a, d, f, b, k) {
                    function g() {
                        this.status = void 0;
                        this.cart = {
                            subTotal: {}
                        };
                        this.mainImage = {};
                        this.isAtcGenericError = this.shippingMessageHTML = this.imbHTML = void 0
                    }
                    a = new f("uss-atc-status-store", b.ussCTI.CATEGORY, b.ussCTI.TYPE, b.ussCTI.ITEM);
                    g.prototype = {
                        setStatus: function(c) {
                            this.status = 1 === c || c === b.classList.ATC_SUCCESS ? b.classList.ATC_SUCCESS : b.classList.ATC_ERROR
                        },
                        setCart: function(c, a, l) {
                            k.isNonEmptyString(c) && (this.cart.count = parseInt(c));
                            a && (this.cart.subTotal = a);
                            k.isNonEmptyString(l) && (this.cart.checkoutUrl = l)
                        },
                        setMainImage: function(c, a) {
                            k.isNonEmptyString(c) && (this.mainImage.src = c, k.isNonEmptyString(a) ? this.mainImage.altText : this.mainImage.altText = "")
                        },
                        setImbHTML: function(c) {
                            k.isNonEmptyString(c) && (this.imbHTML = c)
                        },
                        setShippingMessageHTML: function(c) {
                            k.isNonEmptyString(c) && (this.shippingMessageHTML = c)
                        },
                        setIsAtcGenericError: function(c) {
                            this.isAtcGenericError = c
                        }
                    };
                    f = new g;
                    d.registerStore(a, function(c, a) {
                        var l = c;
                        switch (a.getName()) {
                            case b.actions.ATC_RECEIVE:
                                var d =
                                    a.getMetaData();
                                a.getSource() === b.actionSources.DP_ATC_CLICK ? (l = new g, d.isAtcGenericError ? l.setIsAtcGenericError(!0) : (l.setStatus(d.status), l.setCart(d.cart.count, d.cart.subTotal, d.cart.checkoutUrl), l.setMainImage(d.mainImage.src, d.mainImage.altText), l.setImbHTML(d.imbHTML), l.setShippingMessageHTML(d.shippingMessageHTML))) : a.getSource() !== b.actionSources.USS_INLINE_ATC_CLICK || d.isAtcGenericError || (l = new g, l.setStatus(c.status), l.setMainImage(c.mainImage.src, c.mainImage.altText), l.setImbHTML(c.imbHTML),
                                    l.setShippingMessageHTML(c.shippingMessageHTML), d.cart && l.setCart(d.cart.count, d.cart.subTotal, c.cart.checkoutUrl));
                                break;
                            case b.actions.USS_OPEN:
                                a.getSource() === b.actionSources.DP_ATC_CLICK && (l = new g)
                        }
                        return l
                    }, f)
                });
                e.when("A", "uss-constants").register("uss-template-store", function(a, d) {
                    var f = a.$,
                        b = d.classList,
                        k = {};
                    return {
                        init: function() {
                            var a = f("." + b.TEMPLATE_STORE),
                                c;
                            1 === a.length && a.find("." + b.TEMPLATE).each(function(a, l) {
                                c = f("\x3cdiv\x3e\x3c/div\x3e");
                                l = f(l);
                                c.append(l);
                                (a = l.data(b.TEMPLATE_NAME)) &&
                                (k[a] = c.html())
                            })
                        },
                        getTemplate: function(a) {
                            return k[a]
                        },
                        _nameToTemplateMap: k
                    }
                });
                e.when("A", "dp-flux-attribution", "dp-flux-utils", "uss-store-repository", "uss-widget", "uss-constants").register("uss-widget-factory", function(a, d, f, b, k, g) {
                    var c = a.$,
                        h = {};
                    h[g.widgetType.WIDGET] = k;
                    a = g.ussCTI;
                    var l = new d("uss-widget-factory", a.CATEGORY, a.TYPE, a.ITEM);
                    return {
                        registerWidgetType: function(a, c) {
                            if (!f.isNonEmptyString(a)) throw Error("uss-widget-factory.registerWidgetType()... : name parameter must be valid string. provided name param is \x3d " +
                                a);
                            if (!(c.prototype instanceof k)) throw Error("uss-widget-factory.registerWidgetType()... : constructor.prototype must be instance of Widget. provided constructor param is \x3d " + c);
                            h[a] = c
                        },
                        getWidgetType: function(a) {
                            return h[a]
                        },
                        getWidget: function(a) {
                            var b, f = l;
                            try {
                                var k = a.widgetType || g.widgetType.WIDGET,
                                    u = h[k];
                                if (!u) return e.log("Widget.getWidget()... : Constructor not exist for type : " + k, "FATAL", f.getAttribution()), b;
                                var x = u.getAttribution && u.getAttribution();
                                x && (f = x);
                                if (a.attribution) var p = a.attribution,
                                    f = new d(p.name, p.category, p.type, p.item);
                                var q = c(a.content),
                                    t = c("\x3cdiv\x3e\x3c/div\x3e");
                                t.append(q);
                                b = new u(f, t)
                            } catch (r) {
                                e.log("Widget.getWidget()... : " + r.message, "FATAL", f.getAttribution && f.getAttribution())
                            }
                            return b
                        }
                    }
                });
                e.when("A", "uss-constants", "dp-flux-view", "uss-store-repository", "uss-dispatcher").register("uss-widget", function(a, d, f, b, k) {
                    function e(c) {
                        var d = [];
                        a.each(c, function(a) {
                            var c = b.getStore(a);
                            if (c) d.push(c);
                            else throw Error("Widget.getWidget().getStores()... : store with name \x3d " +
                                a + " not exists");
                        });
                        return d
                    }
                    var c = d.classList,
                        h = d.widgetType;
                    return a.createClass({
                        init: function(a, d) {
                            this._element = d;
                            this._element.addClass(h.WIDGET);
                            this._element.addClass(c.HIDE_ELEMENT);
                            this._attribution = a;
                            this._dispacther = k;
                            this.getStoreNames().length && (d = e(this.getStoreNames()), this._fluxView = new f(a, d, this.update.bind(this)), this.update(d))
                        },
                        show: function(b) {
                            b = b || {};
                            b = b.showWidgetAnimation || {};
                            var h = d.animationType;
                            b.animationType = b.animationType || h.NO_ANIMATION;
                            switch (b.animationType) {
                                case h.FADE_IN:
                                    a.fadeIn(this._element,
                                        b.timeDuration || 100, b.transitionTimingFunction || d.transitionTimingFunction.EVEN_EASE);
                                    break;
                                case h.NO_ANIMATION:
                                    this._element.addClass(c.SHOW_ELEMENT), this._element.removeClass(c.HIDE_ELEMENT)
                            }
                        },
                        hide: function() {
                            this._element.addClass(c.HIDE_ELEMENT);
                            this._element.removeClass(c.SHOW_ELEMENT)
                        },
                        beforeRender: function() {},
                        afterRender: function() {},
                        getElement: function() {
                            return this._element
                        },
                        getAttribution: function() {
                            return this._attribution
                        },
                        getDispatcher: function() {
                            return this._dispacther
                        },
                        update: function(a) {},
                        getStoreNames: function() {
                            return []
                        },
                        deleteWidget: function() {
                            this._element.remove();
                            this._fluxView && this._fluxView.unregisterStores()
                        }
                    })
                });
                e.when("A", "uss-constants", "uss-widget-factory", "uss-logger-service").register("uss-recommendation-widget", function(a, d, f, b) {
                    var k = d.widgetType;
                    a = f.getWidgetType(k.WIDGET);
                    var e = d.classList,
                        c = d.metrics;
                    d = a.extend({
                        init: function(a, c) {
                            this._super(a, c);
                            this._element.addClass(k.RECOMMENDATION_WIDGET);
                            this._addTrackingMetrics()
                        },
                        _addTrackingMetrics: function() {
                            this._element.find("." +
                                e.FACEOUT_IMAGE).click(function() {
                                b.logCounter(c.FACEOUT_IMAGE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_REVIEW_STARS).click(function() {
                                b.logCounter(c.FACEOUT_REVIEW_STARS_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_PRICE).click(function() {
                                b.logCounter(c.FACEOUT_PRICE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_TITLE).click(function() {
                                b.logCounter(c.FACEOUT_TITLE_CLICK_COUNTER)
                            });
                            this._element.find("." + e.FACEOUT_BEST_SELLER).click(function() {
                                b.logCounter(c.FACEOUT_BEST_SELLER_CLICK_COUNTER)
                            })
                        }
                    });
                    f.registerWidgetType(k.RECOMMENDATION_WIDGET, d);
                    return d
                });
                e.when("A", "uss-constants", "uss-widget-factory", "dp-flux-attribution", "uss-template-store", "dp-flux-action", "uss-logger-service").register("uss-no-recommendation-widget", function(a, d, f, b, e, g, c) {
                    var h = d.widgetType;
                    a = f.getWidgetType(h.WIDGET);
                    var l = d.ussCTI,
                        w = new b(d.widgetType.NO_RECOMMENDATION_WIDGET, l.CATEGORY, l.TYPE, l.ITEM);
                    b = a.extend({
                        init: function(a, b) {
                            this._super(a, b);
                            this._element.addClass(h.NO_RECOMMENDATION_WIDGET);
                            a = e.getTemplate(d.widgetType.NO_RECOMMENDATION_WIDGET);
                            this._element.append(a);
                            this._continueShoppingLink = this._element.find("." + d.classList.CONTINUE_SHOPPING_LINK);
                            this._continueShoppingLink.click(function(a) {
                                a.preventDefault();
                                c.logCounter(d.metrics.CONTINUE_SHOPPING_CLICK);
                                this.getDispatcher().dispatch(new g(d.actions.USS_CLOSE, d.actionSources.CONTINUE_SHOPPING_CLICK))
                            }.bind(this))
                        }
                    });
                    b.getAttribution = function() {
                        return w
                    };
                    f.registerWidgetType(h.NO_RECOMMENDATION_WIDGET, b);
                    return b
                });
                e.when("A", "uss-constants", "uss-widget-factory").register("primary-action-status-widget",
                    function(a, d, f) {
                        var b = d.widgetType;
                        a = f.getWidgetType(b.WIDGET).extend({
                            init: function(a, d) {
                                this._super(a, d);
                                this.getElement().addClass(b.PRIMARY_ACTION_STATUS_WIDGET)
                            }
                        });
                        f.registerWidgetType(b.PRIMARY_ACTION_STATUS_WIDGET, a);
                        return a
                    });
                e.when("A", "promising-ui-element", "uss-utils", "uss-constants").register("promising-image", function(a, d, f, b) {
                    var k = a.$,
                        g = b.classList;
                    return d.extend({
                        init: function(a, b) {
                            this._element = k(b);
                            this._attribution = a;
                            this._super(this._element);
                            this._eventHandle = void 0
                        },
                        _showTickMarkImage: function(c) {
                            switch (c) {
                                case g.ATC_SUCCESS:
                                    this._showSuccessTickMark();
                                    break;
                                case g.ATC_ERROR:
                                    this._showErrorTickMark();
                                    break;
                                default:
                                    return
                            }
                            a.off(this._eventHandle.event, this._eventHandle.callback)
                        },
                        _showSuccessTickMark: function() {
                            k(".main-image").find(".success-tick-mark-placeholder").addClass("success-tick-mark-image")
                        },
                        _showErrorTickMark: function() {
                            var c = k(".main-image").find(".error-tick-mark-placeholder");
                            c.addClass("error-tick-mark-image");
                            a.fadeIn(c, 200, b.transitionTimingFunction.EASE_OUT)
                        },
                        showUIValue: function(c, d, l) {
                            var g = this,
                                v = b.defaultAtcAnimationType,
                                D =
                                this._super.bind(this);
                            v === b.animationType.FADE_IN && (this._eventHandle = a.on(b.atcAnimationStatusEvent, this._showTickMarkImage.bind(this, l)));
                            return f.loadImage(c, d).then(function(c) {
                                    if (v === b.animationType.FADE_IN) {
                                        var d = k(".main-image").find(".ui-promise");
                                        a.fadeOut(d, 200, b.transitionTimingFunction.EASE_IN, function() {
                                            g._appendImageToUIValue(c);
                                            D();
                                            var d = k(".main-image").find(".ui-value");
                                            a.fadeIn(d, 200, b.transitionTimingFunction.EASE_OUT)
                                        })
                                    } else this._appendImageToUIValue(c), D();
                                    return !0
                                }.bind(this),
                                function() {
                                    e.log("PromisingImage.showUIValue() ... : failed to load image", "FATAL", this._attribution.getAttribution());
                                    return !1
                                }.bind(this))
                        },
                        _appendImageToUIValue: function(a) {
                            this.getValueElement().empty();
                            this.getValueElement().append(a)
                        }
                    })
                });
                e.when("A", "promising-ui-element", "uss-constants").register("atc-status-msg", function(a, d, f) {
                    var b = f.classList;
                    return d.extend({
                        init: function(a) {
                            this._atcStatusElement = a;
                            this._super(this._atcStatusElement)
                        },
                        _showSuccessMessage: function() {
                            this._atcStatusElement.addClass(b.ATC_SUCCESS);
                            this._atcStatusElement.removeClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ITEM_IN_CART)
                        },
                        _showFailureMessage: function() {
                            this._atcStatusElement.addClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ATC_SUCCESS);
                            this._atcStatusElement.removeClass(b.ITEM_IN_CART)
                        },
                        _showItemInCartMessage: function() {
                            this._atcStatusElement.addClass(b.ITEM_IN_CART);
                            this._atcStatusElement.removeClass(b.ATC_ERROR);
                            this._atcStatusElement.removeClass(b.ATC_SUCCESS)
                        },
                        showUIValue: function(d) {
                            var e = this,
                                c = f.defaultAtcAnimationType;
                            switch (d) {
                                case b.ATC_SUCCESS:
                                    this._showSuccessMessage();
                                    break;
                                case b.ATC_ERROR:
                                    this._showFailureMessage();
                                    break;
                                case b.ITEM_IN_CART:
                                    this._showItemInCartMessage();
                                    break;
                                default:
                                    return
                            }
                            this._super();
                            c === f.animationType.FADE_IN && (d = this._atcStatusElement.find("." + b.UI_PROMISE), a.fadeOut(d, 200, f.transitionTimingFunction.EASE_IN, function() {
                                var c = e._atcStatusElement.find("." + b.UI_VALUE);
                                a.fadeIn(c, 200, f.transitionTimingFunction.EASE_OUT, function() {
                                    a.trigger(f.atcAnimationStatusEvent)
                                })
                            }))
                        }
                    })
                });
                e.when("A",
                    "promising-ui-element", "uss-constants", "dp-flux-utils").register("cart-status-message", function(a, d, f, b) {
                    var e = f.classList;
                    return d.extend({
                        init: function(a) {
                            this._cartStatusElement = a;
                            this._subTotalElement = this._cartStatusElement.find("." + e.CART_SUB_TOTAL);
                            this._cartCountElement = this._cartStatusElement.find("." + e.CART_COUNT);
                            this._cartCountSingularTemplate = this._cartCountElement.data("cart-count-singular-template");
                            this._cartCountPluralTemplate = this._cartCountElement.data("cart-count-plural-template");
                            this._super(this._cartStatusElement);
                            this._eventHandle = void 0
                        },
                        _atcAnimationStatusResolved: function() {
                            setTimeout(function() {
                                this._cartStatusElement.addClass("uss-c-cart-status-msg-transition");
                                a.off(this._eventHandle.event, this._eventHandle.callback)
                            }.bind(this), 200)
                        },
                        showUIValue: function(d, c) {
                            var h = f.defaultAtcAnimationType;
                            if ("number" === typeof d && b.isNonEmptyString(c)) {
                                var l;
                                1 === d ? l = this._cartCountSingularTemplate.replace("###cartCount", d) : 1 < d && (l = this._cartCountPluralTemplate.replace("###cartCount",
                                    d));
                                this._cartCountElement.html(l);
                                this._subTotalElement.html(c);
                                this._super();
                                h === f.animationType.FADE_IN && (this._eventHandle = a.on(f.atcAnimationStatusEvent, this._atcAnimationStatusResolved.bind(this)))
                            }
                        }
                    })
                });
                e.when("A", "a-button", "uss-constants", "uss-logger-service").register("uss-sub-nav", function(a, d, f, b) {
                    var e = f.classList,
                        g = f.metrics;
                    return {
                        getInstance: function(c) {
                            var h = {},
                                l = c.find("." + e.CHECKOUT_FORM);
                            d("." + e.CHECKOUT_BUTTON, c);
                            var w = c.find("." + e.CART_BUTTON),
                                v = void 0;
                            l.submit(function() {
                                b.logCounter(g.CHECKOUT_FORM_CLICK_COUNTER)
                            });
                            w.click(function() {
                                b.logCounter(g.CART_BUTTON_CLICK_COUNTER)
                            });
                            h.updateCheckoutUrl = function(a) {
                                l.attr("action", a)
                            };
                            h.hide = function() {
                                a.$(c).addClass("is-hidden")
                            };
                            h.atcAnimationStatusResolved = function() {
                                setTimeout(function() {
                                    a.$(c).addClass("uss-c-sub-nav-margin");
                                    a.$(c).addClass("uss-c-sub-nav-transition");
                                    a.off(v.event, v.callback)
                                }.bind(), 200)
                            };
                            h.show = function() {
                                a.$(c).removeClass("is-hidden");
                                f.defaultAtcAnimationType === f.animationType.FADE_IN && (v = a.on(f.atcAnimationStatusEvent, h.atcAnimationStatusResolved.bind()))
                            };
                            h.preInitiate = function() {
                                var a = l.parent();
                                a.find("iframe#ussCheckoutPrefetch").remove();
                                var c = (new Date).getTime(),
                                    d = "/gp/checkoutprefetch/checkout-prefetch.html?checkoutInitiateId\x3d" + c,
                                    b = document.createElement("iframe");
                                b.setAttribute("src", d);
                                b.setAttribute("style", "width:0px;height:0px;display:none;position:absolute;");
                                b.setAttribute("name", "ussCheckoutPrefetch");
                                b.setAttribute("id", "ussCheckoutPrefetch");
                                a.append(b);
                                a = l.find("#checkoutInitiateId");
                                a.length ? a.val(c) : l.append("\x3cinput type\x3d'hidden' name\x3d'checkoutInitiateId' id\x3d'checkoutInitiateId' value\x3d'" +
                                    c + "'\x3e")
                            };
                            h.hide();
                            return h
                        }
                    }
                });
                e.when("A", "uss-constants").register("uss-shipping-details", function(a, d) {
                    var f = a.$;
                    return {
                        getInstance: function(b) {
                            var e = b.find("." + d.classList.SHIPPING_DETAILS),
                                g = e.find("." + d.classList.SHIPPING_MESSAGE_PLACEHOLDER),
                                c = d.defaultAtcAnimationType,
                                h = void 0,
                                l = function() {
                                    var a = g.find(".a-row").find("a"),
                                        c = a.attr("onclick");
                                    if ("undefined" !== typeof c && c.includes("amz_js_PopWin")) {
                                        var d = [];
                                        f.each(a[0].attributes, function(a, c) {
                                            d.push(c.name)
                                        });
                                        f.each(d, function(c, d) {
                                            a.removeAttr(d)
                                        });
                                        a.attr("href", "/gp/help/customer/display.html?nodeId\x3d527692")
                                    }
                                },
                                w = {
                                    hide: function() {
                                        e.addClass(d.classList.HIDE_ELEMENT);
                                        e.removeClass(d.classList.SHOW_ELEMENT)
                                    },
                                    atcAnimationStatusResolved: function() {
                                        setTimeout(function() {
                                            e.addClass("uss-c-shipping-details-transition");
                                            a.off(h.event, h.callback)
                                        }.bind(), 200)
                                    },
                                    show: function(b) {
                                        g.empty();
                                        g.append(a.$(b));
                                        l();
                                        e.addClass(d.classList.SHOW_ELEMENT);
                                        e.removeClass(d.classList.HIDE_ELEMENT);
                                        c === d.animationType.FADE_IN && (h = a.on(d.atcAnimationStatusEvent, w.atcAnimationStatusResolved.bind()))
                                    }
                                };
                            w.hide();
                            return w
                        }
                    }
                });
                e.when("A", "uss-constants", "primary-action-status-widget", "dp-flux-attribution", "uss-widget-factory", "atc-status-msg", "cart-status-message", "promising-image", "uss-sub-nav", "uss-shipping-details").register("atc-status-widget", function(a, d, f, b, e, g, c, h, l, w) {
                    var v = d.ussCTI,
                        D = d.widgetType,
                        y = d.classList,
                        u = new b(d.widgetType.ATCStatusWidget, v.CATEGORY, v.TYPE, v.ITEM);
                    f = f.extend({
                        init: function(a, d) {
                            this._atcGenericError = d.find("." + y.ATC_GENERIC_ERROR);
                            this._atcAcknowledgementMessage =
                                d.find("." + y.ATC_ACKNOWLEDGEMENT_MESSAGE);
                            this._mainImage = new h(a, this._atcAcknowledgementMessage.find("." + y.MAIN_IMAGE));
                            this._atcStatusMessage = new g(this._atcAcknowledgementMessage.find("." + y.ATC_STATUS_MESSAGE_COMPONENT));
                            this._cartStatusMessage = new c(this._atcAcknowledgementMessage.find("." + y.CART_STATUS_MESSAGE_COMPONENT));
                            this._subNav = l.getInstance(this._atcAcknowledgementMessage.find("." + y.SUB_NAV));
                            this._shippingDetails = w.getInstance(this._atcAcknowledgementMessage);
                            this._viewState = {};
                            this._super(a,
                                d)
                        },
                        update: function(c) {
                            var b;
                            a.each(c, function(c) {
                                c.getStoreAttribution().getName() === d.stores.ATC_STATUS_STORE && (this._subNav.preInitiate(), b = c.getState(), b.isAtcGenericError ? this.showGenericError() : (c = a.diff(this._viewState, b), c.status && b.status && this._atcStatusMessage.showUIValue(b.status), c.cart.count && b.cart.count && (this._cartStatusMessage.showUIValue(b.cart.count, b.cart && b.cart.subTotal && b.cart.subTotal.displayString || ""), c.cart.checkoutUrl && b.cart.checkoutUrl && this._subNav.updateCheckoutUrl(b.cart.checkoutUrl),
                                    this._subNav.show()), c.mainImage.src && b.mainImage.src && this._mainImage.showUIValue(b.mainImage.src, b.mainImage.altText, b.status), c.shippingMessageHTML && b.shippingMessageHTML && this._shippingDetails.show(b.shippingMessageHTML)), this._viewState = b)
                            }.bind(this))
                        },
                        showGenericError: function() {
                            this._atcAcknowledgementMessage.addClass(y.HIDE_ELEMENT);
                            this._atcAcknowledgementMessage.removeClass(y.SHOW_ELEMENT);
                            this._atcGenericError.removeClass(y.HIDE_ELEMENT);
                            this._atcGenericError.addClass(y.SHOW_ELEMENT)
                        },
                        getStoreNames: function() {
                            return [d.stores.ATC_STATUS_STORE]
                        }
                    });
                    f.getAttribution = function() {
                        return u
                    };
                    e.registerWidgetType(D.ATCStatusWidget, f);
                    return f
                });
                e.when("A", "uss-constants", "dp-flux-attribution", "uss-widget-factory").register("atc-status-imb-widget", function(a, d, f, b) {
                    var k = b.getWidgetType(d.widgetType.WIDGET),
                        g = d.ussCTI,
                        c = new f("atc-status-imb-widget", g.CATEGORY, g.TYPE, g.ITEM);
                    f = k.extend({
                        init: function(a, c) {
                            c.addClass(d.widgetType.ATC_STATUS_IMB_WIDGET);
                            this._super(a, c)
                        },
                        update: function(b) {
                            var f;
                            a.each(b, function(b) {
                                if (b.getStoreAttribution().getName() === d.stores.ATC_STATUS_STORE)
                                    if (f = b.getState(), f.imbHTML) {
                                        this.getElement().empty();
                                        b = a.$(f.imbHTML);
                                        var h = b.children().length;
                                        if (1 <= h) {
                                            b.find(".a-declarative a").unwrap();
                                            var g = b.find(".a-declarative span");
                                            g.removeClass("a-color-link huc-cursor-pointer");
                                            g.unwrap();
                                            this.getElement().append(b);
                                            this.show();
                                            1 < h && e.log("ImbWidget.update(...): More than one IMB message exist : html \x3d " + f.imbHTML, "WARN", c.getAttribution())
                                        } else this.hide()
                                    } else this.hide()
                            }.bind(this))
                        },
                        afterRender: function() {
                            this.hide()
                        },
                        getStoreNames: function() {
                            return [d.stores.ATC_STATUS_STORE]
                        }
                    });
                    f.getAttribution = function() {
                        return c
                    };
                    b.registerWidgetType(d.widgetType.ATC_STATUS_IMB_WIDGET, f);
                    return f
                });
                e.when("A").register("uss-base-layout", function(a) {
                    return a.createClass({
                        init: function(a) {
                            this._ussSheetElement = a
                        },
                        renderWidgets: function(a) {
                            throw Error("Layout.renderWidgets()...: Subclass must implement update method");
                        },
                        reset: function() {
                            throw Error("Layout.reset()...: Subclass must implement reset method");
                        },
                        getUssSheetElement: function() {
                            return this._ussSheetElement
                        }
                    })
                });
                e.when("A", "uss-base-layout", "promising-ui-element", "uss-constants", "primary-action-status-widget", "atc-status-imb-widget").register("uss-default-layout", function(a, d, f, b, e, g) {
                    var c = b.layout.defaultLayout;
                    return d.extend({
                        init: function(d) {
                            this._super(d);
                            this._element = d.find("." + c.DEFAULT_LAYOUT);
                            this._ussHead = this._element.find("." + c.HEAD);
                            this._ussBody = this._element.find("." + c.BODY);
                            this._widgetList = [];
                            this._recommendationLoader = a.$("." +
                                c.SKELETON_LOADER);
                            this._recommendationLoadingMessage = a.$("." + c.RECOMMENDATION_LOADING_MESSAGE);
                            this._recommendationLoadedMessage = a.$("." + c.RECOMMENDATION_LOADED_MESSAGE);
                            this._ussBody.append(this._recommendationLoader);
                            this._recommendationLoaderFadeOutOptions = {
                                timeDuration: 200,
                                transitionTimingFunction: b.transitionTimingFunction.EASE_IN
                            };
                            this._recommendationLoaderFadeInOptions = {
                                timeDuration: 200,
                                transitionTimingFunction: b.transitionTimingFunction.EASE_OUT
                            };
                            this._recommendationWidgetOptions = {
                                showWidgetAnimation: {
                                    animationType: b.animationType.FADE_IN,
                                    timeDuration: 200,
                                    transitionTimingFunction: b.transitionTimingFunction.EASE_OUT
                                }
                            }
                        },
                        renderWidgets: function(b) {
                            var d, f = !1;
                            a.each(b, function(b) {
                                d = {};
                                b.beforeRender();
                                this._widgetList.push(b);
                                if (b instanceof e) this._ussHead.prepend(b.getElement());
                                else if (b.getElement().addClass(c.BOTTOM_MARGIN_BETWEEN_WIDGETS), b.getElement().addClass(c.TOP_MARGIN_BETWEEN_WIDGETS), b instanceof g) this._ussBody.prepend(b.getElement());
                                else {
                                    if (!f) {
                                        f = !0;
                                        var h = this;
                                        a.fadeOut(this._recommendationLoader, this._recommendationLoaderFadeOutOptions.timeDuration,
                                            this._recommendationLoaderFadeOutOptions.transitionTimingFunction,
                                            function() {
                                                a.fadeIn(h._recommendationLoadedMessage, h._recommendationLoaderFadeInOptions.timeDuration, h._recommendationLoaderFadeInOptions.transitionTimingFunction)
                                            })
                                    }
                                    d = this._recommendationWidgetOptions;
                                    this._ussBody.append(b.getElement())
                                }
                                b.show(d);
                                b.afterRender()
                            }.bind(this))
                        },
                        reset: function() {
                            a.each(this._widgetList, function(a) {
                                a.deleteWidget()
                            });
                            this._widgetList = [];
                            this._ussBody.empty();
                            this._ussBody.append(this._recommendationLoader);
                            this._ussBody.append(this._recommendationLoadedMessage);
                            this._recommendationLoader.css({
                                display: "block"
                            });
                            this._recommendationLoadingMessage.css({
                                display: "none"
                            });
                            this._recommendationLoadedMessage.css({
                                display: "none"
                            });
                            this.resetScrollPosition()
                        },
                        resetScrollPosition: function() {
                            this._ussBody.scrollTop(0)
                        }
                    })
                });
                e.when("uss-constants", "dp-flux-action", "uss-dispatcher").register("uss-action-creator-helper", function(a, d, f) {
                    return {
                        primaryATCClick: function(b, e) {
                            var g = new d(a.actions.USS_OPEN, a.actionSources.DP_ATC_CLICK, {
                                recommendationBaseIdentifier: b
                            });
                            f.dispatch(g);
                            e.atcData.then(function(c) {
                                var b = {};
                                1 === c.isOk ? b = c.atcStatusData : b.isAtcGenericError = !0;
                                c = new d(a.actions.ATC_RECEIVE, a.actionSources.DP_ATC_CLICK, b);
                                f.dispatch(c)
                            }, function() {
                                var c = new d(a.actions.ATC_RECEIVE, a.actionSources.DP_ATC_CLICK, {
                                    isAtcGenericError: !0
                                });
                                f.dispatch(c)
                            });
                            e.percolateData.then(function(c) {
                                var e = {
                                    isContainsRecommendation: !1,
                                    widgets: []
                                };
                                c.recommendationData && (e.widgets = c.recommendationData.widgets || []);
                                e.widgets.length || e.widgets.push({
                                    widgetType: a.widgetType.NO_RECOMMENDATION_WIDGET
                                });
                                e.recommendationBaseIdentifier = b;
                                c = new d(a.actions.RECOMMENDATION_DATA_RECEIVE, a.actionSources.DP_ATC_CLICK, e);
                                f.dispatch(c)
                            }, function() {
                                var c = {
                                    widgets: []
                                };
                                c.widgets.push({
                                    widgetType: a.widgetType.NO_RECOMMENDATION_WIDGET
                                });
                                c.recommendationBaseIdentifier = b;
                                c = new d(a.actions.RECOMMENDATION_DATA_RECEIVE, a.actionSources.DP_ATC_CLICK, c);
                                f.dispatch(c)
                            })
                        },
                        secondaryATCClick: function(b) {
                            b.atcData.then(function(b) {
                                var e = {};
                                1 === b.isOk ? e = b.atcStatusData : e.isAtcGenericError = !0;
                                b = new d(a.actions.ATC_RECEIVE, a.actionSources.USS_INLINE_ATC_CLICK,
                                    e);
                                f.dispatch(b)
                            }, function() {})
                        }
                    }
                })
            },
            initializeUSSComponents: function() {
                e.when("uss-template-store", "uss-sheet-store", "uss-recommendation-data-store", "uss-store-repository", "uss-widget", "uss-recommendation-widget", "primary-action-status-widget", "uss-widget-factory", "uss-sheet-view", "uss-layout").register("uss-framework-ready", function(a) {
                    a.init()
                });
                e.when("uss-sheet-view", "uss-framework-ready").register("uss-sheet-view-ready", function(a) {
                    a.initializeUSSSheetView()
                })
            },
            initializeBuyBox: function() {
                e.when("buy-box-override",
                    "atc-status-widget", "atc-status-imb-widget", "uss-atc-status-store", "uss-framework-ready", "uss-sheet-view-ready").execute(function(a) {
                    a.init()
                })
            }
        }
    });
    e.when("A", "atf", "uss-init-helper", "uss-utils", "uss-preconditions", "uss-logger-service", "uss-constants").register("uss-init", function(C, B, m, A, a, d, f) {
        function b() {
            m.loadUssCommonAssets();
            e.when("A", "3p-promise", "uss-constants", "a-sheet", "uss-logger-service").register("uss-sheet-component", function(a, b, d, f, e) {
                function g() {
                    var b = p("#image-block").offset().top;
                    a.requestAnimationFrame(function() {
                        t.css({
                            position: "fixed",
                            top: "-" + b + "px"
                        })
                    }, t[0])
                }

                function k() {
                    a.requestAnimationFrame(function() {
                        t.css({
                            position: "",
                            top: ""
                        })
                    }, t[0])
                }

                function u(a) {
                    var c = a.find("." + z.HEAD_DIVIDER);
                    a.scroll(function() {
                        0 < a.scrollTop() ? c.removeClass(d.classList.HIDE_ELEMENT) : c.addClass(d.classList.HIDE_ELEMENT)
                    })
                }

                function x(b, h) {
                    if (!(this instanceof x)) throw Error(q.INVALID_CONSTRUCTOR_USAGE);
                    if ("string" === typeof b)
                        if (p("#" + b).length) {
                            var t = this;
                            this._sheetID = b;
                            this._sheet = f.create({
                                name: "uss_bottom_sheet",
                                preloadDomId: b,
                                height: 1E3,
                                closeType: "message",
                                sheetType: "web",
                                closeMessage: "DONE"
                            });
                            this._sheetElement = p("#" + b);
                            m() === d.deviceOrientation.ORIENTATION_LANDSCAPE && this._sheetElement.find("." + z.HEAD).removeClass(d.classList.USS_C_HEAD_STICKY);
                            a.on("a:sheet:beforeHide:uss_bottom_sheet", function() {
                                r && h.beforeClose && h.beforeClose();
                                k();
                                e.logCounter("uss_bottom_sheet:close")
                            });
                            a.on("orientationchange", function() {
                                var a = m(),
                                    c = t._sheetElement.find("." + z.HEAD);
                                a === d.deviceOrientation.ORIENTATION_PORTRAIT ? c.addClass(d.classList.USS_C_HEAD_STICKY) :
                                    c.removeClass(d.classList.USS_C_HEAD_STICKY)
                            });
                            a.on("a:sheet:beforeShow:uss_bottom_sheet", function(a) {
                                g();
                                u(t._sheetElement)
                            })
                        } else throw Error("Unique element with id '" + b + "' must exist inside a DOM");
                    else throw Error(q.INVALID_SHEET_ID);
                }
                var p = a.$,
                    q = d.fatalMessagesList,
                    t = p("#a-page");
                p("body");
                var r = !0,
                    z = d.layout.defaultLayout,
                    m = function() {
                        return p(n).height() > p(n).width() ? d.deviceOrientation.ORIENTATION_PORTRAIT : d.deviceOrientation.ORIENTATION_LANDSCAPE
                    };
                x.prototype.open = function() {
                    return new b(function(a) {
                        r = !0;
                        this._sheet.show();
                        e.logCounter("uss_bottom_sheet:open");
                        a(!0)
                    }.bind(this))
                };
                x.prototype.close = function() {
                    return new b(function(a) {
                        r = !1;
                        this._sheet.hide();
                        a(!0)
                    }.bind(this))
                };
                x.prototype.getSheetElement = function() {
                    return this._sheetElement
                };
                return x
            });
            e.when("A", "a-checkbox").register("buy-box-utility", function(a, b) {
                return {
                    isWarrantySelectedInBuyBox: function() {
                        var a = b(".mbb-checkbox");
                        return 0 < a.size() && a.isChecked()
                    }
                }
            });
            e.when("jQuery", "A", "uss-utils", "uss-atc", "uss-constants").execute("uss-inline-atc",
                function(a, b, d, f, e) {
                    function g(a) {
                        var c = {};
                        c.a = a.cartArgs.ASIN;
                        c.oid = a.cartArgs.offerListingID;
                        c.verificationSessionID = a.cartArgs.verificationSessionID;
                        c.quantity = a.cartArgs.quantity;
                        c.o = "add";
                        return c
                    }

                    function k(a, c, b, d) {
                        a && 1 === a.isOk && a.atcStatusData && 1 === a.atcStatusData.status ? (d.addClass(u.HIDE_ELEMENT), c.removeClass(u.HIDE_ELEMENT)) : (d.addClass(u.HIDE_ELEMENT), b.removeClass(u.HIDE_ELEMENT))
                    }
                    var u = e.classList;
                    (function() {
                        b.declarative("p13n-overflow-atc", "click", function(b) {
                            var e = b.data;
                            b = b.$declarativeParent;
                            var h = b.parent().find(u.SUCCESS_ELEMENT),
                                t = b.parent().find(u.ERROR_ELEMENT),
                                r = b.find(u.BUTTON_ELEMENT);
                            b = {};
                            r.attr("disabled", "disabled");
                            r.addClass(u.DISABLE_BUTTON);
                            b = "";
                            e.linkParams && (b = a.param(e.linkParams));
                            if (d.isMobileApp()) e.inputs = g(e), e.inputs.isSecondaryAtc = 1, b && "" !== b.trim() && ("\x26" === b.charAt(b.length - 1) && (b = b.substring(0, b.length - 1)), e.reftag = e.reftag + "?" + b), b = f.addToCart("RecommendationsWidget", e);
                            else {
                                var z = {
                                    params: g(e)
                                };
                                b = f.addToCart("RecommendationsWidget", z, {
                                    linkParams: b,
                                    ref: e.reftag
                                })
                            }
                            b.atcData.done(function(a) {
                                k(a,
                                    h, t, r)
                            });
                            b.atcData.fail(function() {
                                k(null, h, t, r)
                            })
                        })
                    })()
                });
            e.when("jQuery", "A", "a-component", "a-truncate", "uss-constants").register("uss-list-widget", function(a, b, d, e, f) {
                var g = d.create({
                    _componentName: "ussListWidget",
                    init: function(a, c) {
                        var d = f.classList;
                        this._super(a, c);
                        a = this._$element.find(".a-truncate");
                        a.length && a.each(function() {
                            e.get(this).update()
                        });
                        this._$element.find(".a-icon-row").addClass(d.FACEOUT_REVIEW_STARS);
                        b.loadDynamicImage(this._$element.find("." + d.FACEOUT_IMAGE))
                    }
                });
                return function(a,
                    b) {
                    return new g(a, b)
                }
            });
            e.when("A", "uss-default-layout").register("uss-mobile-default-layout", function(a, b) {
                return b.extend({
                    init: function(a) {
                        this._super(a)
                    },
                    resetScrollPosition: function() {
                        a.animationFrameDelay(function() {
                            this._ussSheetElement.scrollTop(0)
                        }.bind(this))
                    }
                })
            });
            A.isMobileApp() ? (e.when("A", "mash", "uss-constants", "uss-store-repository", "dp-flux-attribution", "dp-flux-view", "dp-flux-action", "uss-dispatcher", "uss-logger-service").register("uss-mash-reappear", function(a, b, d, e, f, g, k, u, m) {
                function p() {
                    q.isFunction(r) &&
                        r.apply(n.app, arguments);
                    m.logCounter(d.metrics.MASH_REAPPEAR);
                    u.dispatch(new k(d.actions.USS_CLOSE, d.actionSources.MASH_REAPPEAR))
                }
                var q = a.$;
                a = d.ussCTI;
                var t = e.getStore(d.stores.USS_SHEET_STORE);
                e = new f("uss-mash-reappear-view", a.CATEGORY, a.TYPE, a.ITEM);
                new g(e, [t], function(a) {
                    n.app.willReappear !== p && (r = n.app.willReappear); - 1 !== q.inArray(t, a) && (a = t.getState(), a.isSheetOpen() ? n.app.willReappear = p : n.app.willReappear = r)
                });
                var r
            }), e.when("A", "uss-constants", "uss-logger-service").register("percolateUI-ajax-utility",
                function(a, b, d) {
                    var e = b.ajaxParams.AJAX_TIMEOUT,
                        f = b.metrics;
                    return {
                        callPercolateUI: function(b) {
                            b = {
                                pageType: "DetailAW",
                                baseAsin: b,
                                subPageType: "mobile-uss"
                            };
                            var h = a.$.Deferred(),
                                g = new d.Timer(f.PERCOLATE_DATA_PROMISE_RESOLVED_TIMER);
                            g.start();
                            a.post("/gp/uss/mobile/", {
                                params: b,
                                success: function(a, b, c) {
                                    h.resolve(a)
                                },
                                error: function(a, b) {
                                    h.reject()
                                },
                                timeout: e
                            });
                            h.done(function(a) {
                                g.stop()
                            });
                            h.fail(function() {
                                d.logCounter(f.PERCOLATE_DATA_PROMISE_REJECTED_COUNTER)
                            });
                            return h.promise()
                        }
                    }
                }), e.when("A", "uss-action-creator-helper",
                "percolateUI-ajax-utility", "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("uss-atc", function(a, b, d, e, f, g, k) {
                function m(a, b, c, d) {
                    if (e.isUssWeblabInTreatment()) return r.bind(null, a, b, c, d)
                }

                function n(a) {
                    this.widgetName = a;
                    this.isPrimaryAtc = "DetailPageBuyBox" === a
                }
                var p = a.$,
                    q = {},
                    t = g.metrics,
                    r = function(a, c, e, g, k) {
                        var r = {};
                        k && k.atcStatusData && 1 === k.atcStatusData.isOk ? e.resolve(k.atcStatusData) : (e.reject(), f.logCounter(t.ATC_PROMISE_REJECTED_COUNTER));
                        r.atcData = e;
                        c ? (g = d.callPercolateUI(a),
                            r.percolateData = g, b.primaryATCClick(a, r)) : (f.logCounter(t.SECONDARY_ADD_TO_CART_CLICK_COUNTER), b.secondaryATCClick(r))
                    };
                n.prototype._addUssParameters = function(a) {
                    e.isUssWeblabInTreatment() ? (a.inputs.isUSSAjax = 1, this.isPrimaryAtc && (k.shouldFireAndForgetWeblabTrigger() || (a.inputs.triggerUSSWeblab = e.triggerUSSWeblabValue()))) : k.shouldFireAndForgetWeblabTrigger() || (a.inputs.triggerUSSWeblab = e.triggerUSSWeblabValue());
                    var b = k.getDebugParams();
                    Object.keys(b).forEach(function(c) {
                        a.params[c] = b[c]
                    });
                    return a
                };
                n.prototype._addToCart = function(b) {
                    var d = p.Deferred(),
                        e = p.Deferred(),
                        h = {},
                        g = b.inputs.a;
                    b = this._addUssParameters(b);
                    h.atcData = d;
                    var l = new f.Timer(t.ATC_PROMISE_RESOLVED_TIMER);
                    l.start();
                    d.done(function(a) {
                        l.stop()
                    });
                    a.trigger("js-trigger-aw-mash", b, m(g, this.isPrimaryAtc, d, e));
                    return h
                };
                return {
                    addToCart: function(a, b) {
                        if (!a || !a.trim().length || "object" !== typeof b) throw g.fatalMessagesList.INCORRECT_PARAMETER_PASSED;
                        q[a] || (q[a] = new n(a));
                        return q[a]._addToCart(b)
                    }
                }
            }), e.when("A", "uss-atc", "buy-box-utility",
                "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("buy-box-override", function(a, b, d, e, f, g, k) {
                var m = !1,
                    x = {
                        init: function() {
                            a.$.isFunction(n.markFeatureInteractive) && n.markFeatureInteractive("atc", {
                                hasComponents: !0,
                                components: [{
                                    name: "show-uss-interstitial"
                                }]
                            });
                            a.declarative("show-uss-interstitial", "click", function(p) {
                                var q = n.ue;
                                q && q.count && p && p.data && "add-to-cart" === p.data.buttonID && q.count("DetailPage_MobileApp_AddToCart", (q.count("DetailPage_MobileApp_AddToCart") || 0) + 1);
                                var q = e.isUssConditionsPassed(),
                                    t = d.isWarrantySelectedInBuyBox();
                                q && !t ? (k.shouldFireAndForgetWeblabTrigger() && k.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue()), b.addToCart("DetailPageBuyBox", p.data)) : (f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED), a.trigger("js-trigger-aw-mash", p.data))
                            });
                            a.declarative("show-uss-interstitial", ["touchstart"], function(a) {
                                var b = a.$event.originalEvent,
                                    c = n.ue;
                                b.acknowledge && (b.acknowledge(0 < a.$currentTarget.length ? a.$currentTarget[0] :
                                    void 0), c && c.count && c.count("tnr-post-ack-atc", (c.count("tnr-post-ack-atc") || 0) + 1))
                            })
                        }
                    };
                return {
                    init: function() {
                        m || (m = !0, x.init())
                    }
                }
            })) : (e.when("A", "uss-constants", "dp-flux-attribution", "dp-flux-view", "uss-store-repository", "uss-atc-status-store").register("nav-bar-cart-count-view", function(a, b, d, e, f, g) {
                var k = a.$;
                a = b.ussCTI;
                d = new d("nav-bar-cart-count-view", a.CATEGORY, a.TYPE, a.ITEM);
                g = f.getStore(b.stores.ATC_STATUS_STORE);
                new e(d, [g], function(a) {
                    if (-1 !== k.inArray(g, a)) {
                        var b = g.getState();
                        n.$Nav.when("api.setCartCount").run(function(a) {
                            b.cart.count &&
                                a(b.cart.count)
                        })
                    }
                })
            }), e.when("A", "uss-action-creator-helper", "uss-preconditions", "uss-logger-service", "uss-constants", "uss-utils").register("uss-atc", function(a, b, d, e, f, g) {
                function k(a) {
                    this.widgetName = a;
                    this.isPrimaryAtc = "DetailPageBuyBox" === a
                }
                var m = a.$,
                    x = f.ajaxParams.AJAX_TIMEOUT,
                    p = f.ajaxParams.BASE_URL,
                    q = {};
                k.prototype._getAtcUrl = function(a) {
                    var b = p;
                    a.hasOwnProperty("ref") && (b = b + "/ref\x3d" + a.ref);
                    (a = a.linkParams) && "" !== a.trim() && ("\x26" === a.charAt(a.length - 1) && (a = a.substring(0, a.length - 1)), b =
                        b + "?" + a);
                    return b
                };
                k.prototype._addUssParameters = function(a) {
                    a.params.isUSSAjax = 1;
                    this.isPrimaryAtc && (a.params.isPrimaryATC = 1, g.shouldFireAndForgetWeblabTrigger() || (a.params.triggerUSSWeblab = d.triggerUSSWeblabValue()));
                    var b = g.getDebugParams();
                    Object.keys(b).forEach(function(c) {
                        a.params[c] = b[c]
                    });
                    return a
                };
                k.prototype._callback = function() {
                    var a = arguments[0],
                        b = Array.prototype.slice.call(arguments, 1);
                    "function" === typeof a && a.apply(this, b)
                };
                k.prototype._addToCart = function(b, d) {
                    var e = this;
                    b = this._getAtcUrl(b);
                    d = this._addUssParameters(d);
                    var f = m.Deferred(),
                        h = m.Deferred(),
                        g = {};
                    a.post(b, {
                        params: d.params,
                        success: function(b, f, h) {
                            d.hasOwnProperty("success") && e._callback(d.success, b, f, h);
                            a.trigger("USS ATC: Success")
                        },
                        error: function(b, g, k) {
                            f.reject();
                            h.reject();
                            d.hasOwnProperty("error") && e._callback(d.error, b, g, k);
                            a.trigger("USS ATC : Failure")
                        },
                        abort: function(a) {
                            f.reject();
                            h.reject();
                            d.hasOwnProperty("abort") && e._callback(d.abort, a)
                        },
                        chunk: function(a) {
                            if (a && a.hasOwnProperty("name")) {
                                switch (a.name) {
                                    case "atc-data":
                                        f.resolve(a.response);
                                        break;
                                    case "percolate-data":
                                        h.resolve(a.response);
                                        break;
                                    default:
                                        var b = {
                                            message: "ATC Failed for widget " + e.widgetName + ". Unrecognized chunk name found. ",
                                            logLevel: "FATAL"
                                        };
                                        n.ueLogError && n.ueLogError("USS ATC Failure for widget " + e.widgetName, b)
                                }
                                d.hasOwnProperty("chunk") && e._callback(d.chunk, a)
                            }
                        },
                        timeout: d.timeout || x
                    });
                    g.atcData = f;
                    this.isPrimaryAtc && (g.percolateData = h);
                    return g
                };
                return {
                    addToCart: function(a, c, d) {
                        if (!a || !a.trim().length || "object" !== typeof c) throw f.fatalMessagesList.INCORRECT_PARAMETER_PASSED;
                        var g = "DetailPageBuyBox" === a;
                        q[a] || (q[a] = new k(a));
                        a = q[a]._addToCart(d, c);
                        g || (e.logCounter(f.metrics.SECONDARY_ADD_TO_CART_CLICK_COUNTER), b.secondaryATCClick(a));
                        return a
                    }
                }
            }), e.when("A", "uss-atc", "uss-action-creator-helper", "uss-preconditions", "uss-logger-service", "uss-constants", "buy-box-utility", "uss-utils").register("buy-box-override", function(a, b, d, e, f, g, k, m) {
                var n = a.$,
                    p = g.metrics;
                a = {
                    actionButton: null,
                    whitelistedActions: {
                        "submit.add-to-cart": 1
                    },
                    init: function() {
                        this.checkPreconditionsAndManipulateBuyBox()
                    },
                    checkPreconditionsAndManipulateBuyBox: function() {
                        this.buyBoxForm = n("#addToCart");
                        (e.isUssConditionsPassed() || e.isUssConditionsPassedUssVsDss()) && this.attachFormHandler()
                    },
                    attachFormHandler: function() {
                        this.buyBoxForm.submit(this.submitForm.bind(this));
                        this.buyBoxForm.find("input[type\x3dsubmit], input[type\x3dbutton]").click(function(a) {
                            this.actionButton = a.target
                        }.bind(this))
                    },
                    isValidAction: function() {
                        return this.actionButton && this.actionButton.name in this.whitelistedActions
                    },
                    submitForm: function(a) {
                        if (!k.isWarrantySelectedInBuyBox() &&
                            this.isValidAction())
                            if (e.isUssWeblabInTreatment()) {
                                a.preventDefault();
                                a = this.getAddToCartParameters();
                                var c = {
                                        params: a
                                    },
                                    n = {
                                        ref: g.ajaxParams.REFTAG
                                    };
                                m.shouldFireAndForgetWeblabTrigger() && m.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue());
                                var c = b.addToCart("DetailPageBuyBox", c, n),
                                    z = new f.Timer(p.ATC_PROMISE_RESOLVED_TIMER),
                                    x = new f.Timer(p.PERCOLATE_DATA_PROMISE_RESOLVED_TIMER);
                                z.start();
                                x.start();
                                c.atcData.then(function(a) {
                                    1 === a.isOk && z.stop()
                                }, function() {
                                    f.logCounter(p.ATC_PROMISE_REJECTED_COUNTER)
                                });
                                c.percolateData.then(function() {
                                    x.stop()
                                }, function() {
                                    f.logCounter(p.PERCOLATE_DATA_PROMISE_REJECTED_COUNTER)
                                });
                                d.primaryATCClick(a[g.ajaxParams.ASIN], c)
                            } else f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED), m.shouldFireAndForgetWeblabTrigger() ? m.fireAndForgetWeblabTrigger(e.triggerUSSWeblabValue(), e.ussWeblabTreatmentValue()) : this.addHiddenUSSField("triggerUSSWeblab", e.triggerUSSWeblabValue());
                        else f.logCounter(g.metrics.POST_ATC_PRECONDITIONS_FAILED)
                    },
                    addHiddenUSSField: function(a, b) {
                        n("\x3cinput\x3e").attr({
                            type: "hidden",
                            id: a,
                            name: a,
                            value: b
                        }).appendTo(this.buyBoxForm)
                    },
                    getAddToCartParameters: function() {
                        var a = {},
                            b = this.buyBoxForm.serializeArray();
                        n.each(b, function(b, c) {
                            a[c.name] = c.value
                        });
                        return a
                    }
                };
                return {
                    init: a.init.bind(a)
                }
            }))
        }

        function k() {
            var c = a.isUssConditionsPassed();
            c && d.logCounter(f.metrics.PAGE_LANDING_PRECONDITIONS_PASSED);
            if (A.isMobileApp() || c) g || (b(), g = !0, m.initializeUSSComponents()), m.initializeBuyBox()
        }
        var g = !1;
        C.on("PageRefresh:ATF", function() {
            k()
        });
        k()
    })
});
/* ******** */
(function(c) {
    var b = window.AmazonUIPageJS || window.P,
        d = b._namespace || b.attributeErrors,
        a = d ? d("InteractionTrackingAssets", "") : b;
    a.guardFatal ? a.guardFatal(c)(a, window) : a.execute(function() {
        c(a, window)
    })
})(function(c, b, d) {});
/* ******** */