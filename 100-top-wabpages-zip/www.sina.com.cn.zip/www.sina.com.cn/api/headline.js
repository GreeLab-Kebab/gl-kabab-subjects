    var leadNewsData = { 
		headlinePoster:{
			state:'true',  //是否纯图片格式
			images:{
			  src:['//n.sinaimg.cn/news/680/w300h380/20191009/dee9-ifrwayx0031663.png']
			},
			title:'',
			link:['https://finance.sina.com.cn/edu/2019-09-29/doc-iicezueu9079102.shtml']
		  },
		   videoTmp : {
            state : 'false',
            choice : 2,
			linkTop : 'http://fashion.sina.com.cn/zt_d/liangjingkang/',
			linkBottom : 'http://fashion.sina.com.cn/zt_d/liangjingkang/',
            imgtop : '//n.sinaimg.cn/news/433/w300h133/20190904/60db-ieaiqii9221092.png',
            video : {
                src : '//ask.ivideo.sina.com.cn/v_play_ipad.php?vid=30288287402&tags=popview',
				link:'http://video.sina.com.cn/p/fashion/2019-09-03/detail-iicezzrq3090014.d.html'
            },
            imgbottom : '//n.sinaimg.cn/news/378/w300h78/20190904/c734-ieaiqii9221863.png'
        },
		
     	question:{		//iframe类型
		state:'false',
		src : '//www.sina.com.cn/edblk/headlineIframe.shtml'
	},
	//头条轮播
	successively:{
	state:'false',  //是否纯图片格式
	images:{"srcgroup":["\/\/n.sinaimg.cn\/news\/680\/w300h380\/20190927\/c0a9-ifffqup0672798.jpg","\/\/n.sinaimg.cn\/news\/680\/w300h380\/20190927\/be48-ifffqup0674547.jpg"],"linkgroup":["http:\/\/fashion.sina.com.cn\/zt_d\/2020ss\/","https:\/\/finance.sina.com.cn\/china\/2019-09-26\/doc-iicezueu8598780.shtml"]}
	},
	focusPicture:{
	state :"false",
	 lanmutiao: {
        title:"2019高考成绩陆续公布",
		link:"http://edu.sina.com.cn/zt_d/fenshu/"				
    },
	tuwen1:{
                imgSrc:"//n.sinaimg.cn/default/transform/160/w90h70/20190622/c86f-hyvnhqp6783030.jpg",
                title:"四川现双胞胎学霸",
                content:"弟弟数学考了满分，总分718；哥哥考了705。",
                link:"http://edu.sina.com.cn/gaokao/2019-06-22/doc-ihytcerk8642445.shtml"
        },
    tuwen2:{
                imgSrc:"//n.sinaimg.cn/default/160/w90h70/20190621/a4ec-hyrtarx0473872.jpg",
                title:"4省市率先公布分数线",
                content:"2019高考分数线陆续公布中，一起来看。",
                link:"http://edu.sina.com.cn/zt_d/fenshu/"
        },
    focusPic:{
                src:"//www.sina.com.cn/iframe/headline/sinaIndex.shtml",
                width:"300",
                height:"150"
        }
	}
    
};